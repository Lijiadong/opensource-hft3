# rl-models

## Commands


### Commands to train a y0 predictor

```bash

python trans_data.py --old 8 --train "11_19-11_30"

python calculate_meanx3.py --train "11_19-11_30" 

python calculate_meanx3_2.py --train "11_19-11_30;12_03-12_10" 

python combine_daysx3.py --train 11_19-11_30

CUDA_VISIBLE_DEVICES=1 python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 601 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train "11_19-11_30" --valid 12_01-12_04 --test 12_01-12_01 --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 13 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 12_01-12_01 --wandb
```
### Commands to train a rl model with two sides dynamic

1. open continuous, close discrete (this is implemented under the position[-5, 0] setting, open one position, close all)
```bash
CUDA_VISIBLE_DEVICES=0 python main_cnnlstm_rl_sim3_7.py --lr 0.001 --dropout 0 --opt adamw --x xnn6 --y 0 --input_size 73 --wd 1e-6 --T 5 --batch_size 2048 --old 39 --train 12_11-01_20 --valid 01_21-01_31 --test 02_01-02_08 --arch TSTransformerEncoderRLSeq7 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_08 --test4 02_01-02_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_sell_12_11-01_20std --rlbuy_profit_path2 "219dout4easy_profit_sell_02_01-02_08std" --rlbuy_profit_path3 219dout4easy_profit_sell_02_01-02_08std --rlbuy_profit_path4 219dout4easy_profit_sell_02_01-02_08std --valid_2ndsellpoint 219dout4valid_buy2ndpoint_12_11-01_20std --valid_2ndsellpoint2 "219dout4valid_buy2ndpoint_02_01-02_08std" --valid_2ndsellpoint3 219dout4valid_buy2ndpoint_02_01-02_08std --valid_2ndsellpoint4 219dout4valid_buy2ndpoint_02_01-02_08std --wandb --gradient_acc_step 30 --type sell --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name t2close404 --not_squeeze --norm_y --set_seed --repeat_times 10 --consider_zero --gamma 0 --bin 1 --t2 --d_num 6 --offset 0 --d_list 4 5 3 2 1 0 --use_true_lag
```

2. open continuous, close continuous (this is implemented under the position[-5, 5] setting, open one position, close one position)
```bash
CUDA_VISIBLE_DEVICES=0 python main_cnnlstm_rl_sim3_7sharpe2twoside3.py --lr 0.001 --dropout 0 --opt adamw --x xnn6 --y 0 --input_size 73 --wd 1e-6 --T 5 --batch_size 2048 --old 39 --train 12_11-01_20 --valid 01_21-01_31 --test $date --arch TSTransformerEncoderRLSeq72 --val_split 0.0001 --use_p23 101 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_08 --test4 02_01-02_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_buy_12_11-01_20std --rlbuy_profit_path2 "219dout4easy_profit_buy_${date}std" --rlbuy_profit_path3 219dout4easy_profit_buy_02_01-02_08std --rlbuy_profit_path4 219dout4easy_profit_buy_02_01-02_08std --valid_2ndsellpoint 219dout4valid_sell2ndpoint_12_11-01_20std --valid_2ndsellpoint2 "219dout4valid_sell2ndpoint_${date}std" --valid_2ndsellpoint3 219dout4valid_sell2ndpoint_02_01-02_08std --valid_2ndsellpoint4 219dout4valid_sell2ndpoint_02_01-02_08std --wandb --gradient_acc_step 30 --type buy --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name t2close45310000segsharpe44 --not_squeeze --norm_y --repeat_times 10 --consider_zero --gamma 0 --d_num 7 --offset 0 --bin 5 --t2 --d_list 4 5 3 2 1 0 10000 --no_order --m1 3 --m2 3 (--sharpe, use this to control whether use sharpe as the target) --use_true_lag 
```

2. open discrete, close continuous(this is implemented under the position[-5, 5] setting, open one position, close one position)
```bash
CUDA_VISIBLE_DEVICES=0 python main_cnnlstm_rl_sim3_7sharpe2twoside3.py --lr 0.001 --dropout 0 --opt adamw --x xnn6 --y 0 --input_size 73 --wd 1e-6 --T 5 --batch_size 2048 --old 39 --train 12_11-01_20 --valid 01_21-01_31 --test $date --arch TSTransformerEncoderRLSeq75 --val_split 0.0001 --use_p23 101 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_08 --test4 02_01-02_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_buy_12_11-01_20std --rlbuy_profit_path2 "219dout4easy_profit_buy_${date}std" --rlbuy_profit_path3 219dout4easy_profit_buy_02_01-02_08std --rlbuy_profit_path4 219dout4easy_profit_buy_02_01-02_08std --valid_2ndsellpoint 219dout4valid_sell2ndpoint_12_11-01_20std --valid_2ndsellpoint2 "219dout4valid_sell2ndpoint_${date}std" --valid_2ndsellpoint3 219dout4valid_sell2ndpoint_02_01-02_08std --valid_2ndsellpoint4 219dout4valid_sell2ndpoint_02_01-02_08std --wandb --gradient_acc_step 30 --type buy --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name t2close45310000segsharpe44 --not_squeeze --norm_y --repeat_times 10 --consider_zero --gamma 0 --d_num 7 --offset 0 --bin 5 --t2 --d_list 4 5 3 2 1 0 10000 --no_order --m1 3 --m2 3 (--sharpe, use this to control whether use sharpe as the target) --use_true_lag
```

### Dataloading codes places

#### y0 predictor

stock.py (1)StockAggregate18, change especially the "data_6/" prefix and add new "args.train=="xxx"". (2) "args.old==18" load data and abs, std, mean.


#### rl models

stock.py "args.old == 39" load data, tps, tpb, profitmaping and profit std and so on. These are generated with the next sections' commands.

### Data preprocessing codes

#### Change 23_xx_xx to xx_xx
```bash
bash rename_days.sh (the dates of files and locations should be changed accordingly.)
```

#### Generate profit mappings.

```bash
for date in "12_11-01_20" "01_21-01_31" "02_01-02_08"
do 
python trans_data.py --train $date --old 8
CUDA_VISIBLE_DEVICES=0 python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 601 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train 12_21-01_31 --valid 02_01-02_04 --test $date --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 13 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_01 --wandb --generate_test_predict --seed 8554873884 (This should be changed accordingly to the trained y0 predictor setting, i.e., the "--train", "--valid", "--test")

python backtest_2_compare_test6_19.py --test $date --perform_backtest --compute_trade --wandb --seed 999999    --profit_type 19
python backtest_2_compare_test6_19close.py --test $date --perform_backtest --compute_trade --wandb --seed 8554873884    --profit_type 19
python backtest_2_compare_test6_22.py --test $date --perform_backtest --compute_trade --wandb --seed 8554873884    --profit_type 19 --t2
done
```

### What different sim files mean?

main_cnnlstm_rl_sim3.py is the first version to run successfully the one side rl.

```bash
CUDA_VISIBLE_DEVICES=1  python main_cnnlstm_rl_sim3.py --lr 0.001 --dropout 0 --opt adamw --x xnn3 --y 0 --input_size 504 --wd 0 --T 5 --batch_size 2048 --old 38 --train 08_11-09_15 --valid 09_16-09_25 --test 09_16-09_25 --arch TSTransformerEncoderRLSeq3 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 09_26-10_25 --test4 10_27-11_06 --test_interval 2000 --rlbuy_profit_path 19dout4easy_profit_sell_08_11-09_15std --rlbuy_profit_path2 19dout4easy_profit_sell_09_16-09_25std --rlbuy_profit_path3 19dout4easy_profit_sell_09_26-10_25std --rlbuy_profit_path4 19dout4easy_profit_sell_10_27-11_06std --valid_buypoint_train 19dout4valid_sellpoint_08_11-09_15std --valid_buypoint_valid 19dout4valid_sellpoint_09_16-09_25std --valid_buypoint_test 19dout4valid_sellpoint_09_26-10_25std --valid_buypoint_test4 19dout4valid_sellpoint_10_27-11_06std --buy_bucket_path 19dout4buckets_sell_08_11-09_15std --buy_bucket_path2 19dout4buckets_sell_09_16-09_25std --buy_bucket_path3 19dout4buckets_sell_09_26-10_25std --buy_bucket_path4 19dout4buckets_sell_10_27-11_06std --valid_2ndsellpoint 19dout4valid_buy2ndpoint_08_11-09_15std --valid_2ndsellpoint2 19dout4valid_buy2ndpoint_09_16-09_25std --valid_2ndsellpoint3 19dout4valid_buy2ndpoint_09_26-10_25std --valid_2ndsellpoint4 19dout4valid_buy2ndpoint_10_27-11_06std --num_envs 256 --num_steps 5000 --lag 1 --wandb --gamma 0 --remaining 1 --gradient_acc_step 30 --norm_y --type sell --not_use_bin_feature --exp_neg --take_normal --updates_thres 200000 --profit_type 19
```

main_cnnlstm_rl_sim3_3.py is another stable version to train one side rl with faster evaluation.

main_cnnlstm_rl_sim4_2.py is a stable version with double sell open rl.

```bash

CUDA_VISIBLE_DEVICES=1  python main_cnnlstm_rl_sim4_2.py --lr 0.001 --dropout 0 --opt adamw --x xnn4 --y 0 --input_size 96 --wd 0 --T 5 --batch_size 2048 --old 37 --train 08_11-10_20 --valid 10_21-10_25 --test 10_21-10_25 --arch TSTransformerEncoderRLSeq4 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 10_27-11_08 --test4 12_06-12_06 --test_interval 2000 --rlbuy_profit_path 19dout4easy_profit_sell_08_11-10_20std --rlbuy_profit_path2 19dout4easy_profit_sell_10_21-10_25std --rlbuy_profit_path3 19dout4easy_profit_sell_10_27-11_08std --rlbuy_profit_path4 19dout4easy_profit_sell_12_06-12_06std --valid_buypoint_train 19dout4valid_sellpoint_08_11-10_20std --valid_buypoint_valid 19dout4valid_sellpoint_10_21-10_25std --valid_buypoint_test 19dout4valid_sellpoint_10_27-11_08std --valid_buypoint_test4 19dout4valid_sellpoint_12_06-12_06std --buy_bucket_path 19dout4buckets_sell_08_11-10_20std --buy_bucket_path2 19dout4buckets_sell_10_21-10_25std --buy_bucket_path3 19dout4buckets_sell_10_27-11_08std --buy_bucket_path4 19dout4buckets_sell_12_06-12_06std --valid_2ndsellpoint 19dout4valid_buy2ndpoint_08_11-10_20std --valid_2ndsellpoint2 19dout4valid_buy2ndpoint_10_21-10_25std --valid_2ndsellpoint3 19dout4valid_buy2ndpoint_10_27-11_08std --valid_2ndsellpoint4 19dout4valid_buy2ndpoint_12_06-12_06std --num_envs 256 --num_steps 5000 --lag 1 --wandb --gamma 0 --remaining 1 --gradient_acc_step 30 --norm_y --type sell --not_use_bin_feature --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --learn_bias
```
main_cnnlstm_rl_sim3_7.py is the stable version with open&close rl.

```bash
CUDA_VISIBLE_DEVICES=0 python main_cnnlstm_rl_sim3_7.py --lr 0.001 --dropout 0 --opt adamw --x xnn6 --y 0 --input_size 73 --wd 1e-6 --T 5 --batch_size 2048 --old 39 --train 12_11-01_20 --valid 01_21-01_31 --test 02_01-02_08 --arch TSTransformerEncoderRLSeq7 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_08 --test4 02_01-02_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_sell_12_11-01_20std --rlbuy_profit_path2 "219dout4easy_profit_sell_02_01-02_08std" --rlbuy_profit_path3 219dout4easy_profit_sell_02_01-02_08std --rlbuy_profit_path4 219dout4easy_profit_sell_02_01-02_08std --valid_2ndsellpoint 219dout4valid_buy2ndpoint_12_11-01_20std --valid_2ndsellpoint2 "219dout4valid_buy2ndpoint_02_01-02_08std" --valid_2ndsellpoint3 219dout4valid_buy2ndpoint_02_01-02_08std --valid_2ndsellpoint4 219dout4valid_buy2ndpoint_02_01-02_08std --wandb --gradient_acc_step 30 --type sell --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name t2close404 --not_squeeze --norm_y --set_seed --repeat_times 10 --consider_zero --gamma 0 --bin 1 --t2 --d_num 6 --offset 0 --d_list 4 5 3 2 1 0 --use_true_lag
```

main_cnnlstm_rl_sim3_7sharpe2twoside3.py is the stable version to run with sharpe target.

```bash
CUDA_VISIBLE_DEVICES=0 python main_cnnlstm_rl_sim3_7sharpe2twoside3.py --lr 0.001 --dropout 0 --opt adamw --x xnn6 --y 0 --input_size 73 --wd 1e-6 --T 5 --batch_size 2048 --old 39 --train 12_11-01_20 --valid 01_21-01_31 --test $date --arch TSTransformerEncoderRLSeq72 --val_split 0.0001 --use_p23 101 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_08 --test4 02_01-02_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_buy_12_11-01_20std --rlbuy_profit_path2 "219dout4easy_profit_buy_${date}std" --rlbuy_profit_path3 219dout4easy_profit_buy_02_01-02_08std --rlbuy_profit_path4 219dout4easy_profit_buy_02_01-02_08std --valid_2ndsellpoint 219dout4valid_sell2ndpoint_12_11-01_20std --valid_2ndsellpoint2 "219dout4valid_sell2ndpoint_${date}std" --valid_2ndsellpoint3 219dout4valid_sell2ndpoint_02_01-02_08std --valid_2ndsellpoint4 219dout4valid_sell2ndpoint_02_01-02_08std --wandb --gradient_acc_step 30 --type buy --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name t2close45310000segsharpe44 --not_squeeze --norm_y --repeat_times 10 --consider_zero --gamma 0 --d_num 7 --offset 0 --bin 5 --t2 --d_list 4 5 3 2 1 0 10000 --no_order --m1 3 --m2 3 --sharpe --use_true_lag 
```

main_cnnlstm_rl_sim3_7sharpe2twoside3closefast.py is the experimental codes trying with idea to close fast with taker.

```bash
CUDA_VISIBLE_DEVICES=2 python main_cnnlstm_rl_sim3_7sharpe2twoside5closefast.py --lr 0.001 --dropout 0 --opt adamw --x xnn6 --y 0 --input_size 73 --wd 1e-6 --T 5 --batch_size 2048 --old 39 --train 12_11-01_20 --valid 02_01-02_08 --test 12_11-01_20 --arch TSTransformerEncoderRLSeq72 --val_split 0.0001 --use_p23 101 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_08 --test4 02_01-02_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_buy_12_11-01_20std --rlbuy_profit_path2 219dout4easy_profit_buy_12_11-01_20std --rlbuy_profit_path3 219dout4easy_profit_buy_02_01-02_08std --rlbuy_profit_path4 219dout4easy_profit_buy_02_01-02_08std --valid_2ndsellpoint 219dout4valid_sell2ndpoint_12_11-01_20std --valid_2ndsellpoint2 219dout4valid_sell2ndpoint_12_11-01_20std --valid_2ndsellpoint3 219dout4valid_sell2ndpoint_02_01-02_08std --valid_2ndsellpoint4 219dout4valid_sell2ndpoint_02_01-02_08std --wandb --gradient_acc_step 30 --type buy --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name t2close45310000segsharpe44bin10000 --not_squeeze --norm_y --repeat_times 10 --consider_zero --gamma 0 --d_num 7 --offset 0 --bin 10000 --t2 --d_list 4 5 3 2 1 0 10000 --no_order --m1 3 --m2 3 --use_true_lag
```

main_cnnlstm_rl_sim3_14.py is the code to backtest with strategy consider std>5 as special case.
```bash
CUDA_VISIBLE_DEVICES=0 python main_cnnlstm_rl_sim3_14.py --lr 0.001 --dropout 0 --opt adamw --x xnn6 --y 0 --input_size 73 --wd 1e-6 --T 5 --batch_size 2048 --old 39 --train 12_11-01_20 --valid 01_21-01_31 --test 02_01-02_08 --arch TSTransformerEncoderRLSeq7 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_08 --test4 02_01-02_08 --test_interval 2000 --rlbuy_profit_path 219dout4easy_profit_sell_12_11-01_20std --rlbuy_profit_path2 "219dout4easy_profit_sell_02_01-02_08std" --rlbuy_profit_path3 219dout4easy_profit_sell_02_01-02_08std --rlbuy_profit_path4 219dout4easy_profit_sell_02_01-02_08std --valid_2ndsellpoint 219dout4valid_buy2ndpoint_12_11-01_20std --valid_2ndsellpoint2 "219dout4valid_buy2ndpoint_02_01-02_08std" --valid_2ndsellpoint3 219dout4valid_buy2ndpoint_02_01-02_08std --valid_2ndsellpoint4 219dout4valid_buy2ndpoint_02_01-02_08std --wandb --gradient_acc_step 30 --type sell --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --action_size 1 --name t2close404 --not_squeeze --norm_y --set_seed --repeat_times 10 --consider_zero --gamma 0 --bin 1 --t2 --d_num 6 --offset 0 --d_list 4 5 3 2 1 0  --generate_test_predict --seed 1675965033.3244553 --ip ***.***.***.*** --write_db --start 75  --use_true_lag --predict_all
```

Other code files are dummy.

### Data types and locations.

23_xx_xx are changed to xx_xx.

combined files are saved also in "data_6/"

No other wierd things.












