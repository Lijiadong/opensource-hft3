import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt
import torch

def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test)
flist = genflist(args.test[0])
print(flist)
filename = "fu"
data = pd.DataFrame()
first = True
for file in flist:
    if first:
        data = pd.read_pickle('data_6/data_'+file+'.pkl')
        first = False
    else:
        tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
        data = pd.concat([data, tmp])
data = data.iloc[4:]
# data = data.iloc[:int(1e5)]
with open("data_7/y0_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number0)+".npy", 'rb') as f:
    y = np.load(f)
# y = y[:int(1e5)]
def backtest(a, b):
    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)
    p1='predict1'
    filename='fu'
    profit_l = np.zeros((len(data), 4))
    non_zeros = 0
    non_zeros_ = 0
    print(len(data))
    # exit(-1)
    for i in range(0, len(data)-1):
        # if data[p1][i]>-a:
            for d in range(1, 2):
                # buy_price = data['bp1_'+filename][i]*(1-d/1e4)*(1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
                tpb = data['sellpriceT_'+filename][i+1]
                buy_price = tpb + 0.01
                profit = 0
                # if data[p1][i]<=-a:
                    # print("now <= -1")
                # print(i, d)
                if tpb <= buy_price-0.01 and tpb != 0:
                    # print(i, d, "buy in")
                    # if data[p1][i] <=-a:
                    #     exit(-1)
                    # print(data.index[i],data[p1][i])
                    # print('buy',i, buy_price, tpb, data['buyprice_'+filename][i+1], data['mid_'+filename][i])
                    profit += 0.4/1e4
                    # print("now profit", profit)
                    j = i
                    while(True):
                        j += 1
                        if j+5 >= len(data):
                            profit = 0
                            break
                        if data[p1][j] < -b:
                            sell_price = data['bp1_fu'][j+5]*(1.0)
                            profit += sell_price / buy_price - 1 - 2/1e4
                            # print("now profit", profit)
                            break
                        # sell_price = data['ap1_'+filename][j]*(1+d/1e4)*(1+np.clip(2*(data[p1][j]+0.0)/1e4,-0/1e4, 20/1e4))
                        tp = data['buypriceT_'+filename][j+1]
                        sell_price = tp - 0.01
                        if tp >= sell_price+0.01 and tp != 0:
                            # print(data.index[j],data[p1][j])
                            # print('sell close', sell_price)
                            profit += sell_price / buy_price - 1 + 0.4/1e4
                            # print("now profit", profit)
                            break
                    profit_l[i][d-1] = profit
                    
                else:
                    # if data[p1][i]<=-a:
                        # print("cannot buy in")
                    profit_l[i][d-1] = 0
                    # print("----profit of "+ str(d) + " in tick " + str(i) +" ----", profit)
            if np.sum(profit_l[i]) != 0:
                if data[p1][i]>-a:
                    # print("----for y > -1, profit of "+ str(d) + " in tick " + str(i) +" ----", profit_l[i])
                    non_zeros += 1
                else:
                    # print("----for y <= -1, profit of "+ str(d) + " in tick " + str(i) +" ----", profit_l[i])
                    non_zeros_ += 1
                print("non_zeros, non_zeros_, total tick", non_zeros, non_zeros_, len(data), np.sum(profit_l))
    np.save("profit_l_non_constraint.npy", profit_l)

backtest(1, 10)
