import pandas as pd
import numpy as np
from args import args
import datetime


def tr_data(date_list, tp, old=2):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day, day.month, day.day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        loc = 'data_6/'+tp+'_'+month_str+'_'+day_str+'.pkl'
        mid_p = (pd.read_pickle(loc)["ap1_fu"]+pd.read_pickle(loc)["bp1_fu"])/2
        mid_window_mean = mid_p.rolling(50).mean()
        mid_p = mid_p.to_numpy()
        print(mid_p.shape, mid_window_mean.shape, mid_window_mean[-200:].to_numpy())
        mid_window_mean = np.concatenate([mid_window_mean[99:].to_numpy(),mid_window_mean[-1]*np.ones((99,))], axis=0)
        print(mid_window_mean[-300:])
        print(mid_p.shape, mid_window_mean.shape)
        y50 = np.log(mid_window_mean/mid_p)*1e4
        y0 = np.load('data_6/y'+'_'+month_str+'_'+day_str+'.npy')
        print(y50, y0)
        with open('data_6/'+"y50"+'_'+month_str+'_'+day_str+'.npy', 'wb') as f:
            np.save(f, y50)
tr_data(args.train[0], "data", 7)
