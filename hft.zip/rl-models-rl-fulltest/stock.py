from ast import arg
from pickletools import uint1
import re
import torch.utils.data as data
import torch
import numpy as np
from args import args
import datetime
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import WeightedRandomSampler
import wandb
if args.wandb:
    wandb.init(project="stock_prediction", config=args, name=args.name, entity="zhouuxx96")



def load_data_length(date_list, tp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if start_month <= end_month:
        year = 2022
    else:
        year = 2023
    end = datetime.date(year,end_month,end_day)
    x_l = 0
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day, day.month, day.day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l += np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r").shape[0]
    return x_l

std_profit, mean_profit, abs_profit = None, None, None
class CustomWeightedRandomSampler(WeightedRandomSampler):
    """WeightedRandomSampler except allows for more than 2^24 samples to be sampled"""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __iter__(self):
        rand_tensor = np.random.choice(range(0, len(self.weights)),
                                       size=self.num_samples,
                                       p=self.weights.numpy() / torch.sum(self.weights).numpy(),
                                       replace=self.replacement)
        rand_tensor = torch.from_numpy(rand_tensor)
        return iter(rand_tensor.tolist())

if args.old == 0:
    train_lim = 800000
    val_lim = 950000
    test_lim = 1274215

    with open('data_old/x.npy', 'rb') as f:
        x = np.load(f)
    with open('data_old/y.npy', 'rb') as f:
        y = np.load(f)
        

    x = torch.from_numpy(x)
    y = torch.from_numpy(y)
    # indices = torch.load("data_old/old_indices.pt")
    # indices = torch.randperm(test_lim)
    # torch.save(indices, "indices.pt")
    # exit(-1)
    # print(indices.shape)
    # x = x[indices].clone()
    # y = y[indices].clone()
    # torch.save(x, "x_shuffuled.pt")
    # torch.save(y, "y_shuffuled.pt")   
    # exit(-1)
    # x = torch.load("data_old/x_shuffuled.pt")
    # y = torch.load("data_old/y_shuffuled.pt")

    # rand_train_idx = np.random.choice([i for i in range(test_lim)], (train_lim))
    # print(rand_train_idx, len(rand_train_idx))
    # rand_val_idx = np.random.choice([i for i in range(test_lim)], (val_lim-train_lim))
    # print(rand_val_idx, len(rand_val_idx))
    # rand_test_idx = np.random.choice([i for i in range(test_lim)], (test_lim-val_lim))
    # print(rand_test_idx, len(rand_test_idx))

    g_list, train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [["ETH/USDT"], x[:train_lim], y[:train_lim], x[train_lim:val_lim], y[train_lim:val_lim], x[val_lim:test_lim], y[val_lim:test_lim], x.mean(0), x.std(0)]
elif args.old == 1:
    with open('x.npy', 'rb') as f:
        x = np.load(f)
    with open('y.npy', 'rb') as f:
        y = np.load(f)

    with open('x2.npy', 'rb') as f:
        x2 = np.load(f)
    with open('y2.npy', 'rb') as f:
        y2 = np.load(f)
    
    # def data_classification(X, Y, T):
    #     [N, D] = X.shape
    #     print(N, D)
    #     df = np.array(X)

    #     dY = np.array(Y)

    #     dataY = dY[T - 1:N]

    #     dataX = np.zeros((N - T + 1, T, D))
    #     for i in range(T, N + 2):
    #         dataX[i - T] = df[i - T:i, :]
    #     print(dataX, dataY)
    #     return dataX, dataY

    # x, y = data_classification(x, y, 50)
    # print(x.shape, y.shape)
    x = torch.from_numpy(x)
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v).clone()
    y = torch.from_numpy(y)
    x2 = torch.from_numpy(x2)
    abs_v = x2.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x2 = (x2/abs_v).clone()
    y2 = torch.from_numpy(y2)

    # indices = torch.randperm(x.size(0))
    # x_whole = torch.cat((x, x2), 0)
    # x = x[indices].clone()
    # y = y[indices].clone()

   
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, std, mean = [x, y, x, y, x2, y2, x.mean(0), x.std(0)]

elif args.old == 2:
    if args.x == "xn":
        with open('yuhi/xn_05_24.npy', 'rb') as f:
            x = np.load(f)
        with open('yuhi/xn_05_25.npy', 'rb') as f:
            x2 = np.load(f)
    else:
        with open('yuhi/xnn_05_24.npy', 'rb') as f:
            x = np.load(f)
        with open('yuhi/xnn_05_25.npy', 'rb') as f:
            x2 = np.load(f)
    if args.y == "0":
        with open('yuhi/y_05_24.npy', 'rb') as f:
            y = np.load(f)
        with open('yuhi/y_05_25.npy', 'rb') as f:
            y2 = np.load(f)
    elif args.y == "3":
        with open('yuhi/y3_05_24.npy', 'rb') as f:
            y = np.load(f)
        with open('yuhi/y3_05_25.npy', 'rb') as f:
            y2 = np.load(f)
    elif args.y == "4":
        with open('yuhi/y4_05_24.npy', 'rb') as f:
            y = np.load(f)
        with open('yuhi/y4_05_25.npy', 'rb') as f:
            y2 = np.load(f)
    print(x.shape)
    x = torch.from_numpy(x)
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v).clone()
    y = torch.from_numpy(y)
    x2 = torch.from_numpy(x2)
    abs_v = x2.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x2 = (x2/abs_v).clone()
    y2 = torch.from_numpy(y2)
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, std, mean = [x, y, x, y, x2, y2, x.mean(0), x.std(0)]

elif args.old == 3:
    # index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]

    if args.x == "xn":
        with open('data_4/xn_05_24.npy', 'rb') as f:
            x = np.load(f)
        with open('data_4/xn_05_25.npy', 'rb') as f:
            x2 = np.load(f)
    else:
        with open('data_4/xnn_05_24.npy', 'rb') as f:
            x = np.load(f)
        with open('data_4/xnn_05_25.npy', 'rb') as f:
            x2 = np.load(f)
    if args.y == "0":
        with open('data_4/y_05_24.npy', 'rb') as f:
            y = np.load(f)
        with open('data_4/y_05_25.npy', 'rb') as f:
            y2 = np.load(f)
    elif args.y == "3":
        with open('data_4/y3_05_24.npy', 'rb') as f:
            y = np.load(f)
        with open('data_4/y3_05_25.npy', 'rb') as f:
            y2 = np.load(f)
    elif args.y == "4":
        with open('data_4/y4_05_24.npy', 'rb') as f:
            y = np.load(f)
        with open('data_4/y4_05_25.npy', 'rb') as f:
            y2 = np.load(f)
    print(x.shape, "why???????????")
    # x = torch.from_numpy(x)[:, :-2]
    x = torch.from_numpy(x)[:, :-2]
    print(x.size(), "_------------")
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v).clone()
    y = torch.from_numpy(y)
    x2 = torch.from_numpy(x2)[:, :-2]
    abs_v = x2.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x2 = (x2/abs_v).clone()
    y2 = torch.from_numpy(y2)
    gtrain_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [x, y, x, y, x2, y2, x.mean(0), x.std(0)]

elif args.old == 4:
    def load_data(start, end, tp):
        x_l = []
        for i in range(start, end+1):
            with open('data_4/'+tp+'_05_'+str(i)+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)))
        return torch.cat(x_l, dim=0)
        
    if args.x == "xn":
        x = load_data(24, 28, "xn")[:, :-2]
        x2 = load_data(29, 29, "xn")[:, :-2]
    else:
        x = load_data(24, 28, "xnn")[:, :-2]
        x2 = load_data(29, 29, "xnn")[:, :-2]
    if args.y == "0":
        y = load_data(24, 28, "y")
        y2 = load_data(29, 29, "y")
    elif args.y == "3":
        y = load_data(24, 28, "y3")
        y2 = load_data(29, 29, "y3")
    elif args.y == "4":
        y = load_data(24, 28, "y4")
        y2 = load_data(29, 29, "y4")
    print(x.shape, x2.shape, y.shape, y2.shape)
    # x = torch.from_numpy(x)[:, :-2]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v).clone()
    abs_v = x2.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x2 = (x2/abs_v).clone()
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [x, y, x, y, x2, y2, x.mean(0), x.std(0)]

elif args.old == 5:
    def load_data(start, end, tp):
        x_l = []
        for i in range(start, end+1):
            with open('data_4/'+tp+'_05_'+str(i)+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)))
        return torch.cat(x_l, dim=0)
        
    if args.x == "xn":
        x = torch.cat([load_data(24, 28, "xn"), load_data(30, 31, "xn")], dim=0)[:, :-2]
        x2 = load_data(29, 29, "xn")[:, :-2]
    else:
        x = torch.cat([load_data(24, 28, "xnn"), load_data(30, 31, "xnn")], dim=0)[:, :-2]
        x2 = load_data(29, 29, "xnn")[:, :-2]
    if args.y == "0":
        y = torch.cat([load_data(24, 28, "y"), load_data(30, 31, "y")], dim=0)
        y2 = load_data(29, 29, "y")
    elif args.y == "3":
        y = torch.cat([load_data(24, 28, "y3"), load_data(30, 31, "y3")], dim=0)
        y2 = load_data(29, 29, "y3")
    elif args.y == "4":
        y = torch.cat([load_data(24, 28, "y4"), load_data(30, 31, "y4")], dim=0)
        y2 = load_data(29, 29, "y4")
    print(x.shape, x2.shape, y.shape, y2.shape)
    # x = torch.from_numpy(x)[:, :-2]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v).clone()
    abs_v = x2.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x2 = (x2/abs_v).clone()
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [x, y, x, y, x2, y2, x.mean(0), x.std(0)]

elif args.old == 6:
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_4/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)))
        return torch.cat(x_l, dim=0)
        
    if args.x == "xn":
        x = torch.cat([load_data(args.train[i], "xn") for i in range(len(args.train))], dim=0)[:, :-2]
        x2 = torch.cat([load_data(args.test[i], "xn") for i in range(len(args.test))], dim=0)[:, :-2]
    else:
        x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, :-2]
        x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, :-2]
    if args.y == "0":
        y = torch.cat([load_data(args.train[i], "y") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y") for i in range(len(args.test))], dim=0)
    elif args.y == "3":
        y = torch.cat([load_data(args.train[i], "y3") for i in range(len(args.train))], dim=0)
        y2 =  torch.cat([load_data(args.test[i], "y3") for i in range(len(args.test))], dim=0)
    elif args.y == "4":
        y = torch.cat([load_data(args.train[i], "y4") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y4") for i in range(len(args.test))], dim=0)
    print(x.shape, x2.shape, y.shape, y2.shape)
    # x = torch.from_numpy(x)[:, :-2]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v).clone()
    abs_v = x2.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x2 = (x2/abs_v).clone()
    valiation_split = int(x.size(0)*(1-args.val_split))
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [x[:valiation_split], y[:valiation_split], x[valiation_split:], y[valiation_split:], x2, y2, x.mean(0), x.std(0)]

elif args.old == 7:
    print("train, test", args.train, args.test)
    if args.use_p23 == 3:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37]
    elif args.use_p23 == 2:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 37]
    elif args.use_p23 == 1:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36]
    else:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_5/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)))
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_5/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    print(y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    if args.x == "xn":
        x = torch.cat([load_data(args.train[i], "xn") for i in range(len(args.train))], dim=0)[:, index]
        x2 = torch.cat([load_data(args.test[i], "xn") for i in range(len(args.test))], dim=0)[:, index]
    else:
        x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
        x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    if args.y == "0":
        y = torch.cat([load_data(args.train[i], "y") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y") for i in range(len(args.test))], dim=0)
    elif args.y == "3":
        y = torch.cat([load_data(args.train[i], "y3") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y3") for i in range(len(args.test))], dim=0)
    elif args.y == "4":
        y = torch.cat([load_data(args.train[i], "y4") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y4") for i in range(len(args.test))], dim=0)
    print(x.shape, x2.shape, y.shape, y2.shape)
    # x = torch.from_numpy(x)[:, :-2]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v).clone()
    x2 = (x2/abs_v).clone()
    valiation_split = int(x.size(0)*(1-args.val_split))
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [x[:valiation_split], y[:valiation_split], x[valiation_split:], y[valiation_split:], x2, y2, x.mean(0), x.std(0)]

elif args.old == 8:
    print("train, test", args.train, args.test)
    if args.use_p23 == 0:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 46, 48]
    elif args.use_p23 == 1:    
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.use_p23 == 2:    
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.use_p23 == 3:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.use_p23 == 4:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]
    elif args.use_p23 == 5:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    print(y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    y_length_list_2 = []
    for i in range(len(args.test2)):
        y_length_list_2 += load_data_length(args.test2[i], "y") 
    print("y_length_list_2", y_length_list_2)
    y_length_list_2[-1] = y_length_list_2[-1]-args.T+1

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    x3 = torch.cat([load_data(args.test2[i], "xnn") for i in range(len(args.test2))], dim=0)[:, index]

    print("index, x.size()", index, x.size())
    if args.y == "0":
        y = torch.cat([load_data(args.train[i], "y") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y") for i in range(len(args.test))], dim=0)
        y3 = torch.cat([load_data(args.test2[i], "y") for i in range(len(args.test2))], dim=0)
    elif args.y == "3":
        y = torch.cat([load_data(args.train[i], "y3") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y3") for i in range(len(args.test))], dim=0)
        y3 = torch.cat([load_data(args.test2[i], "y3") for i in range(len(args.test2))], dim=0)
    elif args.y == "4":
        y = torch.cat([load_data(args.train[i], "y4") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y4") for i in range(len(args.test))], dim=0)
        y3 = torch.cat([load_data(args.test2[i], "y4") for i in range(len(args.test2))], dim=0)

    print(x.shape, x2.shape, x3.shape, y.shape, y2.shape, y3.shape)
    # x = torch.from_numpy(x)[:, :-2]
    # ori_x2 = x2.clone()
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    x2 = (x2/abs_v)
    x3 = (x3/abs_v)
    valiation_split = int(x.size(0)*(1-args.val_split))
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [x, y, x[valiation_split:], y[valiation_split:], x2, y2, x.mean(0), x.std(0)]
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    # d = {"abs_v": abs_v, "mean": mean, "std": std}
    # torch.save("stat_"+";".join(args.train)+".pt", d)
    noise_mask = torch.load("noise_mask_0.5_2.pt")

elif args.old == 9:
    print("train, test", args.train, args.test)
    if args.use_p23 == 0:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 46, 48]
    elif args.use_p23 == 1:    
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.use_p23 == 2:    
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    else:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    print(y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    print("index, x.size()", index, x.size())
    if args.y == "0":
        y = torch.cat([load_data(args.train[i], "y") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y") for i in range(len(args.test))], dim=0)
    elif args.y == "3":
        y = torch.cat([load_data(args.train[i], "y3") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y3") for i in range(len(args.test))], dim=0)
    elif args.y == "4":
        y = torch.cat([load_data(args.train[i], "y4") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y4") for i in range(len(args.test))], dim=0)
    print(x.shape, x2.shape, y.shape, y2.shape)
    def trans(y):
        z0 = (y<-10)
        z1 = (-10<=y) & (y<-0.6)
        z2 = (-0.6<=y) & (y<=0.6)
        z3 = (0.6<y) & (y<=10)
        z4 = (10<y)
        y[z0] = 0
        y[z1] = 1
        y[z2] = 2
        y[z3] = 3
        y[z4] = 4
        return z0, z1, z2, z3, z4
    z0, z1, z2, z3, z4 = trans(y)
    print(z0.sum(), z1.sum(), z2.sum(), z3.sum(), z4.sum())
    # for i in range(y.size(0)):
        # print(y[i])
    print(y, y.size())

    group_weights = y.size(0) / torch.Tensor([z0.sum().item(), z1.sum().item(), z2.sum().item(), z3.sum().item(), z4.sum().item()]).float()
    print(group_weights)
    weights = group_weights[y.long()]
    wegihtedsampler = CustomWeightedRandomSampler(weights[args.T-1:],
                                    y.size(0)-args.T+1,
                                    replacement=True)
    trans(y2)
    ori_x2 = x2.clone()
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    x2 = (x2/abs_v)
    valiation_split = int(x.size(0)*(1-args.val_split))
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y, mean, std = [x, y, x, y, x2, y2, x.mean(0), x.std(0)]
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    # d = {"abs_v": abs_v, "mean": mean, "std": std}
    # torch.save("stat_"+";".join(args.train)+".pt", d)
    noise_mask = torch.load("noise_mask_0.5_2.pt")


elif args.old == 10:
    print("train, test", args.train, args.test)
    if args.use_p23 == 0:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 46, 48]
    elif args.use_p23 == 1:    
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.use_p23 == 2:    
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    else:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    print(y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index]
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index]
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index]

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)
    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1)).float()
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1)).float()
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1)).float()

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    x588 = torch.cat([load_data(args.train[i], "x") for i in range(len(args.train))], dim=0)
    x588_2 = torch.cat([load_data(args.test[i], "x") for i in range(len(args.test))], dim=0)
    x = torch.cat([x, x588], dim=1)
    x2 = torch.cat([x2, x588_2], dim=1)

    print("x.size()", x.size(), x2.size())
    if args.y == "0":
        y = torch.cat([load_data(args.train[i], "y") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y") for i in range(len(args.test))], dim=0)
    elif args.y == "3":
        y = torch.cat([load_data(args.train[i], "y3") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y3") for i in range(len(args.test))], dim=0)
    elif args.y == "4":
        y = torch.cat([load_data(args.train[i], "y4") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y4") for i in range(len(args.test))], dim=0)
    
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y = [x, y, x, y, x2, y2]

elif args.old == 11:
    print("train, test", args.train, args.test)
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]

    import datetime
    def load_data(date_list, tp, abs_v=None, mean=None, std=None):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                if tp == "xnn":
                    x_l.append(((torch.from_numpy(np.load(f)).float()[:, index]/abs_v)-mean)/std)
                elif tp == "x":
                    x_l.append(((torch.from_numpy(np.load(f)).float()/abs_v)-mean)/std)
                else:
                    x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    print(y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    with open('abs_v'+";".join(args.train)+'588.npy', 'rb') as f:
        abs_v = torch.from_numpy(np.load(f))
    with open('mean'+";".join(args.train)+'588.npy', 'rb') as f:
        mean = torch.from_numpy(np.load(f))
    with open('std'+";".join(args.train)+'588.npy', 'rb') as f:
        std = torch.from_numpy(np.load(f))
    print(abs_v.size(), mean.size(), std.size())

    x = torch.cat([load_data(args.train[i], "xnn", abs_v[:57], mean[:57], std[:57]) for i in range(len(args.train))], dim=0)
    x2 = torch.cat([load_data(args.test[i], "xnn", abs_v[:57], mean[:57], std[:57]) for i in range(len(args.test))], dim=0)
    x588 = torch.cat([load_data(args.train[i], "x", abs_v[57:], mean[57:], std[57:]) for i in range(len(args.train))], dim=0)
    x588_2 = torch.cat([load_data(args.test[i], "x", abs_v[57:], mean[57:], std[57:]) for i in range(len(args.test))], dim=0)
    x = torch.cat([x, x588], dim=1)
    x2 = torch.cat([x2, x588_2], dim=1)
    print(x.mean(0), x.std(0), x2.mean(0), x2.std(0))
    print("x.size()", x.size(), x2.size())
    if args.y == "0":
        y = torch.cat([load_data(args.train[i], "y") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y") for i in range(len(args.test))], dim=0)
    elif args.y == "3":
        y = torch.cat([load_data(args.train[i], "y3") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y3") for i in range(len(args.test))], dim=0)
    elif args.y == "4":
        y = torch.cat([load_data(args.train[i], "y4") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y4") for i in range(len(args.test))], dim=0)

    torch.save(x,"x_645"+";".join(args.train)+'.pt')
    torch.save(x2,"x2_645"+";".join(args.test)+'.pt')
    torch.save(y,"y_645"+";".join(args.train)+'.pt')
    torch.save(y2,"y2_645"+";".join(args.test)+'.pt')
    torch.save(y_length_list,"y_length_list2_645"+";".join(args.test)+'.pt')

    exit(-1)

elif args.old == 12:
    index_all = []
    for i in range(647):
        if i != 34 and i != 35:
            index_all.append(i)
    print(index_all)
    # abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+".npy").reshape(1, 59)
    # mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+".npy").reshape(1, 59)
    # std_xnn = np.load('data_6/std_xnn'+args.train[0]+".npy").reshape(1, 59)

    # abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+".npy").reshape(1, 588)
    # mean_x = np.load('data_6/mean_x'+args.train[0]+".npy").reshape(1, 588)
    # std_x = np.load('data_6/std_x'+args.train[0]+".npy").reshape(1, 588)
    # abs_v_xnn = np.load("data_6/abs_v_xnn05_24-07_18.npy").reshape(1, 59)
    # mean_xnn = np.load('data_6/mean_xnn05_24-07_18.npy').reshape(1, 59)
    # std_xnn = np.load('data_6/std_xnn05_24-07_18.npy').reshape(1, 59)

    
    # abs_v_x = np.load('data_6/abs_v_x05_24-07_18.npy').reshape(1, 588)
    # mean_x = np.load('data_6/mean_x05_24-07_18.npy').reshape(1, 588)
    # std_x = np.load('data_6/std_x05_24-07_18.npy').reshape(1, 588)


    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)


    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x ], axis=1))
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
    print(abs_v.shape, mean.shape, std.shape)

    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            x_i = np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            x_l.append(x_i)
            print(day)
        return x_l

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0)-args.T+1)
        return x_l

    length_list = []
    for i in range(len(args.train)):
        length_list += load_data_length(args.train[i], "y") 
    length_list2 = []
    for i in range(len(args.test)):
        length_list2 += load_data_length(args.test[i], "y") 
    y_length_list = length_list2
    xnn = load_data(args.train[0], "xnn")
    xnn2 = load_data(args.test[0], "xnn")
    x = load_data(args.train[0], "x")
    x2 = load_data(args.test[0], "x")
    
    if args.y == "0":
        y = load_data(args.train[0], "y") 
        y2 = load_data(args.test[0], "y")
    elif args.y == "3":
        y = load_data(args.train[0], "y3")
        y2 = load_data(args.test[0], "y3")
    elif args.y == "4":
        y = load_data(args.train[0], "y4")
        y2 = load_data(args.test[0], "y4")
    train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y = [(x, xnn), y, (x, xnn), y, (x2, xnn2), y2]

elif args.old == 13:
    index_all = []
    for i in range(647):
        if i != 34 and i != 35:
            index_all.append(i)
    print(index_all)
    # abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+".npy").reshape(1, 59)
    # mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+".npy").reshape(1, 59)
    # std_xnn = np.load('data_6/std_xnn'+args.train[0]+".npy").reshape(1, 59)

    # abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+".npy").reshape(1, 588)
    # mean_x = np.load('data_6/mean_x'+args.train[0]+".npy").reshape(1, 588)
    # std_x = np.load('data_6/std_x'+args.train[0]+".npy").reshape(1, 588)
    # abs_v_xnn = np.load("data_6/abs_v_xnn05_24-07_18.npy").reshape(1, 59)
    # mean_xnn = np.load('data_6/mean_xnn05_24-07_18.npy').reshape(1, 59)
    # std_xnn = np.load('data_6/std_xnn05_24-07_18.npy').reshape(1, 59)

    # abs_v_x = np.load('data_6/abs_v_x05_24-07_18.npy').reshape(1, 588)
    # mean_x = np.load('data_6/mean_x05_24-07_18.npy').reshape(1, 588)
    # std_x = np.load('data_6/std_x05_24-07_18.npy').reshape(1, 588)

    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)
    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
    print(abs_v.shape, mean.shape, std.shape)

    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            x_i = np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            x_l.append(x_i)
            print(day)
        return x_l

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0)-args.T+1)
        return x_l

    length_list = []
    for i in range(len(args.train)):
        length_list += load_data_length(args.train[i], "y") 
    length_list2 = []
    for i in range(len(args.test)):
        length_list2 += load_data_length(args.test[i], "y") 
    y_length_list = length_list2
    # xnn = load_data(args.train[0], "xnn")
    # xnn2 = load_data(args.test[0], "xnn")
    # x = load_data(args.train[0], "x")
    # x2 = load_data(args.test[0], "x")
    
    # if args.y == "0":
    #     y = load_data(args.train[0], "y") 
    #     y2 = load_data(args.test[0], "y")
    # elif args.y == "3":
    #     y = load_data(args.train[0], "y3")
    #     y2 = load_data(args.test[0], "y3")
    # elif args.y == "4":
    #     y = load_data(args.train[0], "y4")
    #     y2 = load_data(args.test[0], "y4")
    # train_data_X, train_data_y, val_data_X, val_data_y, test_data_X, test_data_y = [(x, xnn), y, (x, xnn), y, (x2, xnn2), y2]


elif args.old == 14:
    print("train, test", args.train, args.test)
    index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    print(abs_v_xnn, mean_xnn, std_xnn)

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)
    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1)).float()
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1)).float()
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1)).float()
    if args.only_xnn:
        abs_v = abs_v_xnn
        mean = mean_xnn
        std = std_xnn

elif args.old == 15:
    if args.use_p23 != 6:
        if args.use_p23 == 3:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        elif args.use_p23 == 4:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]
        elif args.use_p23 == 5:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
        elif args.use_p23 == 7:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]


        # abs_v_xnn = np.load("data_6/abs_v_xnn05_24-07_18.npy").reshape(1, 59)[:, index_all]
        # mean_xnn = np.load('data_6/mean_xnn05_24-07_18.npy').reshape(1, 59)[:, index_all]
        # std_xnn = np.load('data_6/std_xnn05_24-07_18.npy').reshape(1, 59)[:, index_all]

        
        # abs_v_x = np.load('data_6/abs_v_x05_24-07_18.npy').reshape(1, 588)
        # mean_x = np.load('data_6/mean_x05_24-07_18.npy').reshape(1, 588)
        # std_x = np.load('data_6/std_x05_24-07_18.npy').reshape(1, 588)

        abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)


        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
    else:
        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

        abs_v = torch.from_numpy(abs_v_x)
        mean = torch.from_numpy(mean_x)
        std = torch.from_numpy(std_x)
    print(abs_v.shape, mean.shape, std.shape)
    y_length_list = 1

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1
    if args.use_p23 != 6:
        # xnn = load_data(args.train[0], "xnn")
        xnn2 = load_data(args.test[0], "xnn")[:, index_all]
        # x = load_data(args.train[0], "x")
        x2 = load_data(args.test[0], "x")
        x2 = torch.cat([xnn2, x2], dim=1)
        print(x2.size())
    else:
        x2 = load_data(args.test[0], "x")
        
    if args.y == "0":
        # y = load_data(args.train[0], "y") 
        y2 = load_data(args.test[0], "y")
    elif args.y == "3":
        # y = load_data(args.train[0], "y3")
        y2 = load_data(args.test[0], "y3")
    elif args.y == "4":
        # y = load_data(args.train[0], "y4")
        y2 = load_data(args.test[0], "y4")

elif args.old == 16:
    print("train, test", args.train, args.test)

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    print(y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    y_length_list_2 = []
    for i in range(len(args.test2)):
        y_length_list_2 += load_data_length(args.test2[i], "y") 
    print("y_length_list_2", y_length_list_2)
    print(y_length_list_2)
    y_length_list_2[-1] = y_length_list_2[-1]-args.T+1

    x = torch.cat([load_data(args.train[i], args.x) for i in range(len(args.train))], dim=0)
    x2 = torch.cat([load_data(args.test[i], args.x) for i in range(len(args.test))], dim=0)
    x3 = torch.cat([load_data(args.test2[i], args.x) for i in range(len(args.test2))], dim=0)
    if args.y == "0":
        y = torch.cat([load_data(args.train[i], "y") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y") for i in range(len(args.test))], dim=0)
        y3 = torch.cat([load_data(args.test2[i], "y") for i in range(len(args.test2))], dim=0)
    elif args.y == "3":
        y = torch.cat([load_data(args.train[i], "y3") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y3") for i in range(len(args.test))], dim=0)
        y3 = torch.cat([load_data(args.test2[i], "y3") for i in range(len(args.test2))], dim=0)
    elif args.y == "4":
        y = torch.cat([load_data(args.train[i], "y4") for i in range(len(args.train))], dim=0)
        y2 = torch.cat([load_data(args.test[i], "y4") for i in range(len(args.test))], dim=0)
        y3 = torch.cat([load_data(args.test2[i], "y4") for i in range(len(args.test2))], dim=0)
    print(x.shape, x2.shape, x3.shape, y.shape, y2.shape, y3.shape)
    # x = torch.from_numpy(x)[:, :-2]
    ori_x2 = x2.clone()
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    x2 = (x2/abs_v)
    x3 = x3/abs_v
    mean, std = x.mean(0), x.std(0)
    train_data_X, train_data_y = x, y

elif args.old == 17:
    if args.use_p23 != 6:
        if args.use_p23 == 3:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        elif args.use_p23 == 4:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]
        elif args.use_p23 == 5:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
        elif args.use_p23 == 7:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]


        # abs_v_xnn = np.load("data_6/abs_v_xnn05_24-07_18.npy").reshape(1, 59)[:, index_all]
        # mean_xnn = np.load('data_6/mean_xnn05_24-07_18.npy').reshape(1, 59)[:, index_all]
        # std_xnn = np.load('data_6/std_xnn05_24-07_18.npy').reshape(1, 59)[:, index_all]

        
        # abs_v_x = np.load('data_6/abs_v_x05_24-07_18.npy').reshape(1, 588)
        # mean_x = np.load('data_6/mean_x05_24-07_18.npy').reshape(1, 588)
        # std_x = np.load('data_6/std_x05_24-07_18.npy').reshape(1, 588)

        abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)


        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
    else:
        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

        abs_v = torch.from_numpy(abs_v_x)
        mean = torch.from_numpy(mean_x)
        std = torch.from_numpy(std_x)
    print(abs_v.shape, mean.shape, std.shape)

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def load_data_length(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            print(day, day.month, day.day)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).size(0))
        return x_l
    y_length_list = []
    for i in range(len(args.test)):
        y_length_list += load_data_length(args.test[i], "y") 
    print("y_length_list", y_length_list)
    y_length_list[-1] = y_length_list[-1]-args.T+1

    y_length_list_2 = []
    for i in range(len(args.test2)):
        y_length_list_2 += load_data_length(args.test2[i], "y") 
    print("y_length_list_2", y_length_list_2)
    y_length_list_2[-1] = y_length_list_2[-1]-args.T+1
    if args.use_p23 != 6:
        # xnn = load_data(args.train[0], "xnn")
        xnn2 = load_data(args.test[0], "xnn")[:, index_all]
        # x = load_data(args.train[0], "x")
        x2 = load_data(args.test[0], "x")
        x2 = torch.cat([xnn2, x2], dim=1)
        print(x2.size())

        xnn3 = load_data(args.test2[0], "xnn")[:, index_all]
        # x = load_data(args.train[0], "x")
        x3 = load_data(args.test2[0], "x")
        x3 = torch.cat([xnn3, x3], dim=1)
        print(x2.size())
    else:
        x2 = load_data(args.test[0], "x")
        x3 = load_data(args.test2[0], "x")
        
    if args.y == "0":
        # y = load_data(args.train[0], "y") 
        y2 = load_data(args.test[0], "y")
        y3 = load_data(args.test2[0], "y")
    elif args.y == "3":
        # y = load_data(args.train[0], "y3")
        y2 = load_data(args.test[0], "y3")
        y3 = load_data(args.test2[0], "y3")
    elif args.y == "4":
        # y = load_data(args.train[0], "y4")
        y2 = load_data(args.test[0], "y4")
        y3 = load_data(args.test2[0], "y4")
    noise_mask = torch.load("noise_mask_"+str(args.masking_ratio)+"_2.pt")


elif args.old == 18:
    temp_date = args.train[0]
    if args.train[0] == "07_01-08_10":
        args.train[0] = "07_01-08_11"
    if args.use_p23 == 13:
        print(np.load('data_6/abs_v_xnn6'+";".join(args.train)+'.npy').shape)
        abs_v_xnn = np.load('data_6/abs_v_xnn6'+";".join(args.train)+'.npy').reshape(1, -1)[:, :33]
        mean_xnn = np.load('data_6/mean_xnn6'+";".join(args.train)+'.npy').reshape(1, -1)[:, :33]
        std_xnn = np.load('data_6/std_xnn6'+";".join(args.train)+'.npy').reshape(1, -1)[:, :33]

        abs_v_x = np.load('data_6/abs_v_x3'+";".join(args.train)+'.npy').reshape(1, 568)
        mean_x = np.load('data_6/mean_x3'+";".join(args.train)+'.npy').reshape(1, 568)
        std_x = np.load('data_6/std_x3'+";".join(args.train)+'.npy').reshape(1, 568)

        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
        print(torch.isnan(abs_v).sum(), torch.isnan(mean).sum(), torch.isnan(std).sum(), torch.sum(abs_v==0), torch.nonzero(std==0))
    elif args.use_p23 == 12:
        abs_v_xnn = np.load('data_6/abs_v_xnn5'+";".join(args.train)+'.npy').reshape(1, 33)
        mean_xnn = np.load('data_6/mean_xnn5'+";".join(args.train)+'.npy').reshape(1, 33)
        std_xnn = np.load('data_6/std_xnn5'+";".join(args.train)+'.npy').reshape(1, 33)

        abs_v_x = np.load('data_6/abs_v_x2'+";".join(args.train)+'.npy').reshape(1, 568)
        mean_x = np.load('data_6/mean_x2'+";".join(args.train)+'.npy').reshape(1, 568)
        std_x = np.load('data_6/std_x2'+";".join(args.train)+'.npy').reshape(1, 568)

        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
    elif args.use_p23 == 11 or args.use_p23 == 100:
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]
        index_x = []
        for i in range(621):
            if i not in [30, 53, 54, 55, 56, 77, 78, 79, 80, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512]:
                index_x.append(i)
        abs_v_xnn = np.load('data_6/abs_v_xnn'+";".join(args.train)+'.npy').reshape(1, 59)[:, index_all]
        mean_xnn = np.load('data_6/mean_xnn'+";".join(args.train)+'.npy').reshape(1, 59)[:, index_all]
        std_xnn = np.load('data_6/std_xnn'+";".join(args.train)+'.npy').reshape(1, 59)[:, index_all]

        abs_v_x = np.load('data_6/abs_v_x'+";".join(args.train)+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+";".join(args.train)+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+";".join(args.train)+'.npy').reshape(1, 588)

        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))[:, index_x]
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))[:, index_x]
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))[:, index_x]
    elif args.use_p23 != 6:
        if args.use_p23 == 3:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        elif args.use_p23 == 4:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]
        elif args.use_p23 == 5:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
        elif args.use_p23 == 7 or args.use_p23 == 100:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]

        index_xabs = [i for i in range(139, 278)] + [i for i in range(417, 695)]

        abs_v_xnn = np.load('data_6/abs_v_xnn'+";".join(args.train)+'.npy').reshape(1, 59)[:, index_all]
        mean_xnn = np.load('data_6/mean_xnn'+";".join(args.train)+'.npy').reshape(1, 59)[:, index_all]
        std_xnn = np.load('data_6/std_xnn'+";".join(args.train)+'.npy').reshape(1, 59)[:, index_all]

        abs_v_x = np.load('data_6/abs_v_x'+";".join(args.train)+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+";".join(args.train)+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+";".join(args.train)+'.npy').reshape(1, 588)


        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
    else:
        abs_v_x = np.load('data_6/abs_v_x'+";".join(args.train)+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+";".join(args.train)+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+";".join(args.train)+'.npy').reshape(1, 588)

        abs_v = torch.from_numpy(abs_v_x)
        mean = torch.from_numpy(mean_x)
        std = torch.from_numpy(std_x)
    print(abs_v.shape, mean.shape, std.shape)

    
    lent = str(abs_v.size(1))
    np.save('data_6/abs_v_x_'+lent+"_"+";".join(args.train), abs_v)
    np.save('data_6/mean_x_'+lent+"_"+";".join(args.train), mean)
    np.save('data_6/std_x_'+lent+"_"+";".join(args.train), std)
    # noise_mask = torch.load("noise_mask_"+str(args.masking_ratio)+"_2.pt")
    if temp_date == "07_01-08_10":
        args.train[0] = temp_date

elif args.old == 19:
    abs_v_x = np.load('data_6/abs_v_x05_24-07_18.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x05_24-07_18.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x05_24-07_18.npy').reshape(1, 588)

    abs_v = torch.from_numpy(abs_v_x)
    mean = torch.from_numpy(mean_x)
    std = torch.from_numpy(std_x)
    print(abs_v.shape, mean.shape, std.shape)

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    data_x = load_data(args.train[0], "x")
    if args.y == "0":
        data_y = load_data(args.train[0], "y")
    elif args.y == "3":
        data_y = load_data(args.train[0], "y3")
    elif args.y == "4":
        data_y = load_data(args.train[0], "y4")
    x = data_x[:int(14/15*data_x.size(0))]
    x2 = data_x[int(14/15*data_x.size(0)):]
    y = data_y[:int(14/15*data_y.size(0))]
    y2 = data_y[int(14/15*data_y.size(0)):]
    y_length_list = [y2.size(0)-args.T+1]
    y_length_list_2 = []
    # x3 = load_data(args.test2[0], "x")
    # if args.y == "0":
    #     y3 = load_data(args.test2[0], "y")
    # elif args.y == "3":
    #     y3 = load_data(args.test2[0], "y3")
    # elif args.y == "4":
    #     y3 = load_data(args.test2[0], "y4")

    # def load_data_length(date_list, tp):
    #     start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    #     print(start_month, start_day, end_month, end_day)
    #     start = datetime.date(2022,start_month,start_day)
    #     end = datetime.date(2022,end_month,end_day)
    #     x_l = []
    #     print(start, end)
    #     for i in range((end-start).days+1):
    #         day = start + datetime.timedelta(days=i)
    #         print(day, day.month, day.day)
    #         month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
    #         day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
    #         with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
    #             x_l.append(torch.from_numpy(np.load(f)).size(0))
    #     return x_l
    # y_length_list_2 = []
    # for i in range(len(args.test2)):
    #     y_length_list_2 += load_data_length(args.test2[i], "y") 
    # print("y_length_list_2", y_length_list_2)
    # y_length_list_2[-1] = y_length_list_2[-1]-args.T+1
elif args.old == 20:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]

    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    noise_mask = torch.load("noise_mask_0.5_2.pt")

elif args.old == 21:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    # y0 = np.load("profit_l_08_11-09_05_57_6_fullpredictchange.npy")
    y0 = np.load(args.rl_profit_path)
    abs_profit = np.max(np.abs(y0))
    y = (y0/abs_profit)
    exist = (y != 0)
    # mean_profit = y[exist].mean()
    # std_profit = y[exist].std()
    # y[exist] = (y[exist]-mean_profit)/std_profit

    mean_profit = y.mean()
    std_profit = y.std()
    y = (y-mean_profit)/std_profit
    # while (True):
    #     arr = np.arange(y0.shape[0])
    #     np.random.shuffle(arr)
    #     y3 = torch.from_numpy(y0[arr[11000000:]]).cuda()
    #     y1 = torch.from_numpy(y0[arr]).cuda()
    #     succ = True
    #     for j in range(0, 6):
    #         m = torch.sum(y3[:, 0]).item()*len(arr)/11000000 - torch.sum(y1[:, 0]).item()
    #         print("d, ", j, torch.sum(y3[:, j]).item(), torch.sum(y1[:, j]).item())
    #     if abs(m) > 0.1:
    #         succ = False
    #     if succ:
    #         break
    


    arr = np.load("arr.npy")
    y3 = torch.from_numpy(y0[arr[11000000:]]).cuda()
    y1 = torch.from_numpy(y0).cuda()
    for j in range(0, 6):
        print("d, ", j, torch.sum(y3[:, j]).item(), torch.sum(y1[:, j]).item())
    print(x.size(), y.shape)
    print(abs_profit, mean_profit, std_profit)
    vari = torch.var_mean(torch.from_numpy(y), dim=0, unbiased=False)[0].cuda().reshape(1, y1.size(1))
    print("what is var", vari, vari.size())

elif args.old == 23:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.test2[i], "xnn") for i in range(len(args.test2))], dim=0)[:, index]
    # abs_v = x.abs().max(0)[0]
    # abs_v[abs_v==0] = 1
    # x = (x/abs_v)
    # mean = x.mean(0)
    # std = x.std(0)
    abs_v = np.load('abs_v'+";".join(args.train)+'.npy')
    mean = np.load('mean'+";".join(args.train)+'.npy')
    std = np.load('std'+";".join(args.train)+'.npy')
    print("load from computed")
    x = (x/abs_v)
    # with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
    #     np.save(f, abs_v.detach().cpu().double().numpy())
    # with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
    #     np.save(f, mean.detach().cpu().double().numpy())
    # with open('std'+";".join(args.train)+'.npy', 'wb') as f:
    #     np.save(f, std.detach().cpu().double().numpy())
    y0 = np.load(args.rl_profit_path)
    abs_profit = np.max(np.abs(y0))
    y = (y0/abs_profit)
    exist = (y != 0)
    mean_profit = y.mean()
    std_profit = y.std()
    y = (y-mean_profit)/std_profit
    arr = None
    y1 = torch.from_numpy(y).cuda()
    for j in range(0, 6):
        print("d, ", j, np.sum(y0[:, j]), torch.var_mean(y1[:, j], unbiased=False))

    vari = torch.var_mean(y1, dim=0, unbiased=False)[0].cuda().reshape(1, y1.size(1))
    print("what is var", vari)



elif args.old == 22:
    if args.use_p23 != 6:
        if args.use_p23 == 3:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        elif args.use_p23 == 4:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33]
        elif args.use_p23 == 5:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
        elif args.use_p23 == 7:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]

        abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)


        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
    else:
        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

        abs_v = torch.from_numpy(abs_v_x)
        mean = torch.from_numpy(mean_x)
        std = torch.from_numpy(std_x)
    print(abs_v.shape, mean.shape, std.shape)

    
    lent = str(abs_v.size(1))
    np.save('data_6/abs_v_x_'+lent+"_"+args.train[0], abs_v)
    np.save('data_6/mean_x_'+lent+"_"+args.train[0], mean)
    np.save('data_6/std_x_'+lent+"_"+args.train[0], std)
    noise_mask = torch.load("noise_mask_"+str(args.masking_ratio)+"_2.pt")

elif args.old == 24:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.test2[i], "xnn") for i in range(len(args.test2))], dim=0)[:, index]
    abs_v = np.load('abs_v'+";".join(args.train)+'.npy')
    mean = np.load('mean'+";".join(args.train)+'.npy')
    std = np.load('std'+";".join(args.train)+'.npy')
    x = (x/abs_v)
    y0 = np.load(args.rl_profit_path)
    abs_profit = np.max(np.abs(y0))
    y = (y0/abs_profit)
    exist = (y != 0)
    mean_profit = y.mean()
    std_profit = y.std()
    y = (y-mean_profit)/std_profit

    y0_ = np.load(args.rl_profit_path2)
    abs_profit_ = np.max(np.abs(y0_))
    y_ = (y0_/abs_profit_)
    exist_ = (y_ != 0)
    mean_profit_ = y_.mean()
    std_profit_ = y_.std()
    y_ = (y_-mean_profit_)/std_profit_
    arr = None
    y1 = torch.from_numpy(y).cuda()
    y2 = torch.from_numpy(y_).cuda()
    for j in range(0, 6):
        print("d, ", j, np.sum(y0[:, j]), torch.var_mean(y1[:, j], unbiased=False))
        print("d, ", j, np.sum(y0_[:, j]), torch.var_mean(y2[:, j], unbiased=False))

    vari = torch.var_mean(y1, dim=0, unbiased=False)[0].cuda().reshape(1, y1.size(1))
    vari_ = torch.var_mean(y2, dim=0, unbiased=False)[0].cuda().reshape(1, y2.size(1))

    print("what is var", vari, vari_)

elif args.old == 28:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.test2[i], "xnn") for i in range(len(args.test2))], dim=0)[:, index]
    abs_v = np.load('abs_v'+";".join(args.train)+'.npy')
    mean = np.load('mean'+";".join(args.train)+'.npy')
    std = np.load('std'+";".join(args.train)+'.npy')
    x = (x/abs_v)

elif args.old == 25:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    y0 = np.load(args.rl_profit_path)
    abs_profit = np.max(np.abs(y0))
    y = (y0/abs_profit)
    exist = (y != 0)

    mean_profit = y.mean()
    std_profit = y.std()
    y = (y-mean_profit)/std_profit
    arr = np.load("arr.npy")
    y3 = torch.from_numpy(y0[arr[11000000:]]).cuda()
    y1 = torch.from_numpy(y0).cuda()

    y0_ = np.load(args.rl_profit_path2)
    abs_profit_ = np.max(np.abs(y0_))
    y_ = (y0_/abs_profit_)
    exist_ = (y_ != 0)
    mean_profit_ = y_.mean()
    std_profit_ = y_.std()
    y_ = (y_-mean_profit_)/std_profit_
    y2 = torch.from_numpy(y_).cuda()
    for j in range(0, 7):
        print("d, ", j, np.sum(y0[:, j]), torch.var_mean(y1[:, j], unbiased=False))
        print("d, ", j, np.sum(y0_[:, j]), torch.var_mean(y2[:, j], unbiased=False))
        print("d, ", j, torch.sum(y3[:, j]).item(), torch.var_mean(y3[:, j], unbiased=False))
    vari = torch.var_mean(torch.from_numpy(y), dim=0, unbiased=False)[0].cuda().reshape(1, y1.size(1))
    vari_ = torch.var_mean(y2, dim=0, unbiased=False)[0].cuda().reshape(1, y2.size(1))

    print("what is var", vari, vari.size())
    print(abs_profit, mean_profit, std_profit, abs_profit_, mean_profit_, std_profit_)

elif args.old == 26:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())

    valid_point = np.load(args.valid_point)
    valid_point_train = np.load(args.valid_point_train)
    valid_point_valid = np.load(args.valid_point_valid)
    

    print(abs_v, mean, std)
    y0 = np.load(args.rl_profit_path)
    abs_profit = np.max(np.abs(y0))
    # abs_profit = 1
    y = (y0/abs_profit)
    exist = (y != 0)
    print(y.shape, valid_point.shape, np.take(y, valid_point, axis=0), np.take(y, valid_point, axis=0).shape)
    print(valid_point, y[valid_point, :])
    print(y[valid_point, :].shape)
    mean_profit = y[valid_point, :].mean()
    std_profit = y[valid_point, :].std()
    # mean_profit, std_profit = 0, 1
    y[valid_point, :] = (y[valid_point, :]-mean_profit)/std_profit

    

    arr = np.load("arr.npy")
    y3 = torch.from_numpy(y0[arr[11000000:]]).cuda()
    y1 = torch.from_numpy(y0).cuda()

    for j in range(0, 7):
        print("d, ", j, np.sum(y0[:, j]), torch.var_mean(y1[:, j], unbiased=False))
        print("d, ", j, torch.sum(y3[:, j]).item(), torch.var_mean(y3[:, j], unbiased=False))
    vari = torch.var_mean(torch.from_numpy(y), dim=0, unbiased=False)[0].cuda().reshape(1, y1.size(1))

    print("what is var", vari, vari.size())
    print(abs_profit, mean_profit, std_profit)

elif args.old == 27:
    if args.use_p23 != 9:
        if args.use_p23 == 7:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]
        else:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]

        index_xabs = [i for i in range(139, 278)] + [i for i in range(417, 695)]

        abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

        abs_v_xabs = np.load('data_6/abs_v_xabs'+args.train[0]+'.npy').reshape(1, 695)[:, index_xabs]
        mean_xabs = np.load('data_6/mean_xabs'+args.train[0]+'.npy').reshape(1, 695)[:, index_xabs]
        std_xabs = np.load('data_6/std_xabs'+args.train[0]+'.npy').reshape(1, 695)[:, index_xabs]


        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x, abs_v_xabs], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x, mean_xabs], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x, std_xabs], axis=1))
        print(abs_v.shape, mean.shape, std.shape)

        
        lent = str(abs_v.size(1))
        np.save('data_6/abs_v_x_'+lent+"_"+args.train[0], abs_v)
        np.save('data_6/mean_x_'+lent+"_"+args.train[0], mean)
        np.save('data_6/std_x_'+lent+"_"+args.train[0], std)
    else:
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]

        abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
        std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

        abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

        abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
        mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
        std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))
        print(abs_v.shape, mean.shape, std.shape)

        lent = str(abs_v.size(1))
        np.save('data_6/abs_v_x_'+lent+"_"+args.train[0], abs_v)
        np.save('data_6/mean_x_'+lent+"_"+args.train[0], mean)
        np.save('data_6/std_x_'+lent+"_"+args.train[0], std)

elif args.old == 29:
    index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]

    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))

    lent = str(abs_v.size(1))
    np.save('data_6/abs_v_x_'+lent+"_"+args.train[0], abs_v)
    np.save('data_6/mean_x_'+lent+"_"+args.train[0], mean)
    np.save('data_6/std_x_'+lent+"_"+args.train[0], std)
    y0 = np.load(args.rl_profit_path+"_123.npy")

    abs_profit = np.max(np.abs(y0))
    y = (y0/abs_profit)
    exist = (y != 0)
    mean_profit = y.mean()
    std_profit = y.std()
    y = (y-mean_profit)/std_profit
    y1 = torch.from_numpy(y0).cuda()

    y0_ = np.load(args.rl_profit_path2+"_123.npy")
    y_ = (y0_/abs_profit-mean_profit)/std_profit
    y2 = torch.from_numpy(y0_).cuda()
    for j in range(0, 7):
        print("d, ", j, np.sum(y0[:, j]), torch.var_mean(y1[:, j], unbiased=False))
        print("d, ", j, np.sum(y0_[:, j]), torch.var_mean(y2[:, j], unbiased=False))
    vari = torch.var_mean(y1, dim=0, unbiased=False)[0].cuda().reshape(1, y1.size(1))
    vari_ = torch.var_mean(y2, dim=0, unbiased=False)[0].cuda().reshape(1, y2.size(1))


elif args.old == 30:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)
    x2 = (x2/abs_v)
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    y0 = np.load(args.rl_profit_path+"_12.npy")
    abs_profit = np.max(np.abs(y0))
    y = (y0/abs_profit)
    exist = (y != 0)

    mean_profit = y.mean()
    std_profit = y.std()
    y = (y-mean_profit)/std_profit
    y = y0
    y0_ = np.load(args.rl_profit_path2+"_12.npy")

    y2 = (y0_/abs_profit-mean_profit)/std_profit
    y2 = y0_
    yy1 = torch.from_numpy(y0).cuda()
    yy2 = torch.from_numpy(y0_).cuda()
    for j in range(0, 7):
        print("d, ", j, np.sum(y0[:, j]), torch.var_mean(yy1[:, j], unbiased=False))
        print("d, ", j, np.sum(y0_[:, j]), torch.var_mean(yy2[:, j], unbiased=False))
    vari = torch.var_mean(yy1, dim=0, unbiased=False)[0].cuda().reshape(1, yy1.size(1))
    vari_ = torch.var_mean(yy2, dim=0, unbiased=False)[0].cuda().reshape(1, yy2.size(1))

elif args.old == 31:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)
    x2 = (x2/abs_v)
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    y0 = np.load(args.rl_profit_path+"_12.npy")
    abs_profit = np.max(np.abs(y0))
    y = (y0/abs_profit)
    exist = (y != 0)
    valid_point_train = np.load(args.valid_point_train)
    valid_point_valid = np.load(args.valid_point_valid)
    valid_point = valid_point_train
    mean_profit = y[valid_point, :].mean()
    std_profit = y[valid_point, :].std()
    # mean_profit, std_profit = 0, 1
    y[valid_point, :] = (y[valid_point, :]-mean_profit)/std_profit
    # mean_profit = y.mean()
    # std_profit = y.std()
    # y = (y-mean_profit)/std_profit
    # y = y0
    y0_ = np.load(args.rl_profit_path2+"_12.npy")

    y2 = (y0_/abs_profit-mean_profit)/std_profit
    print(y2[:, -1])

    # y2 = y0_
    yy1 = torch.from_numpy(y0).cuda()
    yy2 = torch.from_numpy(y0_).cuda()
    for j in range(0, 7):
        print("d, ", j, np.sum(y0[:, j]), torch.var_mean(yy1[:, j], unbiased=False))
        print("d, ", j, np.sum(y0_[:, j]), torch.var_mean(yy2[:, j], unbiased=False))
    vari = torch.var_mean(yy1, dim=0, unbiased=False)[0].cuda().reshape(1, yy1.size(1))
    vari_ = torch.var_mean(yy2, dim=0, unbiased=False)[0].cuda().reshape(1, yy2.size(1))

elif args.old == 32:
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    x3 = torch.cat([load_data(args.test2[i], "xnn") for i in range(len(args.test2))], dim=0)[:, index]
    x4 = torch.cat([load_data(args.test4[i], "xnn") for i in range(len(args.test4))], dim=0)[:, index]

    
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)
    

    x2 = (x2/abs_v)
    x3 = (x3/abs_v)
    x4 = (x4/abs_v)
    # x2_seg = x2[829607:829612]
    # xin2_seg = ((x2_seg/abs_v-mean)/std)
    # print(xin2_seg)

    # np.save("xin2_seg.npy", xin2_seg)
    # np.save("x2_seg.npy", x2_seg)
    
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    if args.lag == 2:
        y01 = np.load(args.rlbuy_profit_path+"_12.npy")
        y02 = np.load(args.rlsell_profit_path+"_12.npy")
    elif args.lag == 1:
        y01 = np.load(args.rlbuy_profit_path+"_1.npy")
        y02 = np.load(args.rlsell_profit_path+"_1.npy")
        

    abs_profit = max(np.max(np.abs(y01)), np.max(np.abs(y02)))
    y01_divabs = y01
    y02_divabs = y02

    exist = (y01_divabs != 0)
    valid_buypoint_train = np.load(args.valid_buypoint_train)
    valid_sellpoint_train = np.load(args.valid_sellpoint_train)
    valid_buypoint = valid_buypoint_train
    valid_sellpoint = valid_sellpoint_train
    valid_point_train = list(set(valid_buypoint_train.flatten()).union(set(valid_sellpoint_train.flatten())))
    valid_point_train.sort()
    valid_point_train = np.array(valid_point_train)
    if args.norm_y:
        if args.train_all_data:
            y01_divabs = (y01/abs_profit)
            y02_divabs = (y02/abs_profit)
            mean_profit = np.concatenate([y01_divabs, y02_divabs], axis=0).mean()
            std_profit = np.concatenate([y01_divabs, y02_divabs], axis=0).std()
            y01_divabs = (y01_divabs-mean_profit)/std_profit
            y02_divabs = (y02_divabs-mean_profit)/std_profit

        else:
            y01_divabs = (y01/abs_profit)
            y02_divabs = (y02/abs_profit)
            mean_profit = np.concatenate([y01_divabs[valid_point_train, :], y02_divabs[valid_point_train, :]], axis=0).mean()
            std_profit = np.concatenate([y01_divabs[valid_point_train, :], y02_divabs[valid_point_train, :]], axis=0).std()
            # mean_profit, std_profit = 0, 1
            y01_divabs[valid_point_train, :] = (y01_divabs[valid_point_train, :]-mean_profit)/std_profit
            y02_divabs[valid_point_train, :] = (y02_divabs[valid_point_train, :]-mean_profit)/std_profit



    # mean_profit = y.mean()
    # std_profit = y.std()
    # y = (y-mean_profit)/std_profit
    # y = y0
    y01_ = np.load(args.rlbuy_profit_path2+"_12.npy")
    y02_ = np.load(args.rlsell_profit_path2+"_12.npy")
    valid_buypoint_valid = np.load(args.valid_buypoint_valid)
    valid_sellpoint_valid = np.load(args.valid_sellpoint_valid)
    valid_point_val = list(set(valid_buypoint_valid.flatten()).union(set(valid_sellpoint_valid.flatten())))
    valid_point_val.sort()
    valid_point_val = np.array(valid_point_val)
    y01_divabs_ = y01_
    y02_divabs_ = y02_
    if args.norm_y:
        if args.train_all_data:
            y01_divabs_ = y01_/abs_profit
            y02_divabs_ = y02_/abs_profit
            y01_divabs_ = (y01_divabs_-mean_profit)/std_profit
            y02_divabs_ = (y02_divabs_-mean_profit)/std_profit
        else:
            y01_divabs_ = y01_/abs_profit
            y02_divabs_ = y02_/abs_profit
            y01_divabs_[valid_point_val, :] = (y01_divabs_[valid_point_val, :]-mean_profit)/std_profit
            y02_divabs_[valid_point_val, :] = (y02_divabs_[valid_point_val, :]-mean_profit)/std_profit

    y0 = None
    y2 = None
    vari = None

elif args.old == 33:

    index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]

    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))

    lent = str(abs_v.size(1))
    np.save('data_6/abs_v_x_'+lent+"_"+args.train[0], abs_v)
    np.save('data_6/mean_x_'+lent+"_"+args.train[0], mean)
    np.save('data_6/std_x_'+lent+"_"+args.train[0], std)

    y01 = np.load(args.rlbuy_profit_path+"_12.npy")
    y02 = np.load(args.rlsell_profit_path+"_12.npy")
    print(y01.shape)

    abs_profit = max(np.max(np.abs(y01)), np.max(np.abs(y02)))
    y01_divabs = y01
    y02_divabs = y02

    exist = (y01_divabs != 0)
    valid_buypoint_train = np.load(args.valid_buypoint_train)
    valid_sellpoint_train = np.load(args.valid_sellpoint_train)
    valid_buypoint = valid_buypoint_train
    valid_sellpoint = valid_sellpoint_train
    valid_point_train = list(set(valid_buypoint_train.flatten()).union(set(valid_sellpoint_train.flatten())))
    valid_point_train.sort()
    valid_point_train = np.array(valid_point_train)
    if args.norm_y:
        if args.train_all_data:
            y01_divabs = (y01/abs_profit)
            y02_divabs = (y02/abs_profit)
            mean_profit = np.concatenate([y01_divabs, y02_divabs], axis=0).mean()
            std_profit = np.concatenate([y01_divabs, y02_divabs], axis=0).std()
            y01_divabs = (y01_divabs-mean_profit)/std_profit
            y02_divabs = (y02_divabs-mean_profit)/std_profit

        else:
            y01_divabs = (y01/abs_profit)
            y02_divabs = (y02/abs_profit)
            mean_profit = np.concatenate([y01_divabs[valid_point_train, :], y02_divabs[valid_point_train, :]], axis=0).mean()
            std_profit = np.concatenate([y01_divabs[valid_point_train, :], y02_divabs[valid_point_train, :]], axis=0).std()
            # mean_profit, std_profit = 0, 1
            y01_divabs[valid_point_train, :] = (y01_divabs[valid_point_train, :]-mean_profit)/std_profit
            y02_divabs[valid_point_train, :] = (y02_divabs[valid_point_train, :]-mean_profit)/std_profit



    # mean_profit = y.mean()
    # std_profit = y.std()
    # y = (y-mean_profit)/std_profit
    # y = y0
    y01_ = np.load(args.rlbuy_profit_path2+"_12.npy")
    y02_ = np.load(args.rlsell_profit_path2+"_12.npy")
    valid_buypoint_valid = np.load(args.valid_buypoint_valid)
    valid_sellpoint_valid = np.load(args.valid_sellpoint_valid)
    valid_point_val = list(set(valid_buypoint_valid.flatten()).union(set(valid_sellpoint_valid.flatten())))
    valid_point_val.sort()
    valid_point_val = np.array(valid_point_val)
    y01_divabs_ = y01_
    y02_divabs_ = y02_
    if args.norm_y:
        if args.train_all_data:
            y01_divabs_ = y01_/abs_profit
            y02_divabs_ = y02_/abs_profit
            y01_divabs_ = (y01_divabs_-mean_profit)/std_profit
            y02_divabs_ = (y02_divabs_-mean_profit)/std_profit
        else:
            y01_divabs_ = y01_/abs_profit
            y02_divabs_ = y02_/abs_profit
            y01_divabs_[valid_point_val, :] = (y01_divabs_[valid_point_val, :]-mean_profit)/std_profit
            y02_divabs_[valid_point_val, :] = (y02_divabs_[valid_point_val, :]-mean_profit)/std_profit

    y0 = None
    y2 = None
    vari = None

elif args.old == 34:
    import pickle
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    x3 = torch.cat([load_data(args.test2[i], "xnn") for i in range(len(args.test2))], dim=0)[:, index]
    x4 = torch.cat([load_data(args.test4[i], "xnn") for i in range(len(args.test4))], dim=0)[:, index]

    
    # with open('abs_v'+";".join(args.train)+'.npy', 'rb') as f:
    #     abs_v = torch.from_numpy(np.load(f)).float()
    # with open('mean'+";".join(args.train)+'.npy', 'rb') as f:
    #     mean = torch.from_numpy(np.load(f)).float()
    # with open('std'+";".join(args.train)+'.npy', 'rb') as f:
    #     std = torch.from_numpy(np.load(f)).float()
    # print(abs_v, mean, std)
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)

    x2 = (x2/abs_v)
    x3 = (x3/abs_v)
    x4 = (x4/abs_v)
    
    with open('abs_v'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    y01 = np.load(args.rlbuy_profit_path+"_1.npy")

    abs_profit = np.max(np.abs(y01))
    y01_divabs = y01

    exist = (y01_divabs != 0)
    valid_buypoint_train = np.load(args.valid_buypoint_train+"_"+str(args.lag)+".npy")
    valid_point_train = valid_buypoint_train
    with open(args.buy_bucket_path+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy = pickle.load(fp)
    if args.norm_y:
        y01_divabs = (y01/abs_profit)
        mean_profit = y01_divabs[valid_point_train, :].mean()
        std_profit = y01_divabs[valid_point_train, :].std()
        y01_divabs[valid_point_train, :] = (y01_divabs[valid_point_train, :]-mean_profit)/std_profit
    else:
        mean_profit = 0
        std_profit = 1
        abs_profit = 1

    y01_ = np.load(args.rlbuy_profit_path2+"_"+str(args.lag)+".npy")
    valid_buypoint_valid = np.load(args.valid_buypoint_valid+"_"+str(args.lag)+".npy")
    valid_point_val = valid_buypoint_valid
    y01_divabs_ = y01_
    with open(args.buy_bucket_path2+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy_ = pickle.load(fp)
    if args.norm_y:
        y01_divabs_ = y01_/abs_profit
        y01_divabs_[valid_point_val, :] = (y01_divabs_[valid_point_val, :]-mean_profit)/std_profit

    y01__ = np.load(args.rlbuy_profit_path3+"_"+str(args.lag)+".npy")
    valid_buypoint_test = np.load(args.valid_buypoint_test+"_"+str(args.lag)+".npy")
    valid_point_test = valid_buypoint_test
    y01_divabs__ = y01__
    with open(args.buy_bucket_path3+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy__ = pickle.load(fp)
    if args.norm_y:
        y01_divabs__ = y01__/abs_profit
        y01_divabs__[valid_point_test, :] = (y01_divabs__[valid_point_test, :]-mean_profit)/std_profit

    y01___ = np.load(args.rlbuy_profit_path4+"_"+str(args.lag)+".npy")
    valid_buypoint_test4 = np.load(args.valid_buypoint_test4+"_"+str(args.lag)+".npy")
    valid_point_test4 = valid_buypoint_test4
    y01_divabs___ = y01___
    with open(args.buy_bucket_path4+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy___ = pickle.load(fp)
    if args.norm_y:
        y01_divabs___ = y01___/abs_profit
        y01_divabs___[valid_point_test4, :] = (y01_divabs___[valid_point_test4, :]-mean_profit)/std_profit
    
    y0 = None
    y2 = None
    vari = None

    print("mean, std, abs", mean_profit, std_profit, abs_profit)


elif args.old == 35:
    import pickle
    index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]

    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))

    lent = str(abs_v.size(1))
    np.save('data_6/abs_v_x_'+lent+"_"+args.train[0], abs_v)
    np.save('data_6/mean_x_'+lent+"_"+args.train[0], mean)
    np.save('data_6/std_x_'+lent+"_"+args.train[0], std)
    
    print(abs_v, mean, std)
    y01 = np.load(args.rlbuy_profit_path+"_1.npy")

    abs_profit = np.max(np.abs(y01))
    y01_divabs = y01

    exist = (y01_divabs != 0)
    valid_buypoint_train = np.load(args.valid_buypoint_train)
    valid_point_train = valid_buypoint_train
    with open(args.buy_bucket_path+"_1.npy", "rb") as fp:
        bucket_buy = pickle.load(fp)
    if args.norm_y:
        y01_divabs = (y01/abs_profit)
        mean_profit = y01_divabs[valid_point_train, :].mean()
        std_profit = y01_divabs[valid_point_train, :].std()
        y01_divabs[valid_point_train, :] = (y01_divabs[valid_point_train, :]-mean_profit)/std_profit
    else:
        mean_profit = 0
        std_profit = 1
        abs_profit = 1

    y01_ = np.load(args.rlbuy_profit_path2+"_1.npy")
    valid_buypoint_valid = np.load(args.valid_buypoint_valid)
    valid_point_val = valid_buypoint_valid
    y01_divabs_ = y01_
    with open(args.buy_bucket_path2+"_1.npy", "rb") as fp:
        bucket_buy_ = pickle.load(fp)
    if args.norm_y:
        y01_divabs_ = y01_/abs_profit
        y01_divabs_[valid_point_val, :] = (y01_divabs_[valid_point_val, :]-mean_profit)/std_profit

    y01__ = np.load(args.rlbuy_profit_path3+"_1.npy")
    valid_buypoint_test = np.load(args.valid_buypoint_test)
    valid_point_test = valid_buypoint_test
    y01_divabs__ = y01__
    with open(args.buy_bucket_path3+"_1.npy", "rb") as fp:
        bucket_buy__ = pickle.load(fp)
    if args.norm_y:
        y01_divabs__ = y01__/abs_profit
        y01_divabs__[valid_point_test, :] = (y01_divabs__[valid_point_test, :]-mean_profit)/std_profit

    y01___ = np.load(args.rlbuy_profit_path4+"_1.npy")
    valid_buypoint_test4 = np.load(args.valid_buypoint_test4)
    valid_point_test4 = valid_buypoint_test4
    y01_divabs___ = y01___
    with open(args.buy_bucket_path4+"_1.npy", "rb") as fp:
        bucket_buy___ = pickle.load(fp)
    if args.norm_y:
        y01_divabs___ = y01___/abs_profit
        y01_divabs___[valid_point_test4, :] = (y01_divabs___[valid_point_test4, :]-mean_profit)/std_profit
    
    y0 = None
    y2 = None
    vari = None

    print("mean, std, abs", mean_profit, std_profit, abs_profit)


    if args.train[0] == "08_11-10_20":
        data_y1 = np.load('data_6/y_all_08_11-09_15.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_08_11-09_15.npy', dtype='float32', mode='r', shape=(total_length1,645))
        data_y2 = np.load('data_6/y_all_09_16-09_25.npy', mmap_mode="r")
        total_length2 = data_y2.shape[0]
        data_X2 = np.memmap('data_6/x_all_09_16-09_25.npy', dtype='float32', mode='r', shape=(total_length2,645))
        data_y3 = np.load('data_6/y_all_09_26-10_12.npy', mmap_mode="r")
        total_length3 = data_y3.shape[0]
        data_X3 = np.memmap('data_6/x_all_09_26-10_12.npy', dtype='float32', mode='r', shape=(total_length3,645))
        total_length4 = load_data_length("10_13-10_20", "y")
        data_X4 = np.memmap('data_6/x_all_10_13-10_25.npy', dtype='float32', mode='r', shape=(total_length4, 645))
        data_X_train = [data_X1, data_X2, data_X3, data_X4]
        length_list_train = [total_length1, total_length2, total_length3, total_length4]
    elif args.train[0] == "08_11-09_15":
        data_y1 = np.load('data_6/y_all_08_11-09_15.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_08_11-09_15.npy', dtype='float32', mode='r', shape=(total_length1,645))
        data_X_train = [data_X1]
        length_list_train = [total_length1]
    if args.test[0] == "10_21-10_25":
        l1 = load_data_length("10_13-10_20", "y")
        total_length1 = load_data_length("10_21-10_25", "y")
        data_X1 = np.memmap('data_6/x_all_10_13-10_25.npy', dtype='float32', mode='r', shape=(total_length1, 645), offset=l1*645*4)
        data_X_test = [data_X1]
        length_list_test = [total_length1]
    elif args.test[0] == "09_16-09_25":
        data_y1 = np.load('data_6/y_all_09_16-09_25.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_09_16-09_25.npy', dtype='float32', mode='r', shape=(total_length1,645))
        data_X_test = [data_X1]
        length_list_test = [total_length1]
    if args.test2[0] == "10_27-11_01":
        total_length1 = load_data_length("10_27-11_01", "y")
        data_X1 = np.memmap('data_6/x_all_10_27-11_01.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        data_X_test2 = [data_X1]
        length_list_test2 = [total_length1]
    elif args.test2[0] == "09_26-10_25":
        data_y1 = np.load('data_6/y_all_09_26-10_12.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_09_26-10_12.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        total_length2 = load_data_length("10_13-10_25", "y")
        data_X2 = np.memmap('data_6/x_all_10_13-10_25.npy', dtype='float32', mode='r', shape=(total_length2, 645))
        data_X_test2 = [data_X1, data_X2]
        length_list_test2 = [total_length1, total_length2]
    if args.test4[0] == "10_27-11_01":
        total_length1 = load_data_length("10_27-11_01", "y")
        data_X1 = np.memmap('data_6/x_all_10_27-11_01.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        data_X_test4 = [data_X1]
        length_list_test4 = [total_length1]


elif args.old == 36:
    dout = 4
    import pickle
    index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    x = torch.cat([load_data(args.train[i], "xnn") for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], "xnn") for i in range(len(args.test))], dim=0)[:, index]
    x3 = torch.cat([load_data(args.test2[i], "xnn") for i in range(len(args.test2))], dim=0)[:, index]
    x4 = torch.cat([load_data(args.test4[i], "xnn") for i in range(len(args.test4))], dim=0)[:, index]
    

    # with open('abs_v'+";".join(args.train)+'.npy', 'rb') as f:
    #     abs_v = torch.from_numpy(np.load(f)).float()
    # with open('mean'+";".join(args.train)+'.npy', 'rb') as f:
    #     mean = torch.from_numpy(np.load(f)).float()
    # with open('std'+";".join(args.train)+'.npy', 'rb') as f:
    #     std = torch.from_numpy(np.load(f)).float()
    # print(abs_v, mean, std)
    abs_v = x.abs().max(0)[0]
    abs_v[abs_v==0] = 1
    x = (x/abs_v)
    mean = x.mean(0)
    std = x.std(0)

    x2 = (x2/abs_v)
    x3 = (x3/abs_v)
    x4 = (x4/abs_v)
    
    with open('abs_v'+";".join(args.train)+str(abs_v.size(1))+'.npy', 'wb') as f:
        np.save(f, abs_v.detach().cpu().double().numpy())
    with open('mean'+";".join(args.train)+str(mean.size(1))+'.npy', 'wb') as f:
        np.save(f, mean.detach().cpu().double().numpy())
    with open('std'+";".join(args.train)+str(std.size(1))+'.npy', 'wb') as f:
        np.save(f, std.detach().cpu().double().numpy())
    print(abs_v, mean, std)
    y01 = np.load(args.rlbuy_profit_path+"_1.npy")

    abs_profit = np.max(np.abs(y01))
    y01_divabs = y01

    exist = (y01_divabs != 0)
    valid_buypoint_train = np.load(args.valid_buypoint_train+"_"+str(args.lag)+".npy")
    valid_point_train = valid_buypoint_train
    with open(args.buy_bucket_path+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy = pickle.load(fp)
    if args.norm_y:
        y01_divabs = (y01/abs_profit)
        mean_profit = y01_divabs[valid_point_train, :].mean()
        std_profit = y01_divabs[valid_point_train, :].std()
        y01_divabs[valid_point_train, :] = (y01_divabs[valid_point_train, :]-mean_profit)/std_profit
    else:
        mean_profit = 0
        std_profit = 1
        abs_profit = 1
    if args.nop:
        nop = "nop"
    else:
        nop = ""
    if args.type == "buy":
        valid_sellprice1 = np.load("14dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.train)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base1 = np.load("14dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.train)+"std"+"_"+str(args.lag)+".npy")
        tpb1 = np.load("14dout"+str(dout)+"tpb"+"_"+";".join(args.train)+"std"+"_"+str(args.lag)+"train.npy")
        y01 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.train)+"std.npy")


        valid_sellprice2 = np.load("14dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base2 = np.load("14dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test)+"std"+"_"+str(args.lag)+".npy")
        tpb2 = np.load("14dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_"+str(args.lag)+"train.npy")
        y02 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std.npy")



        valid_sellprice3 = np.load("14dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test2)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base3 = np.load("14dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test2)+"std"+"_"+str(args.lag)+".npy")
        tpb3 = np.load("14dout"+str(dout)+"tpb"+"_"+";".join(args.test2)+"std"+"_"+str(args.lag)+"train.npy")
        y03 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.test2)+"std.npy")



        valid_sellprice4 = np.load("14dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test4)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base4 = np.load("14dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test4)+"std"+"_"+str(args.lag)+".npy")
        tpb4 = np.load("14dout"+str(dout)+"tpb"+"_"+";".join(args.test4)+"std"+"_"+str(args.lag)+"train.npy")
        y04 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.test4)+"std.npy")

    else:
        valid_sellprice1 = np.load("14dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.train)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base1 = np.load("14dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.train)+"std"+"_"+str(args.lag)+".npy")
        tpb1 = np.load("14dout"+str(dout)+"tps"+"_"+";".join(args.train)+"std"+"_"+str(args.lag)+"train.npy")
        y01 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.train)+"std.npy")



        valid_sellprice2 = np.load("14dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base2 = np.load("14dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test)+"std"+"_"+str(args.lag)+".npy")
        tpb2 = np.load("14dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_"+str(args.lag)+"train.npy")
        y02 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std.npy")



        valid_sellprice3 = np.load("14dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test2)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base3 = np.load("14dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test2)+"std"+"_"+str(args.lag)+".npy")
        tpb3 = np.load("14dout"+str(dout)+"tps"+"_"+";".join(args.test2)+"std"+"_"+str(args.lag)+"train.npy")
        y03 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.test2)+"std.npy")



        valid_sellprice4 = np.load("14dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test4)+"std"+"_"+str(args.lag)+".npy")
        buy_price_base4 = np.load("14dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test4)+"std"+"_"+str(args.lag)+".npy")
        tpb4 = np.load("14dout"+str(dout)+"tps"+"_"+";".join(args.test4)+"std"+"_"+str(args.lag)+"train.npy")
        y04 = np.load("14dout"+str(dout)+"y0"+"_"+";".join(args.test4)+"std.npy")

    y0_abs_v = np.max(np.abs(y01))
    tmp_y01 = y01/y0_abs_v
    y0_mean = tmp_y01.mean()
    y0_std = tmp_y01.std()

    y01_ = np.load(args.rlbuy_profit_path2+"_"+str(args.lag)+".npy")
    valid_buypoint_valid = np.load(args.valid_buypoint_valid+"_"+str(args.lag)+".npy")
    valid_point_val = valid_buypoint_valid
    y01_divabs_ = y01_
    with open(args.buy_bucket_path2+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy_ = pickle.load(fp)
    if args.norm_y:
        y01_divabs_ = y01_/abs_profit
        y01_divabs_[valid_point_val, :] = (y01_divabs_[valid_point_val, :]-mean_profit)/std_profit

    y01__ = np.load(args.rlbuy_profit_path3+"_"+str(args.lag)+".npy")
    valid_buypoint_test = np.load(args.valid_buypoint_test+"_"+str(args.lag)+".npy")
    valid_point_test = valid_buypoint_test
    y01_divabs__ = y01__
    with open(args.buy_bucket_path3+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy__ = pickle.load(fp)
    if args.norm_y:
        y01_divabs__ = y01__/abs_profit
        y01_divabs__[valid_point_test, :] = (y01_divabs__[valid_point_test, :]-mean_profit)/std_profit

    y01___ = np.load(args.rlbuy_profit_path4+"_"+str(args.lag)+".npy")
    valid_buypoint_test4 = np.load(args.valid_buypoint_test4+"_"+str(args.lag)+".npy")
    valid_point_test4 = valid_buypoint_test4
    y01_divabs___ = y01___
    with open(args.buy_bucket_path4+"_"+str(args.lag)+".npy", "rb") as fp:
        bucket_buy___ = pickle.load(fp)
    if args.norm_y:
        y01_divabs___ = y01___/abs_profit
        y01_divabs___[valid_point_test4, :] = (y01_divabs___[valid_point_test4, :]-mean_profit)/std_profit
    
    y0 = None
    y2 = None
    vari = None

    print("mean, std, abs", mean_profit, std_profit, abs_profit)


elif args.old == 37:
    dout = 4
    import pickle
    if args.input_size == 96:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58] + [i for i in range(59, 100)]
    elif args.input_size == 55:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.input_size == 56:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    else:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        if end_month < start_month:
            year = 2023
        else:
            year = 2022
        end = datetime.date(year,end_month,end_day)
        
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)
    print(args.generate_test_predict)
    if not args.generate_test_predict:
        x = torch.cat([load_data(args.train[i], args.x) for i in range(len(args.train))], dim=0)[:, index]
        x2 = torch.cat([load_data(args.test[i], args.x) for i in range(len(args.test))], dim=0)[:, index]
        x3 = torch.cat([load_data(args.test2[i], args.x) for i in range(len(args.test2))], dim=0)[:, index]
    x4 = torch.cat([load_data(args.test4[i], args.x) for i in range(len(args.test4))], dim=0)[:, index]
    import os

    if not os.path.exists('abs_v'+";".join(args.train)+str(len(index))+'.npy'):
        abs_v = x.abs().max(0)[0]
        abs_v[abs_v==0] = 1
        x = (x/abs_v)
        mean = x.mean(0)
        std = x.std(0)

        x2 = (x2/abs_v)
        x3 = (x3/abs_v)
        x4 = (x4/abs_v)
        
        with open('abs_v'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, abs_v.detach().cpu().double().numpy())
        with open('mean'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, mean.detach().cpu().double().numpy())
        with open('std'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, std.detach().cpu().double().numpy())
    else:
        abs_v = np.load('abs_v'+";".join(args.train)+str(len(index))+'.npy')
        mean = np.load('mean'+";".join(args.train)+str(len(index))+'.npy')
        std = np.load('std'+";".join(args.train)+str(len(index))+'.npy')
        if not args.generate_test_predict:
            x = (x/abs_v)
            x2 = (x2/abs_v)
            x3 = (x3/abs_v)
        x4 = (x4/abs_v)
    print(abs_v, mean, std)
    y11 = np.load(args.rlbuy_profit_path+"_11.npy")
    valid_point_train11 = np.load(args.valid_buypoint_train+"_11.npy")
    y11_selected = y11[valid_point_train11]
    y12 = np.load(args.rlbuy_profit_path+"_12.npy")
    valid_point_train12 = np.load(args.valid_buypoint_train+"_12.npy")
    y12_selected = y12[valid_point_train12]
    y21 = np.load(args.rlbuy_profit_path+"_21.npy")
    valid_point_train21 = np.load(args.valid_buypoint_train+"_21.npy")
    y21_selected = y21[valid_point_train21]
    y22 = np.load(args.rlbuy_profit_path+"_22.npy")
    valid_point_train22 = np.load(args.valid_buypoint_train+"_22.npy")
    y22_selected = y22[valid_point_train22]
    if y11.shape[1] == 6:
        y11_selected = np.concatenate([y11_selected, np.zeros((y11_selected.shape[0], 1))], axis=1)
        # y12_selected = np.concatenate([y12_selected, np.zeros((y12_selected.shape[0], 1))], axis=1)
        # y21_selected = np.concatenate([y21_selected, np.zeros((y21_selected.shape[0], 1))], axis=1)
    # print(y11_selected.shape, y12_selected.shape, y21_selected.shape)
    y_combined = np.concatenate([y11_selected, y12_selected, y21_selected, y22_selected], axis=0)

    abs_profit = np.max(np.abs(y_combined))
    y_combined = y_combined/abs_profit
    mean_profit = y_combined.mean()
    std_profit = y_combined.std()

    with open(args.buy_bucket_path+"_11.npy", "rb") as fp:
        bucket_buy11 = pickle.load(fp)
    with open(args.buy_bucket_path+"_12.npy", "rb") as fp:
        bucket_buy12 = pickle.load(fp)
    with open(args.buy_bucket_path+"_21.npy", "rb") as fp:
        bucket_buy21 = pickle.load(fp)
    with open(args.buy_bucket_path+"_22.npy", "rb") as fp:
        bucket_buy22 = pickle.load(fp)

    if not args.norm_y:
        abs_profit = 1
        mean_profit = 0
        std_profit = 1

    if args.nop:
        nop = "nop"
    else:
        nop = ""

    if args.type == "buy":
        valid_sellprice1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.train)+"std"+"_11.npy")
        valid_sellprice1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.train)+"std"+"_22.npy")
        buy_price_base1 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.train)+"std"+"_11.npy")
        tpb1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.train)+"std"+"_11train.npy")
        tpb1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.train)+"std"+"_22train.npy")
        y01 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.train)+"std.npy")

        valid_sellprice2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test)+"std"+"_11.npy")
        valid_sellprice2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test)+"std"+"_22.npy")
        buy_price_base2 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test)+"std"+"_11.npy")
        tpb2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_11train.npy")
        tpb2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_22train.npy")
        y02 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std.npy")

        valid_sellprice3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test2)+"std"+"_11.npy")
        valid_sellprice3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test2)+"std"+"_22.npy")
        buy_price_base3 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test2)+"std"+"_11.npy")
        tpb3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test2)+"std"+"_11train.npy")
        tpb3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test2)+"std"+"_22train.npy")
        y03 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test2)+"std.npy")

        valid_sellprice4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test4)+"std"+"_11.npy")
        valid_sellprice4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test4)+"std"+"_22.npy")
        buy_price_base4 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test4)+"std"+"_11.npy")
        tpb4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test4)+"std"+"_11train.npy")
        tpb4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test4)+"std"+"_22train.npy")
        y04 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test4)+"std.npy")

    else:
        valid_sellprice1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.train)+"std"+"_11.npy")
        valid_sellprice1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.train)+"std"+"_22.npy")
        buy_price_base1 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.train)+"std"+"_11.npy")
        tpb1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.train)+"std"+"_11train.npy")
        tpb1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.train)+"std"+"_22train.npy")
        y01 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.train)+"std.npy")

        valid_sellprice2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test)+"std"+"_11.npy")
        valid_sellprice2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test)+"std"+"_22.npy")
        buy_price_base2 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test)+"std"+"_11.npy")
        tpb2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_11train.npy")
        tpb2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_22train.npy")
        y02 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std.npy")

        valid_sellprice3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test2)+"std"+"_11.npy")
        valid_sellprice3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test2)+"std"+"_22.npy")
        buy_price_base3 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test2)+"std"+"_11.npy")
        tpb3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test2)+"std"+"_11train.npy")
        tpb3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test2)+"std"+"_22train.npy")
        y03 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test2)+"std.npy")

        valid_sellprice4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test4)+"std"+"_11.npy")
        valid_sellprice4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test4)+"std"+"_22.npy")
        buy_price_base4 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test4)+"std"+"_11.npy")
        tpb4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test4)+"std"+"_11train.npy")
        tpb4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test4)+"std"+"_22train.npy")
        y04 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test4)+"std.npy")

    y0_abs_v = np.max(np.abs(y01))
    tmp_y01 = y01/y0_abs_v
    y0_mean = tmp_y01.mean()
    y0_std = tmp_y01.std()

    with open(args.buy_bucket_path2+"_11.npy", "rb") as fp:
        bucket_buy11_ = pickle.load(fp)
    with open(args.buy_bucket_path2+"_12.npy", "rb") as fp:
        bucket_buy12_ = pickle.load(fp)
    with open(args.buy_bucket_path2+"_21.npy", "rb") as fp:
        bucket_buy21_ = pickle.load(fp)
    with open(args.buy_bucket_path2+"_22.npy", "rb") as fp:
        bucket_buy22_ = pickle.load(fp)

    
    with open(args.buy_bucket_path3+"_11.npy", "rb") as fp:
        bucket_buy11__ = pickle.load(fp)
    with open(args.buy_bucket_path3+"_12.npy", "rb") as fp:
        bucket_buy12__ = pickle.load(fp)
    with open(args.buy_bucket_path3+"_21.npy", "rb") as fp:
        bucket_buy21__ = pickle.load(fp)
    with open(args.buy_bucket_path3+"_22.npy", "rb") as fp:
        bucket_buy22__ = pickle.load(fp)

    
    with open(args.buy_bucket_path4+"_11.npy", "rb") as fp:
        bucket_buy11___ = pickle.load(fp)
    with open(args.buy_bucket_path4+"_12.npy", "rb") as fp:
        bucket_buy12___ = pickle.load(fp)
    with open(args.buy_bucket_path4+"_21.npy", "rb") as fp:
        bucket_buy21___ = pickle.load(fp)
    with open(args.buy_bucket_path4+"_22.npy", "rb") as fp:
        bucket_buy22___ = pickle.load(fp)


elif args.old == 38:
    dout = 4
    import pickle
    index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33]
    index_x = []
    for i in range(621):
        if i not in [30, 53, 54, 55, 56, 77, 78, 79, 80, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512]:
            index_x.append(i)
    abs_v_xnn = np.load('data_6/abs_v_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    mean_xnn = np.load('data_6/mean_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]
    std_xnn = np.load('data_6/std_xnn'+args.train[0]+'.npy').reshape(1, 59)[:, index_all]

    abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
    mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
    std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)

    abs_v = torch.from_numpy(np.concatenate([abs_v_xnn, abs_v_x], axis=1))[:, index_x]
    mean = torch.from_numpy(np.concatenate([mean_xnn, mean_x], axis=1))[:, index_x]
    std = torch.from_numpy(np.concatenate([std_xnn, std_x], axis=1))[:, index_x]
    
    lent = str(abs_v.size(1))
    np.save('data_6/abs_v_x_'+lent+"_"+args.train[0], abs_v)
    np.save('data_6/mean_x_'+lent+"_"+args.train[0], mean)
    np.save('data_6/std_x_'+lent+"_"+args.train[0], std)

    y11 = np.load(args.rlbuy_profit_path+"_11.npy")
    valid_point_train11 = np.load(args.valid_buypoint_train+"_11.npy")
    y11_selected = y11[valid_point_train11]
    y12 = np.load(args.rlbuy_profit_path+"_12.npy")
    valid_point_train12 = np.load(args.valid_buypoint_train+"_12.npy")
    y12_selected = y12[valid_point_train12]
    y21 = np.load(args.rlbuy_profit_path+"_21.npy")
    valid_point_train21 = np.load(args.valid_buypoint_train+"_21.npy")
    y21_selected = y21[valid_point_train21]
    y22 = np.load(args.rlbuy_profit_path+"_22.npy")
    valid_point_train22 = np.load(args.valid_buypoint_train+"_22.npy")
    y22_selected = y22[valid_point_train22]

    y_combined = np.concatenate([y11_selected, y12_selected, y21_selected, y22_selected], axis=0)

    abs_profit = np.max(np.abs(y_combined))
    y_combined = y_combined/abs_profit
    mean_profit = y_combined.mean()
    std_profit = y_combined.std()

    with open(args.buy_bucket_path+"_11.npy", "rb") as fp:
        bucket_buy11 = pickle.load(fp)
    with open(args.buy_bucket_path+"_12.npy", "rb") as fp:
        bucket_buy12 = pickle.load(fp)
    with open(args.buy_bucket_path+"_21.npy", "rb") as fp:
        bucket_buy21 = pickle.load(fp)
    with open(args.buy_bucket_path+"_22.npy", "rb") as fp:
        bucket_buy22 = pickle.load(fp)

    if not args.norm_y:
        abs_profit = 1
        mean_profit = 0
        std_profit = 1

    if args.nop:
        nop = "nop"
    else:
        nop = ""

    if args.type == "buy":
        valid_sellprice1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.train)+"std"+"_11.npy")
        valid_sellprice1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.train)+"std"+"_22.npy")
        buy_price_base1 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.train)+"std"+"_11.npy")
        tpb1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.train)+"std"+"_11train.npy")
        tpb1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.train)+"std"+"_22train.npy")
        y01 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.train)+"std.npy")

        valid_sellprice2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test)+"std"+"_11.npy")
        valid_sellprice2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test)+"std"+"_22.npy")
        buy_price_base2 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test)+"std"+"_11.npy")
        tpb2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_11train.npy")
        tpb2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_22train.npy")
        y02 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std.npy")

        valid_sellprice3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test2)+"std"+"_11.npy")
        valid_sellprice3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test2)+"std"+"_22.npy")
        buy_price_base3 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test2)+"std"+"_11.npy")
        tpb3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test2)+"std"+"_11train.npy")
        tpb3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test2)+"std"+"_22train.npy")
        y03 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test2)+"std.npy")

        valid_sellprice4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test4)+"std"+"_11.npy")
        valid_sellprice4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test4)+"std"+"_22.npy")
        buy_price_base4 = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+nop+"_"+";".join(args.test4)+"std"+"_11.npy")
        tpb4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test4)+"std"+"_11train.npy")
        tpb4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test4)+"std"+"_22train.npy")
        y04 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test4)+"std.npy")

    else:
        valid_sellprice1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.train)+"std"+"_11.npy")
        valid_sellprice1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.train)+"std"+"_22.npy")
        buy_price_base1 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.train)+"std"+"_11.npy")
        tpb1_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.train)+"std"+"_11train.npy")
        tpb1_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.train)+"std"+"_22train.npy")
        y01 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.train)+"std.npy")

        valid_sellprice2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test)+"std"+"_11.npy")
        valid_sellprice2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test)+"std"+"_22.npy")
        buy_price_base2 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test)+"std"+"_11.npy")
        tpb2_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_11train.npy")
        tpb2_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_22train.npy")
        y02 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std.npy")

        valid_sellprice3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test2)+"std"+"_11.npy")
        valid_sellprice3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test2)+"std"+"_22.npy")
        buy_price_base3 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test2)+"std"+"_11.npy")
        tpb3_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test2)+"std"+"_11train.npy")
        tpb3_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test2)+"std"+"_22train.npy")
        y03 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test2)+"std.npy")

        valid_sellprice4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test4)+"std"+"_11.npy")
        valid_sellprice4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test4)+"std"+"_22.npy")
        buy_price_base4 = np.load(str(args.profit_type)+"dout"+str(dout)+"sell_price_base"+nop+"_"+";".join(args.test4)+"std"+"_11.npy")
        tpb4_1 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test4)+"std"+"_11train.npy")
        tpb4_2 = np.load(str(args.profit_type)+"dout"+str(dout)+"tps"+"_"+";".join(args.test4)+"std"+"_22train.npy")
        y04 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.test4)+"std.npy")

    y0_abs_v = np.max(np.abs(y01))
    tmp_y01 = y01/y0_abs_v
    y0_mean = tmp_y01.mean()
    y0_std = tmp_y01.std()

    with open(args.buy_bucket_path2+"_11.npy", "rb") as fp:
        bucket_buy11_ = pickle.load(fp)
    with open(args.buy_bucket_path2+"_12.npy", "rb") as fp:
        bucket_buy12_ = pickle.load(fp)
    with open(args.buy_bucket_path2+"_21.npy", "rb") as fp:
        bucket_buy21_ = pickle.load(fp)
    with open(args.buy_bucket_path2+"_22.npy", "rb") as fp:
        bucket_buy22_ = pickle.load(fp)

    
    with open(args.buy_bucket_path3+"_11.npy", "rb") as fp:
        bucket_buy11__ = pickle.load(fp)
    with open(args.buy_bucket_path3+"_12.npy", "rb") as fp:
        bucket_buy12__ = pickle.load(fp)
    with open(args.buy_bucket_path3+"_21.npy", "rb") as fp:
        bucket_buy21__ = pickle.load(fp)
    with open(args.buy_bucket_path3+"_22.npy", "rb") as fp:
        bucket_buy22__ = pickle.load(fp)

    
    with open(args.buy_bucket_path4+"_11.npy", "rb") as fp:
        bucket_buy11___ = pickle.load(fp)
    with open(args.buy_bucket_path4+"_12.npy", "rb") as fp:
        bucket_buy12___ = pickle.load(fp)
    with open(args.buy_bucket_path4+"_21.npy", "rb") as fp:
        bucket_buy21___ = pickle.load(fp)
    with open(args.buy_bucket_path4+"_22.npy", "rb") as fp:
        bucket_buy22___ = pickle.load(fp)

    if args.train[0] == "08_11-10_20":
        data_y1 = np.load('data_6/y_all_08_11-09_15.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_08_11-09_15.npy', dtype='float32', mode='r', shape=(total_length1,645))
        data_y2 = np.load('data_6/y_all_09_16-09_25.npy', mmap_mode="r")
        total_length2 = data_y2.shape[0]
        data_X2 = np.memmap('data_6/x_all_09_16-09_25.npy', dtype='float32', mode='r', shape=(total_length2,645))
        data_y3 = np.load('data_6/y_all_09_26-10_12.npy', mmap_mode="r")
        total_length3 = data_y3.shape[0]
        data_X3 = np.memmap('data_6/x_all_09_26-10_12.npy', dtype='float32', mode='r', shape=(total_length3,645))
        total_length4 = load_data_length("10_13-10_20", "y")
        data_X4 = np.memmap('data_6/x_all_10_13-10_25.npy', dtype='float32', mode='r', shape=(total_length4, 645))
        data_X_train = [data_X1, data_X2, data_X3, data_X4]
        length_list_train = [total_length1, total_length2, total_length3, total_length4]
    elif args.train[0] == "08_11-09_15":
        data_y1 = np.load('data_6/y_all_08_11-09_15.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_08_11-09_15.npy', dtype='float32', mode='r', shape=(total_length1,645))
        data_X_train = [data_X1]
        length_list_train = [total_length1]
    if args.test[0] == "10_21-10_25":
        l1 = load_data_length("10_13-10_20", "y")
        total_length1 = load_data_length("10_21-10_25", "y")
        data_X1 = np.memmap('data_6/x_all_10_13-10_25.npy', dtype='float32', mode='r', shape=(total_length1, 645), offset=l1*645*4)
        data_X_test = [data_X1]
        length_list_test = [total_length1]
    elif args.test[0] == "09_16-09_25":
        data_y1 = np.load('data_6/y_all_09_16-09_25.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_09_16-09_25.npy', dtype='float32', mode='r', shape=(total_length1,645))
        data_X_test = [data_X1]
        length_list_test = [total_length1]
    if args.test2[0] == "10_27-11_11":
        total_length1 = load_data_length("10_27-11_01", "y")
        data_X1 = np.memmap('data_6/x_all_10_27-11_01.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        total_length2 = load_data_length("11_02-11_06", "y")
        data_X2 = np.memmap('data_6/x_all_11_02-11_06.npy', dtype='float32', mode='r', shape=(total_length2, 645))
        total_length3 = load_data_length("11_07-11_11", "y")
        data_X3 = np.memmap('data_6/x_all_11_07-11_11.npy', dtype='float32', mode='r', shape=(total_length3, 645))
        data_X_test2 = [data_X1, data_X2, data_X3]
        length_list_test2 = [total_length1, total_length2, total_length3]
    elif args.test2[0] == "10_27-11_01":
        total_length1 = load_data_length("10_27-11_01", "y")
        data_X1 = np.memmap('data_6/x_all_10_27-11_01.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        data_X_test2 = [data_X1]
        length_list_test2 = [total_length1]
    elif args.test2[0] == "09_26-10_25":
        data_y1 = np.load('data_6/y_all_09_26-10_12.npy', mmap_mode="r")
        total_length1 = data_y1.shape[0]
        data_X1 = np.memmap('data_6/x_all_09_26-10_12.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        total_length2 = load_data_length("10_13-10_25", "y")
        data_X2 = np.memmap('data_6/x_all_10_13-10_25.npy', dtype='float32', mode='r', shape=(total_length2, 645))
        data_X_test2 = [data_X1, data_X2]
        length_list_test2 = [total_length1, total_length2]
    if args.test4[0] == "10_27-11_01":
        total_length1 = load_data_length("10_27-11_01", "y")
        data_X1 = np.memmap('data_6/x_all_10_27-11_01.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        data_X_test4 = [data_X1]
        length_list_test4 = [total_length1]
    elif args.test4[0] == "10_27-11_06":
        total_length1 = load_data_length("10_27-11_01", "y")
        data_X1 = np.memmap('data_6/x_all_10_27-11_01.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        total_length2 = load_data_length("11_02-11_06", "y")
        data_X2 = np.memmap('data_6/x_all_11_02-11_06.npy', dtype='float32', mode='r', shape=(total_length2, 645))
        data_X_test4 = [data_X1, data_X2]
        length_list_test4 = [total_length1, total_length2]
    elif args.test4[0] == "11_19-11_24":
        total_length1 = load_data_length("11_19-11_24", "y")
        data_X1 = np.memmap('data_6/x_all_11_19-11_24.npy', dtype='float32', mode='r', shape=(total_length1, 645))
        data_X_test4 = [data_X1]
        length_list_test4 = [total_length1]


elif args.old == 39:
    dout = 4
    import pickle
    if args.input_size == 96:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58] + [i for i in range(59, 100)]
    elif args.input_size == 55:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.input_size == 56:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.input_size == 73:
        index = [i for i in range(73)]
    else:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        start = datetime.date(2022,start_month,start_day)
        if end_month < start_month:
            year = 2023
        else:
            year = 2022
        end = datetime.date(year,end_month,end_day)
        print(start_month, start_day, end_month, end_day)
        x_l = []
        for i in range((end-start).days+1):
            print(i)
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
        return torch.cat(x_l, dim=0)

    if not args.generate_test_predict:
        x = torch.cat([load_data(args.train[i], args.x) for i in range(len(args.train))], dim=0)[:, index]
        x3 = torch.cat([load_data(args.test2[i], args.x) for i in range(len(args.test2))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], args.x) for i in range(len(args.test))], dim=0)[:, index]
    x4 = torch.cat([load_data(args.test4[i], args.x) for i in range(len(args.test4))], dim=0)[:, index]
    import os

    if not os.path.exists('abs_v'+";".join(args.train)+str(len(index))+'.npy'):
        abs_v = x.abs().max(0)[0]
        abs_v[abs_v==0] = 1
        x = (x/abs_v)
        mean = x.mean(0)
        std = x.std(0)

        x2 = (x2/abs_v)
        x3 = (x3/abs_v)
        x4 = (x4/abs_v)
        
        with open('abs_v'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, abs_v.detach().cpu().double().numpy())
        with open('mean'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, mean.detach().cpu().double().numpy())
        with open('std'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, std.detach().cpu().double().numpy())
    else:
        abs_v = np.load('abs_v'+";".join(args.train)+str(len(index))+'.npy')
        mean = np.load('mean'+";".join(args.train)+str(len(index))+'.npy')
        std = np.load('std'+";".join(args.train)+str(len(index))+'.npy')
        if not args.generate_test_predict:
            x = (x/abs_v)
            x3 = (x3/abs_v)
        x2 = (x2/abs_v)
        x4 = (x4/abs_v)

    test_field = args.train
    if args.t2:
        abbr = "2"
    else:
        abbr = ""
    if args.use_p23 != 101:
        if args.type == "buy":
            vb1 = np.load(abbr+str(args.profit_type)+"dout4valid_buypoint_0"+"_"+";".join(test_field)+"std_11.npy")
            # vb2 = np.load(str(args.profit_type)+"dout4valid_buypoint_0"+"_"+";".join(test_field)+"std_22.npy")
            vb3 = np.load(abbr+str(args.profit_type)+"dout4valid_sell2ndpoint_0"+"_"+";".join(test_field)+"std_11.npy")
            # vb4 = np.load(str(args.profit_type)+"dout4valid_sell2ndpoint_0"+"_"+";".join(test_field)+"std_22.npy")
        else:
            vb1 = np.load(abbr+str(args.profit_type)+"dout4valid_sellpoint_0"+"_"+";".join(test_field)+"std_11.npy")
            # vb2 = np.load(str(args.profit_type)+"dout4valid_sellpoint_0"+"_"+";".join(test_field)+"std_22.npy")
            vb3 = np.load(abbr+str(args.profit_type)+"dout4valid_buy2ndpoint_0"+"_"+";".join(test_field)+"std_11.npy")
            # vb4 = np.load(str(args.profit_type)+"dout4valid_buy2ndpoint_0"+"_"+";".join(test_field)+"std_22.npy")
        # vb = list(set(vb1.flatten()).union(set(vb2.flatten())).union(set(vb3.flatten())).union(set(vb4.flatten())))
    else:
        profit_type = 19
        dout = 4
        lag1, lag2 = 1, 1 
        m1, m2 = args.m1, args.m2
        p1 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(test_field)+"std"+".npy")

        buy_price_base = np.load(abbr+str(profit_type)+"dout"+str(dout)+"buy_price_basenop"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy") * (1+np.clip(m2*p1/1e4, -20/1e4, 0))
        sell_price_base = np.load(abbr+str(profit_type)+"dout"+str(dout)+"sell_price_basenop"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy") * (1+np.clip(m1*p1/1e4, 0, 20/1e4))
        tpb = np.load(abbr+str(profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        tps = np.load(abbr+str(profit_type)+"dout"+str(dout)+"tps2nd"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy")
        vb1 = np.logical_and(tpb <= buy_price_base-0.01, tpb != 0).nonzero()[0]
        vb3 = np.logical_and(tps >= sell_price_base+0.01, tps != 0).nonzero()[0]

    vb = list(set(vb1.flatten()).union(set(vb3.flatten())))
    vb.sort()
    vb = np.array(vb)
    train_indices = torch.from_numpy(vb)
    y11 = []
    if args.no_order:
        nums_d = args.d_num-1
    else:
        nums_d = args.d_num
    from_list = [args.offset + i for i in range(nums_d)]
    from_list = [0, 1, 2, 3, 4, 5]
    print("from_list", from_list)
    for dout in from_list:
        y11_i = np.load(abbr+"19dout"+str(dout)+"easy_profit_"+args.type+"_"+";".join(args.train)+"std"+"_11.npy")
        print(np.sum(y11_i!=0))
        y11.append(y11_i)
    y11 = np.concatenate(y11, axis=1)
    print(y11.shape, y11)
    valid_point_train11 = np.sum(y11, axis=1).nonzero()[0]
    print(valid_point_train11.shape, valid_point_train11)
    y11_selected = y11[valid_point_train11]

    y_combined = np.concatenate([y11_selected], axis=0)

    abs_profit = np.max(np.abs(y_combined))
    y_combined = y_combined/abs_profit
    mean_profit = y_combined.mean()
    std_profit = y_combined.std()
    print(abs_profit, mean_profit, std_profit)
    if args.bin == 1 or args.use_p23 == 101:
        abs_profit2, mean_profit2, std_profit2 = abs_profit, mean_profit, std_profit
    else:
        y11 = []
        from_list = [args.offset + i for i in range(nums_d)]
        print("from_list", from_list)
        for dout in from_list:
            y11_i = np.load(abbr+"19dout"+str(dout)+"easy_profit_"+args.type+"pos"+str(args.bin)+"_"+";".join(args.train)+"std"+"_11.npy")
            print(np.sum(y11_i!=0))
            y11.append(y11_i)
        y11 = np.concatenate(y11, axis=1)
        print(y11.shape, y11)
        valid_point_train11 = np.sum(y11, axis=1).nonzero()[0]
        print(valid_point_train11.shape, valid_point_train11)
        y11_selected = y11[valid_point_train11]

        y_combined = np.concatenate([y11_selected], axis=0)

        abs_profit2 = np.max(np.abs(y_combined))
        y_combined = y_combined/abs_profit2
        mean_profit2 = y_combined.mean()
        std_profit2 = y_combined.std()
        print(abs_profit2, mean_profit2, std_profit2)

elif args.old == 40:
    dout = 4
    import pickle
    if args.input_size == 96:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58] + [i for i in range(59, 100)]
    elif args.input_size == 55:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.input_size == 56:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    else:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    import datetime
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)
    print(args.generate_test_predict)
    if not args.generate_test_predict:
        x = torch.cat([load_data(args.train[i], args.x) for i in range(len(args.train))], dim=0)[:, index]
        x2 = torch.cat([load_data(args.test[i], args.x) for i in range(len(args.test))], dim=0)[:, index]
        x3 = torch.cat([load_data(args.test2[i], args.x) for i in range(len(args.test2))], dim=0)[:, index]
    x4 = torch.cat([load_data(args.test4[i], args.x) for i in range(len(args.test4))], dim=0)[:, index]
    import os

    if not os.path.exists('abs_v'+";".join(args.train)+str(len(index))+'.npy'):
        abs_v = x.abs().max(0)[0]
        abs_v[abs_v==0] = 1
        x = (x/abs_v)
        mean = x.mean(0)
        std = x.std(0)

        x2 = (x2/abs_v)
        x3 = (x3/abs_v)
        x4 = (x4/abs_v)
        
        with open('abs_v'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, abs_v.detach().cpu().double().numpy())
        with open('mean'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, mean.detach().cpu().double().numpy())
        with open('std'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, std.detach().cpu().double().numpy())
    else:
        abs_v = np.load('abs_v'+";".join(args.train)+str(len(index))+'.npy')
        mean = np.load('mean'+";".join(args.train)+str(len(index))+'.npy')
        std = np.load('std'+";".join(args.train)+str(len(index))+'.npy')
        if not args.generate_test_predict:
            x = (x/abs_v)
            x2 = (x2/abs_v)
            x3 = (x3/abs_v)
        x4 = (x4/abs_v)
    print(abs_v, mean, std)

    abs_profit = np.load(str(args.profit_type)+"abs_profit_b"+"_"+";".join(args.train)+"std.npy")
    mean_profit = np.load(str(args.profit_type)+"mean_profit_b"+"_"+";".join(args.train)+"std.npy")
    std_profit = np.load(str(args.profit_type)+"std_profit_b"+"_"+";".join(args.train)+"std.npy")

    sell2nd_price_base = np.load(str(args.profit_type)+"dout"+str(dout)+"sell2nd_price_base"+"_"+";".join(args.train)+"std"+"_11.npy")
    buy_price_base = np.load(str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+"_"+";".join(args.train)+"std"+"_11.npy")
    tpb = np.load(str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.train)+"std"+"_11.npy")
    tps2nd = np.load(str(args.profit_type)+"dout"+str(dout)+"tps2nd"+"_"+";".join(args.train)+"std"+"_11.npy")
    y0 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(args.train)+"std.npy")
    valid_buypoint = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_buypoint_0"+"_"+";".join(args.train)+"std"+"_11.npy")
    valid_sell2ndpoint = np.load(str(args.profit_type)+"dout"+str(dout)+"valid_sell2ndpoint_0"+"_"+";".join(args.train)+"std"+"_11.npy")
    vp = list(set(valid_buypoint.flatten()).union(set(valid_sell2ndpoint.flatten())))
    vp.sort()
    vp = np.array(vp)
    if not args.norm_y:
        abs_profit = 1
        mean_profit = 0
        std_profit = 1


elif args.old == 41:
    if args.input_size == 96:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58] + [i for i in range(59, 100)]
    elif args.input_size == 55:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    elif args.input_size == 56:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    else:
        index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
    def load_data(date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)
    print(args.generate_test_predict)
    if not args.generate_test_predict:
        x = torch.cat([load_data(args.train[i], args.x) for i in range(len(args.train))], dim=0)[:, index]
    x2 = torch.cat([load_data(args.test[i], args.x) for i in range(len(args.test))], dim=0)[:, index]
    import os

    if not os.path.exists('abs_v'+";".join(args.train)+str(len(index))+'.npy'):
        abs_v = x.abs().max(0)[0]
        abs_v[abs_v==0] = 1
        x = (x/abs_v)
        mean = x.mean(0)
        std = x.std(0)

        x2 = (x2/abs_v)
        
        with open('abs_v'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, abs_v.detach().cpu().double().numpy())
        with open('mean'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, mean.detach().cpu().double().numpy())
        with open('std'+";".join(args.train)+str(abs_v.size(0))+'.npy', 'wb') as f:
            np.save(f, std.detach().cpu().double().numpy())
    else:
        abs_v = np.load('abs_v'+";".join(args.train)+str(len(index))+'.npy')
        mean = np.load('mean'+";".join(args.train)+str(len(index))+'.npy')
        std = np.load('std'+";".join(args.train)+str(len(index))+'.npy')
        if not args.generate_test_predict:
            x = (x/abs_v)
        x2 = (x2/abs_v)
    print(abs_v, mean, std)
    if args.lag == 2:
        y01 = np.load(args.rlbuy_profit_path+"_11.npy")+np.load(args.rlbuy_profit_path+"_22.npy")
        y02 = np.load(args.rlsell_profit_path+"_11.npy")+np.load(args.rlsell_profit_path+"_22.npy")
    else:
        y01 = np.load(args.rlbuy_profit_path+"_11.npy")
        y02 = np.load(args.rlsell_profit_path+"_11.npy")
    
    abs_profit = max(np.max(np.abs(y01)), np.max(np.abs(y02)))

    exist = None
    if args.lag == 2:
        valid_buypoint_train = np.load(args.valid_buypoint_train+"_11.npy")
        valid_sellpoint_train = np.load(args.valid_sellpoint_train+"_11.npy")
        valid_buypoint_train2 = np.load(args.valid_buypoint_train+"_22.npy")
        valid_sellpoint_train2 = np.load(args.valid_sellpoint_train+"_22.npy")
        valid_buypoint_train = list(set(valid_buypoint_train.flatten()).union(set(valid_buypoint_train2.flatten())))
        valid_buypoint_train.sort()
        valid_buypoint_train = np.array(valid_buypoint_train)
        valid_sellpoint_train = list(set(valid_sellpoint_train.flatten()).union(set(valid_sellpoint_train2.flatten())))
        valid_sellpoint_train.sort()
        valid_sellpoint_train = np.array(valid_sellpoint_train)
    else:
        valid_buypoint_train = np.load(args.valid_buypoint_train+"_11.npy")
        valid_sellpoint_train = np.load(args.valid_sellpoint_train+"_11.npy")
    valid_point_train = list(set(valid_buypoint_train.flatten()).union(set(valid_sellpoint_train.flatten())))
    valid_point_train.sort()
    valid_point_train = np.array(valid_point_train)
    if args.norm_y:
        y01_divabs = (y01/abs_profit)
        y02_divabs = (y02/abs_profit)
        mean_profit = np.concatenate([y01_divabs[valid_point_train, :], y02_divabs[valid_point_train, :]], axis=0).mean()
        std_profit = np.concatenate([y01_divabs[valid_point_train, :], y02_divabs[valid_point_train, :]], axis=0).std()
        y01_divabs[valid_point_train, :] = (y01_divabs[valid_point_train, :]-mean_profit)/std_profit
        y02_divabs[valid_point_train, :] = (y02_divabs[valid_point_train, :]-mean_profit)/std_profit
    if args.rlbuy_profit_path2[0] == "2":
        args.lag = 1
    if args.lag == 2:
        y01_ = np.load(args.rlbuy_profit_path2+"_11.npy") + np.load(args.rlbuy_profit_path2+"_22.npy")
        y02_ = np.load(args.rlsell_profit_path2+"_11.npy") + np.load(args.rlsell_profit_path2+"_22.npy")
    else:
        y01_ = np.load(args.rlbuy_profit_path2+"_11.npy")
        y02_ = np.load(args.rlsell_profit_path2+"_11.npy") 

    if args.lag == 2:
        valid_buypoint_valid = np.load(args.valid_buypoint_valid+"_11.npy")
        valid_sellpoint_valid = np.load(args.valid_sellpoint_valid+"_11.npy")
        valid_buypoint_valid2 = np.load(args.valid_buypoint_valid+"_22.npy")
        valid_sellpoint_valid2 = np.load(args.valid_sellpoint_valid+"_22.npy")
        valid_buypoint_valid = list(set(valid_buypoint_valid.flatten()).union(set(valid_buypoint_valid2.flatten())))
        valid_sellpoint_valid = list(set(valid_sellpoint_valid.flatten()).union(set(valid_sellpoint_valid2.flatten())))
        valid_buypoint_valid.sort()
        valid_buypoint_valid = np.array(valid_buypoint_valid)
        valid_sellpoint_valid.sort()
        valid_sellpoint_valid = np.array(valid_sellpoint_valid)
    
    else:
        valid_buypoint_valid = np.load(args.valid_buypoint_valid+"_11.npy")
        valid_sellpoint_valid = np.load(args.valid_sellpoint_valid+"_11.npy")
    print(valid_buypoint_valid, valid_sellpoint_valid)
    valid_point_val = list(set(valid_buypoint_valid.flatten()).union(set(valid_sellpoint_valid.flatten())))
    valid_point_val.sort()
    valid_point_val = np.array(valid_point_val)
    y01_divabs_ = y01_
    y02_divabs_ = y02_
    if args.norm_y:
        y01_divabs_ = y01_/abs_profit
        y02_divabs_ = y02_/abs_profit
        y01_divabs_[valid_point_val, :] = (y01_divabs_[valid_point_val, :]-mean_profit)/std_profit
        y02_divabs_[valid_point_val, :] = (y02_divabs_[valid_point_val, :]-mean_profit)/std_profit

    y0 = None
    y2 = None
    vari = None

import gym
from gym import spaces
from gym.spaces import Box, Discrete, Dict, Tuple, MultiBinary, MultiDiscrete
import random

class StockEnv38(gym.Env):
    def __init__(self, fulltest=False, i=0, split="train", num_envs=256, lag1=1, lag2=1):
        self.action_space = spaces.Box(low=-1000.0, high=1000.0, shape=(1, ), dtype=np.float32)
        if split == "train":
            self.data_X = data_X_train
            self.bucket = [bucket_buy11, bucket_buy12, bucket_buy21, bucket_buy22]
            self.valid_sellprice = [valid_sellprice1_1, valid_sellprice1_2]
            self.buy_price_base = buy_price_base1
            self.tpb = [tpb1_1, tpb1_2] 
            self.y0 = y01
            self.length_list = length_list_train

        elif split == "test":
            self.data_X = data_X_test
            self.bucket = [bucket_buy11_, bucket_buy12_, bucket_buy21_, bucket_buy22_]
            self.valid_sellprice = [valid_sellprice2_1, valid_sellprice2_2]
            self.buy_price_base = buy_price_base2
            self.tpb = [tpb2_1, tpb2_2] 
            self.y0 = y02
            self.length_list = length_list_test

        elif split == "test2":
            self.data_X = data_X_test2
            self.bucket = [bucket_buy11__, bucket_buy12__, bucket_buy21__, bucket_buy22__]
            self.valid_sellprice = [valid_sellprice3_1, valid_sellprice3_2]
            self.buy_price_base = buy_price_base3
            self.tpb = [tpb3_1, tpb3_2] 
            self.y0 = y03
            self.length_list = length_list_test2

        elif split == "test4":
            self.data_X = data_X_test4
            self.bucket = [bucket_buy11___, bucket_buy12___, bucket_buy21___, bucket_buy22___]
            self.valid_sellprice = [valid_sellprice4_1, valid_sellprice4_2]
            self.buy_price_base = buy_price_base4
            self.tpb = [tpb4_1, tpb4_2] 
            self.y0 = y04
            self.length_list = length_list_test4
                
        self.observation_space = spaces.Box(low=-1000.0, high=1000.0, shape=(args.input_size, args.T), dtype=np.float32)
        lent = [len(b) for b in self.bucket]
        self.T = args.T
        self.fulltest = fulltest 
        if fulltest:
            self.trajectory_index = i-num_envs
            self.i = i
            self.num_envs = num_envs
            self.lag1 = lag1
            self.lag2 = lag2

    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i] 

    def get_state(self, start, end):
        index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]
        index_00, index_01 = self.get_index(self.length_list, start)
        index_10, index_11 = self.get_index(self.length_list, end)
        if index_00 == index_10:
            x_all_i = torch.from_numpy(self.data_X[index_00][index_01:index_11+1, index_here])
        else:
            assert index_00 +1 == index_10
            x_all_i = torch.from_numpy(np.concatenate([self.data_X[index_00][index_01:, index_here], self.data_X[index_10][:index_11+1, index_here]], axis=0))
        x_all_i = x_all_i[:, index_x]
        X = (((x_all_i/abs_v)-mean)/std).float()
        return X

    def step(self, action):
        # print(action)
        done = False
        execute = False
        buy_price = self.buy_price_base[self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]
        buyable = False
        tpb = self.tpb[self.lag1-1][self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]
        reward = 0
        point = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
        if args.type == "buy":
            if args.learn_bias:
                buy_price = buy_price * (1-action[0]/1e4) * (1+np.clip(action[1]*self.y0[self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]/1e4, -20/1e4, 0))
            else:
                buy_price = buy_price * (1-action/1e4) 
            if tpb <= buy_price-0.01 and tpb != 0:
                buyable = True
                if action >= 0:
                    reward = (self.valid_sellprice[self.lag2-1][point] - buy_price + 0.4/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p
                else:
                    reward = (self.valid_sellprice[self.lag2-1][point] - buy_price - 2/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p
        else:
            if args.lean_bias:
                buy_price = buy_price * (1+action[0]/1e4) * (1+np.clip(action[1]*self.y0[self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]/1e4, 0, 20/1e4))
            else:
                buy_price = buy_price * (1+action/1e4)
            # print(point, buy_price, tpb, tpb >= buy_price+0.01, tpb != 0, self.valid_sellprice[point], (buy_price - self.valid_sellprice[point] + 0.4/1e4*(buy_price + self.valid_sellprice[point]))/args.max_p, args.max_p)
            if tpb >= buy_price+0.01 and tpb != 0:
                buyable = True
                if action >= 0:
                    reward = (buy_price - self.valid_sellprice[self.lag2-1][point] + 0.4/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p
                else:
                    reward = (buy_price - self.valid_sellprice[self.lag2-1][point] - 2/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p

        reward = (reward/abs_profit-mean_profit)/std_profit
        # print(reward, self.rewards[point, 4])

        if self.bin < 5 and reward != (0/abs_profit-mean_profit)/std_profit:
            self.bin += 1
            execute = True
        self.local_step += 1
        if self.local_step == len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index]) or self.bin == 5:
            done = True
        else:
            index_ = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
            self.state = self.get_state(index_-self.T+1, index_)
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy((self.y0[index_-self.T+1:index_+1]/y0_abs_v-y0_mean)/y0_std).unsqueeze(-1)], axis=1)


        info = {"full_range_step":self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step-1], "traj_index":self.trajectory_index, "loc_step":self.local_step, "bin": self.bin, "total_bucket": len(self.bucket[2*(self.lag1-1)+(self.lag2-1)]), "execute": execute}
        if args.not_use_bin_feature:
            return self.state.permute(1, 0), reward, done, info
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0), reward, done, info

    def reset(self):
        import random 
        if not self.fulltest:
            self.lag1 = random.randint(1, 2)
            self.lag2 = random.randint(1, 2)
            # self.lag1, self.lag2 = 1, 1
            self.trajectory_index = random.randrange(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)]))
            while(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index]) == 0):
                self.trajectory_index = random.randrange(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)]))

            self.local_step = 0
            while(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index])
            self.bin = 0
            index_ = self.start_index
            self.state = self.get_state(index_-self.T+1, index_)
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy((self.y0[index_-self.T+1:index_+1]/y0_abs_v-y0_mean)/y0_std).unsqueeze(-1)], axis=1)
        else:
            self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket[2*(self.lag1-1)+(self.lag2-1)])
            while(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index]) == 0):
                self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket[2*(self.lag1-1)+(self.lag2-1)])
            
            self.local_step = 0
            while(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index])
            self.bin = 0
            index_ = self.start_index
            self.state = self.get_state(index_-self.T+1, index_)
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy((self.y0[index_-self.T+1:index_+1]/y0_abs_v-y0_mean)/y0_std).unsqueeze(-1)], axis=1)
        if args.not_use_bin_feature:
            return self.state.permute(1, 0)
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0)

class StockEnv40(gym.Env):
    def __init__(self, fulltest=False, i=0, split="train", num_envs=256, lag1=1, lag2=1, test_field=""):
        self.action_space = spaces.Box(low=-1000.0, high=1000.0, shape=(args.action_size, ), dtype=np.float32)
        self.observation_space = spaces.Box(low=-1000.0, high=1000.0, shape=(args.input_size, args.T), dtype=np.float32)
        self.sell2nd_price_base = sell2nd_price_base
        self.buy_price_base = buy_price_base
        self.tpb = tpb
        self.tps2nd = tps2nd
        self.y0 = y0
        self.valid_buypoint = valid_buypoint
        self.valid_sell2ndpoint = valid_sell2ndpoint
        self.T = args.T
        self.data_X = x
        self.vp = vp

    def step(self, action):
        buyable, sellable = False, False
        done = False
        execute = False
        reward = 0
        point = self.vp[self.local_step]
        reward_back_point, reward_back_step = -1, -1
        if args.type == "buy":
            buy_price = self.buy_price_base[point] * (1-action[0]/1e4) 
            sell_price = self.sell2nd_price_base[point] * (1+action[1]/1e4)
            if self.bin > 0 and self.tps2nd[point] >= sell_price+0.01 and self.tps2nd[point] != 0:
                sellable = True
                reward = (sell_price - self.position_list[0][1] + 0.4/1e4*(self.position_list[0][1] + sell_price))/args.max_p
                self.bin -= 1
                reward_back_point = self.position_list[0][0]
                reward_back_step = self.position_list[0][2]
                del self.position_list[0]
                execute = True

            if self.bin < 5 and self.tpb[point] <= buy_price-0.01 and self.tpb[point] != 0:
                buyable = True
                self.bin += 1
                self.position_list.append((point, buy_price, args.step))
        
        self.local_step += 1
        if self.local_step == len(self.vp):
            done = True
        else:
            index_ = self.vp[self.local_step]
            self.state = (self.data_X[index_-self.T+1:index_+1]-mean)/std

        info = {"full_range_step": self.vp[self.local_step-1], "loc_step":self.local_step, "bin": self.bin, "execute": execute, "buyable":buyable, "sellable":sellable, "reward_back":(reward_back_point, reward_back_step)}
        return self.state.permute(1, 0), reward, done, info

    def reset(self):
        import random 
        self.local_step = random.randrange(len(self.vp))
        index_ = self.vp[self.local_step]
        self.bin = 0
        self.position_list = []
        self.state = (self.data_X[index_-self.T+1:index_+1]-mean)/std
        return self.state.permute(1, 0)

class StockEnv37(gym.Env):
    def __init__(self, fulltest=False, i=0, split="train", num_envs=256, lag1=1, lag2=1):
        self.action_space = spaces.Box(low=-1000.0, high=1000.0, shape=(1, ), dtype=np.float32)
        if split == "train":
            self.data_X = x
            self.bucket = [bucket_buy11, bucket_buy12, bucket_buy21, bucket_buy22]
            self.valid_sellprice = [valid_sellprice1_1, valid_sellprice1_2]
            self.buy_price_base = buy_price_base1
            self.tpb = [tpb1_1, tpb1_2] 
            self.y0 = y01

        elif split == "test":
            self.data_X = x2
            self.bucket = [bucket_buy11_, bucket_buy12_, bucket_buy21_, bucket_buy22_]
            self.valid_sellprice = [valid_sellprice2_1, valid_sellprice2_2]
            self.buy_price_base = buy_price_base2
            self.tpb = [tpb2_1, tpb2_2] 
            self.y0 = y02

        elif split == "test2":
            self.data_X = x3
            self.bucket = [bucket_buy11__, bucket_buy12__, bucket_buy21__, bucket_buy22__]
            self.valid_sellprice = [valid_sellprice3_1, valid_sellprice3_2]
            self.buy_price_base = buy_price_base3
            self.tpb = [tpb3_1, tpb3_2] 
            self.y0 = y03

        elif split == "test4":
            self.data_X = x4
            self.bucket = [bucket_buy11___, bucket_buy12___, bucket_buy21___, bucket_buy22___]
            self.valid_sellprice = [valid_sellprice4_1, valid_sellprice4_2]
            self.buy_price_base = buy_price_base4
            self.tpb = [tpb4_1, tpb4_2] 
            self.y0 = y04
                
        self.observation_space = spaces.Box(low=-1000.0, high=1000.0, shape=(args.input_size, args.T), dtype=np.float32)
        lent = [len(b) for b in self.bucket]
        self.T = args.T
        self.fulltest = fulltest 
        if fulltest:
            self.trajectory_index = i-num_envs
            self.i = i
            self.num_envs = num_envs
            self.lag1 = lag1
            self.lag2 = lag2

            
    def step(self, action):
        
        # print(action)
        done = False
        execute = False
        buy_price = self.buy_price_base[self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]
        buyable = False
        tpb = self.tpb[self.lag1-1][self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]
        reward = 0
        point = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
        if args.type == "buy":
            if args.learn_bias:
                buy_price = buy_price * (1-action[0]/1e4) * (1+np.clip(action[1]*self.y0[self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]/1e4, -20/1e4, 0))
            else:
                buy_price = buy_price * (1-action/1e4) 
            if tpb <= buy_price-0.01 and tpb != 0:
                buyable = True
                # if action >= 0:
                reward = (self.valid_sellprice[self.lag2-1][point] - buy_price + 0.4/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p
                # else:
                #    reward = (self.valid_sellprice[self.lag2-1][point] - buy_price - 2/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p
        else:
            if args.learn_bias:
                buy_price = buy_price * (1+action[0]/1e4) * (1+np.clip(action[1]*self.y0[self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]]/1e4, 0, 20/1e4))
            else:
                buy_price = buy_price * (1+action/1e4)
            # print(point, buy_price, tpb, tpb >= buy_price+0.01, tpb != 0, self.valid_sellprice[point], (buy_price - self.valid_sellprice[point] + 0.4/1e4*(buy_price + self.valid_sellprice[point]))/args.max_p, args.max_p)
            if tpb >= buy_price+0.01 and tpb != 0:
                buyable = True
                # if action >= 0:
                reward = (buy_price - self.valid_sellprice[self.lag2-1][point] + 0.4/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p
                # else:
                    # reward = (buy_price - self.valid_sellprice[self.lag2-1][point] - 2/1e4*(buy_price + self.valid_sellprice[self.lag2-1][point]))/args.max_p
        if args.arch == "TSTransformerEncoderRLSeq2" and action == 6:
            reward = 0
        if args.arch == "TSTransformerEncoderRLSeq3" and action > args.bin and args.test_clamp:
            reward = 0

        reward = (reward/abs_profit-mean_profit)/std_profit
        # print(reward, self.rewards[point, 4])

        if self.bin < args.bin and reward != (0/abs_profit-mean_profit)/std_profit:
            self.bin += 1
            execute = True
        self.local_step += 1
        if args.early_stop:
            conditon = (self.local_step == len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index])) or (self.bin == args.bin)
        else:
            conditon = self.local_step == len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index])
        if conditon:
            done = True
            # print(self.local_step, len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index]), self.bin)
        else:
            index_ = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
            self.state = (self.data_X[index_-self.T+1:index_+1]-mean)/std
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy((self.y0[index_-self.T+1:index_+1]/y0_abs_v-y0_mean)/y0_std).unsqueeze(-1)], axis=1)


        info = {"full_range_step":self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step-1], "traj_index":self.trajectory_index, "loc_step":self.local_step, "bin": self.bin, "total_bucket": len(self.bucket[2*(self.lag1-1)+(self.lag2-1)]), "execute": execute}
        if args.not_use_bin_feature:
            return self.state.permute(1, 0), reward, done, info
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0), reward, done, info

    def reset(self):
        import random 
        if not self.fulltest:
            self.lag1 = random.randint(1, 2)
            self.lag2 = random.randint(1, 2)
            if args.for_test_lag1:
                self.lag1, self.lag2 = 1, 1
            self.trajectory_index = random.randrange(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)]))
            while(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index]) == 0):
                self.trajectory_index = random.randrange(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)]))

            self.local_step = 0
            while(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index])
            self.bin = 0
            index_ = self.start_index
            self.state = (self.data_X[index_-self.T+1:index_+1]-mean)/std
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy((self.y0[index_-self.T+1:index_+1]/y0_abs_v-y0_mean)/y0_std).unsqueeze(-1)], axis=1)
        else:
            self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket[2*(self.lag1-1)+(self.lag2-1)])
            while(len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index]) == 0):
                self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket[2*(self.lag1-1)+(self.lag2-1)])
            
            self.local_step = 0
            while(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[2*(self.lag1-1)+(self.lag2-1)][self.trajectory_index])
            self.bin = 0
            index_ = self.start_index
            self.state = (self.data_X[index_-self.T+1:index_+1]-mean)/std
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy((self.y0[index_-self.T+1:index_+1]/y0_abs_v-y0_mean)/y0_std).unsqueeze(-1)], axis=1)
        if args.not_use_bin_feature:
            return self.state.permute(1, 0)
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0)


class StockEnv36(gym.Env):
    def __init__(self, fulltest=False, i=0, split="train", num_envs=256):
        self.action_space = spaces.Box(low=-1000.0, high=1000.0, shape=(1, ), dtype=np.float32)
        if split == "train":
            self.data_X = x
            self.rewards = y01_divabs
            self.bucket = bucket_buy
            self.valid_sellprice = valid_sellprice1
            self.buy_price_base = buy_price_base1
            self.tpb = tpb1
            self.y0 = y01
        elif split == "test":
            self.data_X = x2
            self.rewards = y01_divabs_
            self.bucket = bucket_buy_
            self.valid_sellprice = valid_sellprice2
            self.buy_price_base = buy_price_base2
            self.tpb = tpb2
            self.y0 = y02

        elif split == "test2":
            self.data_X = x3
            self.rewards = y01_divabs__
            self.bucket = bucket_buy__
            self.valid_sellprice = valid_sellprice3
            self.buy_price_base = buy_price_base3
            self.tpb = tpb3
            self.y0 = y03

        elif split == "test4":
            self.data_X = x4
            self.rewards = y01_divabs___
            self.bucket = bucket_buy___
            self.valid_sellprice = valid_sellprice4
            self.buy_price_base = buy_price_base4
            self.tpb = tpb4
            self.y0 = y04
        if args.consider_y0:
            self.y0 = (self.y0/y0_abs_v-y0_mean)/y0_std
        
        self.observation_space = spaces.Box(low=-1000.0, high=1000.0, shape=(args.input_size, args.T), dtype=np.float32)
        lent = [len(b) for b in self.bucket]
        self.T = args.T
        self.fulltest = fulltest 
        if fulltest:
            self.trajectory_index = i-num_envs
            self.i = i
            self.num_envs = num_envs
            
    def step(self, action):
        # print(action)
        done = False
        execute = False
        buy_price = self.buy_price_base[self.bucket[self.trajectory_index][self.local_step]]
        buyable = False
        tpb = self.tpb[self.bucket[self.trajectory_index][self.local_step]]
        reward = 0
        point = self.bucket[self.trajectory_index][self.local_step]
        if args.type == "buy":
            buy_price = buy_price * (1-action/1e4) 
            
            if tpb <= buy_price-0.01 and tpb != 0:
                buyable = True
                if action >= 0:
                    reward = (self.valid_sellprice[point] - buy_price + 0.4/1e4*(buy_price + self.valid_sellprice[point]))/args.max_p
                else:
                    reward = (self.valid_sellprice[point] - buy_price - 2/1e4*(buy_price + self.valid_sellprice[point]))/args.max_p
        else:
            buy_price = buy_price * (1+action/1e4)
            # print(point, buy_price, tpb, tpb >= buy_price+0.01, tpb != 0, self.valid_sellprice[point], (buy_price - self.valid_sellprice[point] + 0.4/1e4*(buy_price + self.valid_sellprice[point]))/args.max_p, args.max_p)
            if tpb >= buy_price+0.01 and tpb != 0:
                buyable = True
                if action >= 0:
                    reward = (buy_price - self.valid_sellprice[point] + 0.4/1e4*(buy_price + self.valid_sellprice[point]))/args.max_p
                else:
                    reward = (buy_price - self.valid_sellprice[point] - 2/1e4*(buy_price + self.valid_sellprice[point]))/args.max_p

        reward = (reward/abs_profit-mean_profit)/std_profit
        # print(reward, self.rewards[point, 4])

        if self.bin < 5 and reward != (0/abs_profit-mean_profit)/std_profit:
            self.bin += 1
            execute = True
        self.local_step += 1
        if self.local_step == len(self.bucket[self.trajectory_index]) or self.bin == 5:
            done = True
        else:
            index_ = self.bucket[self.trajectory_index][self.local_step]
            self.state = (self.data_X[index_-self.T+1:index_+1]-mean)/std
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy(self.y0[index_-self.T+1:index_+1]).unsqueeze(-1)], axis=1)


        info = {"full_range_step":self.bucket[self.trajectory_index][self.local_step-1], "traj_index":self.trajectory_index, "loc_step":self.local_step, "bin": self.bin, "total_bucket": len(self.bucket), "execute": execute}
        if args.not_use_bin_feature:
            return self.state.permute(1, 0), reward, done, info
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0), reward, done, info

    def reset(self):
        if not self.fulltest:
            self.trajectory_index = random.randrange(len(self.bucket))
            while(len(self.bucket[self.trajectory_index]) == 0):
                self.trajectory_index = random.randrange(len(self.bucket))

            self.local_step = 0
            while(self.bucket[self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[self.trajectory_index])
            self.bin = 0
            self.state = (self.data_X[self.start_index-self.T+1:self.start_index+1]-mean)/std
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy(self.y0[self.start_index-self.T+1:self.start_index+1]).unsqueeze(-1)], axis=1)
        else:
            self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket)
            while(len(self.bucket[self.trajectory_index]) == 0):
                self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket)
            
            self.local_step = 0
            while(self.bucket[self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[self.trajectory_index])
            self.bin = 0
            self.state = (self.data_X[self.start_index-self.T+1:self.start_index+1]-mean)/std
            if args.consider_y0:
                self.state = torch.cat([self.state, torch.from_numpy(self.y0[self.start_index-self.T+1:self.start_index+1]).unsqueeze(-1)], axis=1)
        if args.not_use_bin_feature:
            return self.state.permute(1, 0)
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0)

class StockEnv35(gym.Env):
    def __init__(self, fulltest=False, i=0, split="train", num_envs=256):
        self.action_space = spaces.Discrete(7)
        if split == "train":
            self.data_X = data_X_train
            self.length_list = length_list_train
            self.rewards = y01_divabs
            self.bucket = bucket_buy
        elif split == "test":
            self.data_X = data_X_test
            self.length_list = length_list_test
            self.rewards = y01_divabs_
            self.bucket = bucket_buy_
        elif split == "test2":
            self.data_X = data_X_test2
            self.length_list = length_list_test2
            self.rewards = y01_divabs__
            self.bucket = bucket_buy__
        elif split == "test4":
            self.data_X = data_X_test4
            self.length_list = length_list_test4
            self.rewards = y01_divabs___
            self.bucket = bucket_buy___
        self.observation_space = spaces.Box(low=-1000.0, high=1000.0, shape=(args.input_size, args.T), dtype=np.float32)
        
        lent = [len(b) for b in self.bucket]
        self.T = args.T
        self.fulltest = fulltest 
        if fulltest:
            self.trajectory_index = i-num_envs
            self.i = i
            self.num_envs = num_envs
    

    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i] 

    def get_state(self, start, end):
        index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]
        index_00, index_01 = self.get_index(self.length_list, start)
        index_10, index_11 = self.get_index(self.length_list, end)
        if index_00 == index_10:
            x_all_i = torch.from_numpy(self.data_X[index_00][index_01:index_11+1, index_here])
        else:
            assert index_00 +1 == index_10
            x_all_i = torch.from_numpy(np.concatenate([self.data_X[index_00][index_01:, index_here], self.data_X[index_10][:index_11+1, index_here]], axis=0))
        X = (((x_all_i/abs_v)-mean)/std).float()
        return X

    def step(self, action):
        done = False
        execute = False
        reward = self.rewards[self.bucket[self.trajectory_index][self.local_step]][action]
        if self.bin < 5 and reward != self.rewards[self.bucket[self.trajectory_index][self.local_step], 6]:
            self.bin += 1
            execute = True
        self.local_step += 1
        if self.local_step == len(self.bucket[self.trajectory_index]) or self.bin == 5:
            done = True
        else:
            index_ = self.bucket[self.trajectory_index][self.local_step]
            self.state = self.get_state(index_-self.T+1, index_)

        info = {"full_range_step":self.bucket[self.trajectory_index][self.local_step-1], "traj_index":self.trajectory_index, "loc_step":self.local_step, "bin": self.bin, "total_bucket": len(self.bucket), "execute": execute}
        if args.not_use_bin_feature:
            return self.state.permute(1, 0), reward, done, info
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0), reward, done, info

    def reset(self):
        if not self.fulltest:
            self.trajectory_index = random.randrange(len(self.bucket))
            while(len(self.bucket[self.trajectory_index]) == 0):
                self.trajectory_index = random.randrange(len(self.bucket))
            self.local_step = 0
            while(self.bucket[self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[self.trajectory_index])
            self.bin = 0
            self.state = self.get_state(self.start_index-self.T+1, self.start_index)
        else:
            self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket)
            while(len(self.bucket[self.trajectory_index]) == 0):
                self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket)
            self.local_step = 0
            while(self.bucket[self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[self.trajectory_index])
            self.bin = 0
            self.state =  self.get_state(self.start_index-self.T+1, self.start_index)
        if args.not_use_bin_feature:
            return self.state.permute(1, 0)
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0)

class StockEnv(gym.Env):
    def __init__(self, fulltest=False, i=0, split="train", num_envs=256):
        self.action_space = spaces.Discrete(7)
        if split == "train":
            self.data_X = x
            self.rewards = y01_divabs
            self.bucket = bucket_buy
        elif split == "test":
            self.data_X = x2
            self.rewards = y01_divabs_
            self.bucket = bucket_buy_
        elif split == "test2":
            self.data_X = x3
            self.rewards = y01_divabs__
            self.bucket = bucket_buy__
        elif split == "test4":
            self.data_X = x4
            self.rewards = y01_divabs___
            self.bucket = bucket_buy___
        # for j in range(6):
        #     print("j sum", j, np.sum(y01_divabs[:, j]))
        self.observation_space = spaces.Box(low=-1000.0, high=1000.0, shape=(args.input_size, args.T), dtype=np.float32)
        
        lent = [len(b) for b in self.bucket]
        self.T = args.T
        self.fulltest = fulltest 
        if fulltest:
            self.trajectory_index = i-num_envs
            self.i = i
            self.num_envs = num_envs
    def step(self, action):
        done = False
        execute = False
        # print("self.local_step, self.trajectory_index, self.bucket[self.trajectory_index], self.bucket[self.trajectory_index][self.local_step], self.rewards[self.bucket[self.trajectory_index][self.local_step]], reward", self.local_step, self.trajectory_index)
        # print(self.bucket[self.trajectory_index])
        # print(self.bucket[self.trajectory_index][self.local_step])
        # print(self.rewards[self.bucket[self.trajectory_index][self.local_step]])
        reward = self.rewards[self.bucket[self.trajectory_index][self.local_step]][action]
        
        # print("self.local_step, self.trajectory_index, self.bucket[self.trajectory_index], self.bucket[self.trajectory_index][self.local_step], self.rewards[self.bucket[self.trajectory_index][self.local_step]], reward", self.local_step, self.trajectory_index, self.bucket[self.trajectory_index], self.bucket[self.trajectory_index][self.local_step], self.rewards[self.bucket[self.trajectory_index][self.local_step]], reward)
        # print("bin", self.bin)
        # print(reward, self.rewards[self.bucket[self.trajectory_index][self.local_step], 6])
        
        if self.bin < 5 and reward != self.rewards[self.bucket[self.trajectory_index][self.local_step], 6]:
            # print("accumulate", self.bin)
            self.bin += 1
            execute = True
        self.local_step += 1
        if self.local_step == len(self.bucket[self.trajectory_index]) or self.bin == 5:
            # print("done", self.i, self.trajectory_index, self.bin, self.local_step, len(self.bucket[self.trajectory_index]))
            done = True
        else:
            index_ = self.bucket[self.trajectory_index][self.local_step]
            self.state = (self.data_X[index_-self.T+1:index_+1]-mean)/std
            


        info = {"full_range_step":self.bucket[self.trajectory_index][self.local_step-1], "traj_index":self.trajectory_index, "loc_step":self.local_step, "bin": self.bin, "total_bucket": len(self.bucket), "execute": execute}
        # print(self.i, reward)
        # return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0), reward, done, info
        if args.not_use_bin_feature:
            return self.state.permute(1, 0), reward, done, info
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0), reward, done, info

    def reset(self):
        if not self.fulltest:
            self.trajectory_index = random.randrange(len(self.bucket))
            while(len(self.bucket[self.trajectory_index]) == 0):
                self.trajectory_index = random.randrange(len(self.bucket))
            self.start_index = self.bucket[self.trajectory_index][0]
            self.total_steps = len(self.bucket[self.trajectory_index])
            self.local_step = 0
            self.bin = 0
            self.state = (self.data_X[self.start_index-self.T+1:self.start_index+1]-mean)/std
        else:
            self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket)
            while(len(self.bucket[self.trajectory_index]) == 0):
                self.trajectory_index = (self.trajectory_index + self.num_envs) % len(self.bucket)
            
            # print("reset i", self.i, self.trajectory_index )
            self.local_step = 0
            while(self.bucket[self.trajectory_index][self.local_step]-args.T+1 < 0):
                self.local_step += 1
            self.start_index = self.bucket[self.trajectory_index][self.local_step]
            self.total_steps = len(self.bucket[self.trajectory_index])
            self.bin = 0
            # print(self.start_index-self.T+1, self.start_index+1, self.bucket[self.trajectory_index], self.trajectory_index)
            self.state = (self.data_X[self.start_index-self.T+1:self.start_index+1]-mean)/std
            # print(self.state, self.data_X[9198900:9199000], self.data_X.size())
        # print(self.state.permute(1, 0).size(), torch.ones((1, args.T)).size())
        if args.not_use_bin_feature:
            return self.state.permute(1, 0)
        else:    
            return torch.cat([self.state.permute(1, 0), torch.ones((1, args.T))*float(self.bin)/5], axis=0)


class StockAggregate34(data.Dataset):
    def __init__(self, b_obs, b_logprobs, b_actions, b_advantages, b_returns, b_values):
        self.b_obs = b_obs
        self.b_logprobs = b_logprobs
        self.b_actions = b_actions
        self.b_advantages = b_advantages
        self.b_returns = b_returns
        self.b_values = b_values

    def __getitem__(self, index):
        return self.b_obs[index], self.b_logprobs[index], self.b_actions[index], self.b_advantages[index], self.b_returns[index], self.b_values[index]

    def __len__(self):
        return self.b_obs.size(0)


class StockAggregate36(data.Dataset):
    def __init__(self, b_obs, b_logprobs, b_actions, b_returns):
        self.b_obs = b_obs
        self.b_logprobs = b_logprobs
        self.b_actions = b_actions
        self.b_returns = b_returns
        

    def __getitem__(self, index):
        return self.b_obs[index], self.b_logprobs[index], self.b_actions[index], self.b_returns[index]

    def __len__(self):
        return self.b_obs.size(0)

  
class StockAggregate42(data.Dataset):
    def __init__(self, b_obs, b_logprobs, b_actions, b_returns, indices):
        self.b_obs = b_obs
        self.b_logprobs = b_logprobs
        self.b_actions = b_actions
        self.b_returns = b_returns
        self.indices = indices
        self.T = args.T

    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))
        index_ = self.indices[index]
        X = (self.b_obs[index_-self.T+1:index_+1, :]-mean)/std
        return X.permute(1, 0).float(), self.b_logprobs[index], self.b_actions[index], self.b_returns[index]

    def __len__(self):
        return self.indices.size(0)


  
class StockAggregate43(data.Dataset):
    def __init__(self, b_obs, b_logprobs, b_logprobs2, b_actions, b_actions2, b_returns, indices):
        self.b_obs = b_obs
        self.b_logprobs = b_logprobs
        self.b_logprobs2 = b_logprobs2
        self.b_actions = b_actions
        self.b_actions2 = b_actions2
        self.b_returns = b_returns
        self.indices = indices
        self.T = args.T

    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))
        index_ = self.indices[index]
        X = (self.b_obs[index_-self.T+1:index_+1, :]-mean)/std
        return X.permute(1, 0).float(), self.b_logprobs[index], self.b_logprobs2[index], self.b_actions[index], self.b_actions2[index], self.b_returns[index]

    def __len__(self):
        return self.indices.size(0)
    
class StockAggregate37(data.Dataset):
    def __init__(self, b_obs, b_logprobs, b_actions, b_returns):
        self.b_obs = b_obs
        self.b_logprobs = b_logprobs
        self.b_actions = b_actions
        self.b_returns = b_returns
        # self.indices = train_indices
        self.indices = torch.arange(args.T-1, self.b_obs.size(0))
        self.T = args.T

    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))
        index_ = self.indices[index]
        X = (self.b_obs[index_-self.T+1:index_+1, :]-mean)/std
        return X.permute(1, 0).float(), self.b_logprobs[index_], self.b_actions[index_], self.b_returns[index_]

    def __len__(self):
        return self.indices.size(0)


class StockAggregate38(data.Dataset):
    def __init__(self, split, type="buy", test_field=""):
        if args.use_p23 == 100:
            self.data_X = torch.from_numpy(np.load("55data_backtest.npy"))/abs_v
            self.indices = torch.arange(args.T-1, self.data_X.size(0))
        else:
            
            if split == "train":
                self.data_X = x
            elif split == "test":
                self.data_X = x2
            elif split == "test2":
                self.data_X = x3
            elif split == "test4":
                self.data_X = x4

            if args.predict_all:
                self.indices = torch.arange(args.T-1, self.data_X.size(0))
            else:
                if args.t2:
                    abbr = "2"
                else:
                    abbr = ""
                if args.use_p23 != 101:
                    if args.type == "buy":
                        vb1 = np.load(abbr+str(args.profit_type)+"dout4valid_buypoint_0"+"_"+";".join(test_field)+"std_11.npy")
                        vb3 = np.load(abbr+str(args.profit_type)+"dout4valid_sell2ndpoint_0"+"_"+";".join(test_field)+"std_11.npy")
                    else:
                        vb1 = np.load(abbr+str(args.profit_type)+"dout4valid_sellpoint_0"+"_"+";".join(test_field)+"std_11.npy")
                        vb3 = np.load(abbr+str(args.profit_type)+"dout4valid_buy2ndpoint_0"+"_"+";".join(test_field)+"std_11.npy")
                else:
                    abbr = "2"
                    profit_type = 19
                    dout = 4
                    lag1, lag2 = 1, 1 
                    m1, m2 = args.m1, args.m2
                    p1 = np.load(str(args.profit_type)+"dout"+str(dout)+"y0"+"_"+";".join(test_field)+"std"+".npy")
                    buy_price_base = np.load(abbr+str(profit_type)+"dout"+str(dout)+"buy_price_basenop"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy") * (1+np.clip(m2*p1/1e4, -20/1e4, 0))
                    sell_price_base = np.load(abbr+str(profit_type)+"dout"+str(dout)+"sell_price_basenop"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy") * (1+np.clip(m1*p1/1e4, 0, 20/1e4))
                    tpb = np.load(abbr+str(profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy")
                    tps = np.load(abbr+str(profit_type)+"dout"+str(dout)+"tps2nd"+"_"+";".join(test_field)+"std"+"_"+str(lag1)+str(lag2)+".npy")
                    vb1 = np.logical_and(tpb <= buy_price_base-0.01, tpb != 0).nonzero()[0]
                    vb3 = np.logical_and(tps >= sell_price_base+0.01, tps != 0).nonzero()[0]
                
                vb = list(set(vb1.flatten()).union(set(vb3.flatten())))
                vb.sort()
                vb = np.array(vb)
                self.indices = torch.from_numpy(vb)
        self.T = args.T

    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))
        index_ = self.indices[index]
        X = (self.data_X[index_-self.T+1:index_+1, :]-mean)/std
        return X.permute(1, 0).float(), torch.ones(1,1), index_, torch.ones(1,1)

    def __len__(self):    
        return self.indices.size(0)

class StockAggregate33(data.Dataset):
    def __init__(self, split, xnn=None, x=None):
        self.split = split
        if split == "train":
            if args.train[0] == "08_11-09_15":
                data_y1 = np.concatenate([y01_divabs, y02_divabs], axis=1)
                self.indices = torch.from_numpy(valid_point_train)
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_08_11-09_15.npy', dtype='float32', mode='r', shape=(total_length1, 645))
                self.data_y = [torch.from_numpy(data_y1)]
                self.data_X = [data_X1]
                self.length_list = [total_length1]
        else:
            if args.test[0] == "09_16-09_25":
                data_y1 = np.concatenate([y01_divabs_, y02_divabs_], axis=1)
                self.indices = torch.from_numpy(valid_point_val)
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_09_16-09_25.npy', dtype='float32', mode='r', shape=(total_length1, 645))
                self.data_y = [torch.from_numpy(data_y1)]
                self.data_X = [data_X1]
                self.length_list = [total_length1]
            elif args.test[0] == "09_26-10_12":
                data_y1 = np.concatenate([y01_divabs_, y02_divabs_], axis=1)
                self.indices = torch.from_numpy(valid_point_val)
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_09_26-10_12.npy', dtype='float32', mode='r', shape=(total_length1, 645))
                self.data_y = [torch.from_numpy(data_y1)]
                self.data_X = [data_X1]
                self.length_list = [total_length1]


        self.T = args.T
    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i] 

    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))
        index_ = self.indices[index]
        index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]
        index_0, index_1 = self.get_index(self.length_list, index_)
        x_all_i = torch.from_numpy(self.data_X[index_0][index_1-self.T+1:index_1+1, index_here])
        X = (((x_all_i/abs_v)-mean)/std).float()
        y = torch.tensor(self.data_y[index_0][index_1]).float()
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), y, index_, mask

    def __len__(self):
        return self.indices.size(0)


class StockAggregate35(data.Dataset):
    def __init__(self, split, type="buy"):
        if args.use_p23 == 100:
            self.data_X = torch.from_numpy(np.load("55data_backtest.npy"))/abs_v
            self.indices = torch.arange(args.T-1, self.data_X.size(0))
        else:
            index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
            if split == "train":
                self.data_X = x
                if args.predict_all:
                    self.indices = torch.arange(args.T-1, self.data_X.size(0))
                else:
                    vb1 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.train)+"std_11.npy")
                    vb2 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.train)+"std_22.npy")
                    vb = list(set(vb1.flatten()).union(set(vb2.flatten())))
                    vb.sort()
                    vb = np.array(vb)
                    self.indices = torch.from_numpy(vb)
                    

            elif split == "test":
                self.data_X = x2
                if args.predict_all:
                    self.indices = torch.arange(args.T-1, self.data_X.size(0))
                else:
                    vb1 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.test)+"std_11.npy")
                    vb2 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.test)+"std_22.npy")
                    vb = list(set(vb1.flatten()).union(set(vb2.flatten())))
                    vb.sort()
                    vb = np.array(vb)
                    self.indices = torch.from_numpy(vb)

            elif split == "test2":
                self.data_X = x3
                if args.predict_all:
                    self.indices = torch.arange(args.T-1, self.data_X.size(0))
                else:
                    vb1 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.test2)+"std_11.npy")
                    vb2 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.test2)+"std_22.npy")
                    vb = list(set(vb1.flatten()).union(set(vb2.flatten())))
                    vb.sort()
                    vb = np.array(vb)
                    self.indices = torch.from_numpy(vb)

            elif split == "test4":
                self.data_X = x4
                if args.predict_all:
                    self.indices = torch.arange(args.T-1, self.data_X.size(0))
                else:
                    vb1 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.test4)+"std_11.npy")
                    vb2 = np.load(str(args.profit_type)+"dout4valid_"+args.type+"point"+"_"+";".join(args.test4)+"std_22.npy")
                    vb = list(set(vb1.flatten()).union(set(vb2.flatten())))
                    vb.sort()
                    vb = np.array(vb)
                    self.indices = torch.from_numpy(vb)

        self.T = args.T

    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))
        index_ = self.indices[index]
        X = (self.data_X[index_-self.T+1:index_+1, :]-mean)/std
        return X.permute(1, 0).float(), torch.ones(1,1), index_, torch.ones(1,1)

    def __len__(self):    
        return self.indices.size(0)



class StockAggregate32(data.Dataset):
    def __init__(self, split, type="buy"):
        if split == "train":
            self.data_X = x
            self.data_y = np.concatenate([y01_divabs, y02_divabs], axis=1)
            self.indices = torch.from_numpy(valid_point_train)
            
        elif split == "test":
            self.data_X = x2
            self.data_y = np.concatenate([y01_divabs_, y02_divabs_], axis=1)
            self.indices = torch.from_numpy(valid_point_val)
        elif split == "test2":
            self.data_X = x       
            self.data_y = y
            
        self.T = args.T
        self.data_y = torch.from_numpy(self.data_y)
        # print(self.data_y.size())
        if args.train_all_data:
            self.indices = torch.arange(args.T-1, self.data_X.size(0))


    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))

        index_ = self.indices[index]
        X = (self.data_X[index_-self.T+1:index_+1, :]-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index_].float(), index_, mask

    def __len__(self):    
        return self.indices.size(0)

class StockAggregate29(data.Dataset):
    def __init__(self, split, xnn=None, x=None):
        self.split = split
        if split == "train":
            if args.train[0] == "08_11-09_15":
                start, end = 0, 0
                total_length1 = load_data_length("08_11-09_02", "y")
                end += total_length1
                data_y1 = y[start:end]
                start = end
                data_X1 = np.memmap('data_6/x_absall_08_11-09_02.npy', dtype='float32', mode='r', shape=(total_length1,1062))
                total_length2 = load_data_length("09_03-09_07", "y")
                end += total_length2
                data_y2 = y[start:end]
                start = end
                data_X2 = np.memmap('data_6/x_absall_09_03-09_07.npy', dtype='float32', mode='r', shape=(total_length2,1062))
                total_length3 = load_data_length("09_08-09_15", "y")
                end += total_length3
                data_y3 = y[start:end]
                data_X3 = np.memmap('data_6/x_absall_09_08-09_15.npy', dtype='float32', mode='r', shape=(total_length3,1062))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "08_11-09_05":
                data_y1 = y
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length1, 645))
                self.data_y = [data_y1]
                self.data_X = [data_X1]
                self.length_list = [total_length1-args.T+1]
        else:

            self.data_X = [xnn, x]
        self.T = args.T
            
    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i] 

    def __getitem__(self, index):
        if self.split == "train":
            index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]
            index_0, index_1 = self.get_index(self.length_list, index)
            x_all_i = torch.from_numpy(self.data_X[index_0][index_1:index_1+self.T, index_here])
            X = (((x_all_i/abs_v)-mean)/std).float()
            y = torch.tensor(self.data_y[index_0][index_1+self.T-1]).float()
        else:
            xnn_i = torch.from_numpy(self.data_X[0][index:index+self.T, index_all])
            x_i = torch.from_numpy(self.data_X[1][index:index+self.T])
            x_all_i = torch.cat([xnn_i, x_i], dim=1)
            X = (((x_all_i/abs_v)-mean)/std).float()
            y = torch.ones(1,1)
        mask = torch.ones(1,1)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        if self.split == "train":
            return sum(self.length_list)
        else:
            return self.data_X[1].shape[0]-self.T+1

class StockAggregate30(data.Dataset):
    def __init__(self, split):
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        if split == "train":
            self.data_X = x
            self.data_y = [y01_divabs, y02_divabs]
            self.indices = torch.from_numpy(valid_point_train)
        elif split == "test":
            self.data_X = x2
            self.data_y = y2
            
        elif split == "test2":
            self.data_X = x       
            self.data_y = y
        self.T = args.T
        self.data_y = torch.from_numpy(self.data_y)


    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index+self.T-1].float(), index, mask

    def __len__(self):    
        return len(self.data_X)-self.T+1

class StockAggregate31(data.Dataset):
    def __init__(self, split):
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        if split == "train":
            self.data_X = x
            self.data_y = y
            self.indices = torch.from_numpy(valid_point_train)
        elif split == "test":
            self.data_X = x2
            self.data_y = y2
            
            self.indices = torch.from_numpy(valid_point_valid)
        elif split == "test2":
            self.data_X = x       
            self.data_y = y
        self.T = args.T
        self.data_y = torch.from_numpy(self.data_y)
        print(self.data_y.size())


    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))

        index_ = self.indices[index]
        X = (self.data_X[index_-self.T+1:index_+1, :]-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index_].float(), index_, mask

    def __len__(self):    
        return self.indices.size(0)

import random


class StockAggregate27(data.Dataset):
    def __init__(self, split, xnn=None, x=None, y=None, xabs=None):
        self.split = split
        if split == "train":
            if args.train[0] == "08_11-09_15":
                data_y1 = np.load('data_6/y_all_08_11-09_15.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_absall_08_11-09_15.npy', dtype='float32', mode='r', shape=(total_length1, 1062))
                self.data_y = [data_y1]
                self.data_X = [data_X1]
                self.length_list = [total_length1-args.T+1]
            if args.train[0] == "08_08-09_07":
                data_y1 = np.load('data_6/y_all_08_08-09_02.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_absall_08_08-09_02.npy', dtype='float32', mode='r', shape=(total_length1, 1062))
                data_y2 = np.load('data_6/y_all_09_03-09_07.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_absall_09_03-09_07.npy', dtype='float32', mode='r', shape=(total_length2, 1062))
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
        else:
            self.data_X = [xnn, x, xabs]
            self.data_y = y
        self.T = args.T
            
    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i] 

    def __getitem__(self, index):


        if self.split == "train":
            if args.use_p23 == 5:
                index_here = [i for i in range(32)] + [i for i in range(57, 1062)]
            if args.use_p23 == 7:
                index_here = [i for i in range(32)] + [33] + [i for i in range(57, 1062)]
            if args.use_p23 == 9:
                index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]
            
            index_0, index_1 = self.get_index(self.length_list, index)
            x_all_i = torch.from_numpy(self.data_X[index_0][index_1:index_1+self.T, index_here])
            X = (((x_all_i/abs_v)-mean)/std).float()
            y = torch.tensor(self.data_y[index_0][index_1+self.T-1]).float()
        else:
            xnn_i = torch.from_numpy(self.data_X[0][index:index+self.T, index_all])
            x_i = torch.from_numpy(self.data_X[1][index:index+self.T])
            xabs_i = torch.from_numpy(self.data_X[2][index:index+self.T, index_xabs])
            x_all_i = torch.cat([xnn_i, x_i, xabs_i], dim=1)
            X = (((x_all_i/abs_v)-mean)/std).float()
        mask = torch.ones(1,1)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        if self.split == "train":
            return sum(self.length_list)
        else:
            return self.data_y.shape[0]-self.T+1



class StockAggregate26(data.Dataset):
    def __init__(self, split):
        self.data_X = x
        self.data_y = y
        if split == "train":
            self.indices = torch.from_numpy(valid_point_train)
        elif split == "test":
            self.indices = torch.from_numpy(valid_point_valid)
        elif split == "test2":
            self.indices = torch.from_numpy(valid_point)
        self.T = args.T
        self.data_y = torch.from_numpy(y)

    def __getitem__(self, index):
        while(self.indices[index]-self.T+1 < 0):
            index = random.randrange(0, self.indices.size(0))
        index_ = self.indices[index]
        X = (self.data_X[index_-self.T+1:index_+1, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index_].float(), index, mask

    def __len__(self):    
        return self.indices.size(0)

class StockAggregate25(data.Dataset):
    def __init__(self, split):
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        
        if split == "train":
            self.data_X = x[arr[0:11000000]]     
            self.data_y = y[arr[0:11000000]]
        elif split == "test":
            self.data_X = x[arr[11000000:]]          
            self.data_y = y[arr[11000000:]]
        elif split == "test2":
            self.data_X = x       
            self.data_y = y_
        self.T = args.T
        self.data_y = torch.from_numpy(self.data_y)

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index+self.T-1].float(), index, mask

    def __len__(self):    
        return len(self.data_X)-self.T+1


class StockAggregate28(data.Dataset):
    def __init__(self, split, type):
        
        if split == "train":
            self.data_X = x[arr[0:11000000]]     
            self.data_y = y[arr[0:11000000]]
        elif split == "test":
            self.data_X = x[arr[11000000:]]          
            self.data_y = y[arr[11000000:]]
        elif split == "test2":
            if type == "buy":
                self.data_X = x       
            else:
                self.data_X = x       
        self.T = args.T

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), 0, index, mask

    def __len__(self):    
        return len(self.data_X)-self.T+1

class StockAggregate24(data.Dataset):
    def __init__(self, split, type):
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        
        if split == "train":
            self.data_X = x[arr[0:11000000]]     
            self.data_y = y[arr[0:11000000]]
        elif split == "test":
            self.data_X = x[arr[11000000:]]          
            self.data_y = y[arr[11000000:]]
        elif split == "test2":
            if type == "buy":
                self.data_X = x       
                self.data_y = y
            else:
                self.data_X = x       
                self.data_y = y_
        self.T = args.T
        self.data_y = torch.from_numpy(self.data_y)

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index+self.T-1].float(), index, mask

    def __len__(self):    
        return len(self.data_X)-self.T+1
class StockAggregate21(data.Dataset):
    def __init__(self, split):
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        
        if split == "train":
            self.data_X = x[arr[0:11000000]]     
            self.data_y = y[arr[0:11000000]]
        elif split == "test":
            self.data_X = x[arr[11000000:]]          
            self.data_y = y[arr[11000000:]]
        elif split == "test2":
            self.data_X = x       
            self.data_y = y
        self.T = args.T
        self.data_y = torch.from_numpy(self.data_y)

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index+self.T-1].float(), index, mask

    def __len__(self):    
        return len(self.data_X)-self.T+1

class StockAggregate20(data.Dataset):
    def __init__(self, split):
        index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]
        if split == "train":
            self.data_X = np.load("shrink_xnn_08_14-08_22_57.npy")[:45000, index_all]        
            self.data_y = np.load("shrink_profit_l_08_14-08_22_57.npy")
        elif split == "test":
            self.data_X = np.load("shrink_xnn_08_14-08_22_57.npy")[45000:, index_all]        
            self.data_y = np.load("shrink_profit_l_08_14-08_22_57.npy")
        elif split == "test2":
            self.data_X = np.load("shrink_xnn_08_14-08_22_57.npy")[:, index_all]        
            self.data_y = np.load("shrink_profit_l_08_14-08_22_57.npy")
        self.T = args.T
        profit_l = self.data_y
        profit_l = (profit_l/np.max(np.abs(profit_l)))
        profit_l = (profit_l - profit_l.mean())/profit_l.std()
        self.data_y = torch.from_numpy(profit_l)
        self.data_X = torch.from_numpy(self.data_X)

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0).float(), self.data_y[index+self.T-1].float(), index, mask

    def __len__(self):    
        return len(self.data_X)-self.T+1

class StockAggregate19(data.Dataset):
    def __init__(self, split):
        self.split = split
        if split == "train":
            self.data_y = y
            self.data_X = x
        elif split == "test":
            self.data_y = y2
            self.data_X = x2
        # elif split == "test2":
            # self.data_y = y3
            # self.data_X = x3
        self.T = args.T
        
    def __getitem__(self, index):
        x_all_i = self.data_X[index:index+self.T]
        if args.div_std:
            X = (((x_all_i/abs_v)-mean)/std).float()
        else:
            X = x_all_i.float()
        y = self.data_y[index+self.T-1].float()
        mask = torch.ones(1,1)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        return self.data_y.shape[0]-self.T+1

class StockAggregate18(data.Dataset):
    def __init__(self, split, xnn=None, x=None, y=None):
        self.split = split
        if split == "train":
            if args.train[0] == "05_24-07_18":
                data_y1 = np.load('data_6/y_all_05_24-06_17.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_05_24-06_17.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_06_18-07_18.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_06_18-07_18.npy', dtype='float32', mode='r', shape=(total_length2,645))
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "05_24-08_13":
                data_y1 = np.load('data_6/y_all_05_24-06_17.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_05_24-06_17.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_06_18-07_18.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_06_18-07_18.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_07_19-08_13.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_07_19-08_13.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "07_04-08_13":
                data_y2 = np.load('data_6/y_all_07_04-07_18.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_07_04-07_18.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_07_19-08_13.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_07_19-08_13.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "07_04-08_20":
                data_y1 = np.load('data_6/y_all_07_04-07_18.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_07_04-07_18.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_07_19-08_13.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_07_19-08_13.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_08_14-08_20.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_08_14-08_20.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "07_04-08_21":
                data_y1 = np.load('data_6/y_all_07_04-07_18.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_07_04-07_18.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_07_19-08_13.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_07_19-08_13.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_08_14-08_20.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_08_14-08_20.npy', dtype='float32', mode='r', shape=(total_length3,645))
                data_y4 = np.load('data_6/y_all_08_21-08_21.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x_all_08_21-08_21.npy', dtype='float32', mode='r', shape=(total_length4,645))
                self.data_y = [data_y1, data_y2, data_y3, data_y4]
                self.data_X = [data_X1, data_X2, data_X3, data_X4]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1]
            elif args.train[0] == "07_04-08_25":
                data_y1 = np.load('data_6/y_all_07_04-07_18.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_07_04-07_18.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_07_19-08_13.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_07_19-08_13.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_08_14-08_25.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_08_14-08_25.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "07_04-09_03":
                data_y1 = np.load('data_6/y_all_07_04-07_18.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_07_04-07_18.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_07_19-08_13.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_07_19-08_13.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_08_14-08_25.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_08_14-08_25.npy', dtype='float32', mode='r', shape=(total_length3,645))
                data_y4 = np.load('data_6/y_all_08_26-09_03.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x_all_08_26-09_03.npy', dtype='float32', mode='r', shape=(total_length4,645))
                self.data_y = [data_y1, data_y2, data_y3, data_y4]
                self.data_X = [data_X1, data_X2, data_X3, data_X4]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1]
            elif args.train[0] == "07_04-08_08":
                data_y1 = np.load('data_6/y_all_07_04-07_18.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_07_04-07_18.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_07_19-08_08.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_07_19-08_08.npy', dtype='float32', mode='r', shape=(total_length2,645))
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "07_19-09_07":
                data_y1 = np.load('data_6/y_all_07_19-08_13.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                data_X1 = np.memmap('data_6/x_all_07_19-08_13.npy', dtype='float32', mode='r', shape=(total_length1,645))
                data_y2 = np.load('data_6/y_all_08_14-08_25.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_08_14-08_25.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_08_26-09_03.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_08_26-09_03.npy', dtype='float32', mode='r', shape=(total_length3,645))
                data_y4 = np.load('data_6/y_all_09_04-09_07.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x_all_09_04-09_07.npy', dtype='float32', mode='r', shape=(total_length4,645))
                self.data_y = [data_y1, data_y2, data_y3, data_y4]
                self.data_X = [data_X1, data_X2, data_X3, data_X4]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1]
            elif args.train[0] == "08_14-09_20":
                data_y2 = np.load('data_6/y_all_08_14-08_25.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_08_14-08_25.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_08_26-09_03.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_08_26-09_03.npy', dtype='float32', mode='r', shape=(total_length3,645))
                data_y4 = np.load('data_6/y_all_09_04-09_07.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x_all_09_07-09_07.npy', dtype='float32', mode='r', shape=(total_length4,645))
                data_y5 = np.load('data_6/y_all_09_08-09_20.npy', mmap_mode="r")
                total_length5 = data_y4.shape[0]
                data_X5 = np.memmap('data_6/x_all_09_08-09_20.npy', dtype='float32', mode='r', shape=(total_length5,645))
                self.data_y = [data_y2, data_y3, data_y4, data_y5]
                self.data_X = [data_X2, data_X3, data_X4, data_X5]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1, total_length5-args.T+1]

            elif args.train[0] == "08_08-09_07":
                data_y2 = np.load('data_6/y_all_08_08-09_07.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_08_08-09_07.npy', dtype='float32', mode='r', shape=(total_length2,645))
                self.data_y = [data_y2]
                self.data_X = [data_X2]
                self.length_list = [total_length2-args.T+1]
            # elif args.train[0] == "07_01-08_10":
            #     l1 = load_data_length("08_11-08_11", "y")
            #     data_y2 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[:-l1]
            #     print(np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r").shape[0], data_y2.shape[0], -l1)
            #     total_length2 = data_y2.shape[0]
            #     data_X2 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length2,645))
            #     self.data_y = [data_y2]
            #     self.data_X = [data_X2]
            #     self.length_list = [total_length2-args.T+1]
            elif args.train[0] == "07_04-08_14":
                l1 = load_data_length("07_01-07_03", "y")
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y")
                l3 = load_data_length("08_12-08_14", "y")
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:l3+l2]
                print(l2, l3, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "07_08-08_18":
                l1 = load_data_length("07_01-07_07", "y")
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y")
                l3 = load_data_length("08_12-08_18", "y")
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:l3+l2]
                print(l2, l3, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]

            elif args.train[0] == "07_11-08_21":
                l1 = load_data_length("07_01-07_10", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                l3 = load_data_length("08_12-08_21", "y") ###
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:l3+l2]
                print(l2, l3, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "07_15-08_25":
                l1 = load_data_length("07_01-07_14", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                l3 = load_data_length("08_12-08_25", "y") ###
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:l3+l2]
                print(l2, l3, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "07_18-08_28":
                l1 = load_data_length("07_01-07_17", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                l3 = load_data_length("08_12-08_28", "y") ###
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:l3+l2]
                print(l2, l3, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "07_22-09_02":
                l1 = load_data_length("07_01-07_21", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                l3 = load_data_length("08_12-09_02", "y") ###
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:l3+l2]
                print(l2, l3, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "07_25-09_05":
                l1 = load_data_length("07_01-07_24", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                l3 = load_data_length("08_12-09_05", "y") ###
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:l3+l2]
                print(l2, l3, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                self.data_y = [data_y1, data_y2]
                self.data_X = [data_X1, data_X2]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
            elif args.train[0] == "07_29-09_09":
                l1 = load_data_length("07_01-07_28", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                l3 = load_data_length("09_06-09_09", "y") ###
                data_y3 = np.load('data_6/y_all_09_06-09_22.npy', mmap_mode="r")[:l3]
                print(l3, data_y3.shape)
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x_all_09_06-09_22.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "08_01-09_11":
                l1 = load_data_length("07_01-07_31", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                l3 = load_data_length("09_06-09_11", "y") ###
                data_y3 = np.load('data_6/y_all_09_06-09_22.npy', mmap_mode="r")[:l3]
                print(l3, data_y3.shape)
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x_all_09_06-09_22.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "08_05-09_15":
                l1 = load_data_length("07_01-08_04", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                l3 = load_data_length("09_06-09_15", "y") ###
                data_y3 = np.load('data_6/y_all_09_06-09_22.npy', mmap_mode="r")[:l3]
                print(l3, data_y3.shape)
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x_all_09_06-09_22.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "08_08-09_18":
                l1 = load_data_length("07_01-08_07", "y") ###
                data_y1 = np.load('data_6/y_all_07_01-08_11.npy', mmap_mode="r")[l1:]
                print(l1, data_y1.shape)
                total_length1 = data_y1.shape[0]
                print(total_length1)
                data_X1 = np.memmap('data_6/x_all_07_01-08_11.npy', dtype='float32', mode='r', shape=(total_length1,645), offset=l1*645*4)
                print(data_X1.shape)
                l2 = load_data_length("08_11-08_11", "y") 
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                l3 = load_data_length("09_06-09_18", "y") ###
                data_y3 = np.load('data_6/y_all_09_06-09_22.npy', mmap_mode="r")[:l3]
                print(l3, data_y3.shape)
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x_all_09_06-09_22.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y1, data_y2, data_y3]
                self.data_X = [data_X1, data_X2, data_X3]
                self.length_list = [total_length1-args.T+1, total_length2-args.T+1, total_length3-args.T+1]
            elif args.train[0] == "08_12-09_22":
                l2 = load_data_length("08_11-08_11", "y") 
                data_y2 = np.load('data_6/y_all_08_11-09_05.npy', mmap_mode="r")[l2:]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_08_11-09_05.npy', dtype='float32', mode='r', shape=(total_length2,645), offset=l2*645*4)
                print(data_X2.shape)
                l3 = load_data_length("09_06-09_22", "y") ###
                data_y3 = np.load('data_6/y_all_09_06-09_22.npy', mmap_mode="r")[:l3]
                print(l3, data_y3.shape)
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x_all_09_06-09_22.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "09_21-10_25;12_02-12_03":
                l2 = load_data_length("09_21-10_25", "y") 
                data_y2 = np.load('data_6/y_all_09_21-10_30.npy', mmap_mode="r")[:l2]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_09_21-10_30.npy', dtype='float32', mode='r', shape=(l2,645))
                data_y3 = np.load('data_6/y_all_12_02-12_03.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_12_02-12_03.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "09_21-10_25;12_02-12_03":
                l2 = load_data_length("09_21-10_25", "y") 
                data_y2 = np.load('data_6/y_all_09_21-10_30.npy', mmap_mode="r")[:l2]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x_all_09_21-10_30.npy', dtype='float32', mode='r', shape=(l2,645))
                data_y3 = np.load('data_6/y_all_12_02-12_03.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_12_02-12_03.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "11_19-12_02;10_10-11_08":
                data_y2 = np.load('data_6/y_all_10_10-11_08.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                data_X2 = np.memmap('data_6/x_all_10_10-11_08.npy', dtype='float32', mode='r', shape=(total_length2,645))
                data_y3 = np.load('data_6/y_all_11_19-12_02.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x_all_11_19-12_02.npy', dtype='float32', mode='r', shape=(total_length3,645))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "12_06-01_09;01_11-01_15" and args.use_p23 == 13:
                data_y2 = np.load('data_6/y_all_12_06-01_09.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x3_all_12_06-01_09.npy', dtype='float32', mode='r', shape=(total_length2,601))
                data_y3 = np.load('data_6/y_all_01_11-01_15.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x3_all_01_11-01_15.npy', dtype='float32', mode='r', shape=(total_length3,601))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "11_19-11_30;12_03-12_10" and args.use_p23 == 13:
                if args.y == "50":
                    data_y2 = np.load('data_6/y50_all_11_19-11_30.npy', mmap_mode="r")
                else:
                    data_y2 = np.load('data_6/y_all_11_19-11_30.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x3_all_11_19-11_30.npy', dtype='float32', mode='r', shape=(total_length2,601))
                print(np.isnan(data_X2[0]).sum(), "how many nonzeros")
                if args.y == "50":
                    data_y3 = np.load('data_6/y50_all_12_03-12_10.npy', mmap_mode="r")
                else:
                    data_y3 = np.load('data_6/y_all_12_03-12_10.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x3_all_12_03-12_10.npy', dtype='float32', mode='r', shape=(total_length3,601))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "11_19-11_30;12_03-12_20" and args.use_p23 == 13:
                data_y2 = np.load('data_6/y_all_11_19-11_30.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x3_all_11_19-11_30.npy', dtype='float32', mode='r', shape=(total_length2,601))
                print(np.isnan(data_X2[0]).sum(), "how many nonzeros")
                data_y3 = np.load('data_6/y_all_12_03-12_10.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x3_all_12_03-12_10.npy', dtype='float32', mode='r', shape=(total_length3,601))
                data_y4 = np.load('data_6/y_all_12_11-12_20.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x3_all_12_11-12_20.npy', dtype='float32', mode='r', shape=(total_length4,601))
                self.data_y = [data_y2, data_y3, data_y4]
                self.data_X = [data_X2, data_X3, data_X4]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1]

            elif ";".join(args.train) == "11_19-11_30;12_03-12_31" and args.use_p23 == 13:
                data_y2 = np.load('data_6/y_all_11_19-11_30.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x3_all_11_19-11_30.npy', dtype='float32', mode='r', shape=(total_length2,601))
                print(np.isnan(data_X2[0]).sum(), "how many nonzeros")
                data_y3 = np.load('data_6/y_all_12_03-12_10.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x3_all_12_03-12_10.npy', dtype='float32', mode='r', shape=(total_length3,601))
                data_y4 = np.load('data_6/y_all_12_11-12_20.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x3_all_12_11-12_20.npy', dtype='float32', mode='r', shape=(total_length4,601))
                data_y5 = np.load('data_6/y_all_12_21-12_31.npy', mmap_mode="r")
                total_length5 = data_y5.shape[0]
                data_X5 = np.memmap('data_6/x3_all_12_21-12_31.npy', dtype='float32', mode='r', shape=(total_length5,601))
                self.data_y = [data_y2, data_y3, data_y4, data_y5]
                self.data_X = [data_X2, data_X3, data_X4, data_X5]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1, total_length5-args.T+1]
            elif ";".join(args.train) == "12_03-01_10" and args.use_p23 == 13:
                data_y3 = np.load('data_6/y_all_12_03-12_10.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x3_all_12_03-12_10.npy', dtype='float32', mode='r', shape=(total_length3,601))
                data_y4 = np.load('data_6/y_all_12_11-12_20.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x3_all_12_11-12_20.npy', dtype='float32', mode='r', shape=(total_length4,601))
                data_y5 = np.load('data_6/y_all_12_21-12_31.npy', mmap_mode="r")
                total_length5 = data_y5.shape[0]
                data_X5 = np.memmap('data_6/x3_all_12_21-12_31.npy', dtype='float32', mode='r', shape=(total_length5,601))
                data_y6 = np.load('data_6/y_all_01_01-01_10.npy', mmap_mode="r")
                total_length6 = data_y6.shape[0]
                data_X6 = np.memmap('data_6/x3_all_01_01-01_10.npy', dtype='float32', mode='r', shape=(total_length6,601))
                self.data_y = [data_y3, data_y4, data_y5, data_y6]
                self.data_X = [data_X3, data_X4, data_X5, data_X6]
                self.length_list = [total_length3-args.T+1, total_length4-args.T+1, total_length5-args.T+1, total_length6-args.T+1]
            elif ";".join(args.train) == "12_11-01_20" and args.use_p23 == 13:
                
                data_y4 = np.load('data_6/y_all_12_11-12_20.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                data_X4 = np.memmap('data_6/x3_all_12_11-12_20.npy', dtype='float32', mode='r', shape=(total_length4,601))
                data_y5 = np.load('data_6/y_all_12_21-12_31.npy', mmap_mode="r")
                total_length5 = data_y5.shape[0]
                data_X5 = np.memmap('data_6/x3_all_12_21-12_31.npy', dtype='float32', mode='r', shape=(total_length5,601))
                data_y6 = np.load('data_6/y_all_01_01-01_10.npy', mmap_mode="r")
                total_length6 = data_y6.shape[0]
                data_X6 = np.memmap('data_6/x3_all_01_01-01_10.npy', dtype='float32', mode='r', shape=(total_length6,601))
                data_y7 = np.load('data_6/y_all_01_11-01_20.npy', mmap_mode="r")
                total_length7 = data_y7.shape[0]
                data_X7 = np.memmap('data_6/x3_all_01_11-01_20.npy', dtype='float32', mode='r', shape=(total_length7,601))
                self.data_y = [data_y4, data_y5, data_y6, data_y7]
                self.data_X = [data_X4, data_X5, data_X6, data_X7]
                self.length_list = [total_length4-args.T+1, total_length5-args.T+1, total_length6-args.T+1, total_length7-args.T+1]
            elif ";".join(args.train) == "12_21-01_31" and args.use_p23 == 13:
                data_y2 = np.load('data_6/y_all_12_21-12_31.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x3_all_12_21-12_31.npy', dtype='float32', mode='r', shape=(total_length2,601))
                data_y3 = np.load('data_6/y_all_01_01-01_10.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x3_all_01_01-01_10.npy', dtype='float32', mode='r', shape=(total_length3,601))
                data_y4 = np.load('data_6/y_all_01_11-01_20.npy', mmap_mode="r")
                total_length4 = data_y4.shape[0]
                print(total_length4)
                print(data_X2.shape, data_X3.shape)
                data_X4 = np.memmap('data_6/x3_all_01_11-01_20.npy', dtype='float32', mode='r', shape=(total_length4,601))
                print(np.isnan(data_X2[0]).sum(), "how many nonzeros")
                data_y5 = np.load('data_6/y_all_01_21-01_31.npy', mmap_mode="r")
                total_length5 = data_y5.shape[0]
                data_X5 = np.memmap('data_6/x3_all_01_21-01_31.npy', dtype='float32', mode='r', shape=(total_length5,601))
                self.data_y = [data_y2, data_y3, data_y4, data_y5]
                self.data_X = [data_X2, data_X3, data_X4, data_X5]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1, total_length5-args.T+1]
            elif ";".join(args.train) == "12_06-01_09;01_11-01_15" and args.use_p23 == 12:
                data_y2 = np.load('data_6/y_all_12_06-01_09.npy', mmap_mode="r")
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x2_all_12_06-01_09.npy', dtype='float32', mode='r', shape=(total_length2,601))
                data_y3 = np.load('data_6/y_all_01_11-01_15.npy', mmap_mode="r")
                total_length3 = data_y3.shape[0]
                data_X3 = np.memmap('data_6/x2_all_01_11-01_15.npy', dtype='float32', mode='r', shape=(total_length3,601))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "11_19-12_10" and args.use_p23 == 12:
                l2 = load_data_length("11_19-12_10", "y") 
                data_y2 = np.load('data_6/y_all_11_19-12_31.npy', mmap_mode="r")[:l2]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x2_all_11_19-12_31.npy', dtype='float32', mode='r', shape=(l2, 601))
                self.data_y = [data_y2]
                self.data_X = [data_X2]
                self.length_list = [total_length2-args.T+1]

            elif ";".join(args.train) == "11_19-12_20" and args.use_p23 == 12:
                l2 = load_data_length("11_19-12_20", "y") 
                data_y2 = np.load('data_6/y_all_11_19-12_31.npy', mmap_mode="r")[:l2]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x2_all_11_19-12_31.npy', dtype='float32', mode='r', shape=(l2, 601))
                self.data_y = [data_y2]
                self.data_X = [data_X2]
                self.length_list = [total_length2-args.T+1]
            elif ";".join(args.train) == "11_19-12_31" and args.use_p23 == 12:
                l2 = load_data_length("11_19-12_31", "y") 
                data_y2 = np.load('data_6/y_all_11_19-12_31.npy', mmap_mode="r")[:l2]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x2_all_11_19-12_31.npy', dtype='float32', mode='r', shape=(l2, 601))
                self.data_y = [data_y2]
                self.data_X = [data_X2]
                self.length_list = [total_length2-args.T+1]
            elif ";".join(args.train) == "12_01-01_10" and args.use_p23 == 12:
                l2 = load_data_length("11_19-11_30", "y") 
                data_y2 = np.load('data_6/y_all_11_19-12_31.npy', mmap_mode="r")[l2:]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x2_all_11_19-12_31.npy', dtype='float32', mode='r', shape=(total_length2, 601), offset=l2*601*4)
                data_y3 = np.load('data_6/y_all_01_01-01_10.npy', mmap_mode="r")
                print(data_y3.shape)
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x2_all_01_01-01_10.npy', dtype='float32', mode='r', shape=(total_length3, 601))
                self.data_y = [data_y2, data_y3]
                self.data_X = [data_X2, data_X3]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1]
            elif ";".join(args.train) == "12_11-01_20" and args.use_p23 == 12:
                l2 = load_data_length("11_19-12_10", "y") 
                data_y2 = np.load('data_6/y_all_11_19-12_31.npy', mmap_mode="r")[l2:]
                print(l2, data_y2.shape)
                total_length2 = data_y2.shape[0]
                print(total_length2)
                data_X2 = np.memmap('data_6/x2_all_11_19-12_31.npy', dtype='float32', mode='r', shape=(total_length2, 601), offset=l2*601*4)
                data_y3 = np.load('data_6/y_all_01_01-01_10.npy', mmap_mode="r")
                print(data_y3.shape)
                total_length3 = data_y3.shape[0]
                print(total_length3)
                data_X3 = np.memmap('data_6/x2_all_01_01-01_10.npy', dtype='float32', mode='r', shape=(total_length3, 601))
                data_y4 = np.load('data_6/y_all_01_11-01_20.npy', mmap_mode="r")
                print(data_y4.shape)
                total_length4 = data_y4.shape[0]
                print(total_length4)
                data_X4 = np.memmap('data_6/x2_all_01_11-01_20.npy', dtype='float32', mode='r', shape=(total_length4, 601))
                self.data_y = [data_y2, data_y3, data_y4]
                self.data_X = [data_X2, data_X3, data_X4]
                self.length_list = [total_length2-args.T+1, total_length3-args.T+1, total_length4-args.T+1]
            else:
                
                data_y1 = np.load('data_6/y_all_'+args.train[0]+'.npy', mmap_mode="r")
                total_length1 = data_y1.shape[0]
                if args.use_p23 == 13:
                    data_X1 = np.memmap('data_6/x3_all_'+args.train[0]+'.npy', dtype='float32', mode='r', shape=(total_length1,601))
                elif args.use_p23 == 12:
                    data_X1 = np.memmap('data_6/x2_all_'+args.train[0]+'.npy', dtype='float32', mode='r', shape=(total_length1,601))
                else:
                    data_X1 = np.memmap('data_6/x_all_'+args.train[0]+'.npy', dtype='float32', mode='r', shape=(total_length1,645))
                self.data_y = [data_y1]
                self.data_X = [data_X1]
                self.length_list = [total_length1-args.T+1]

        else:
            from numpy import genfromtxt
            if args.use_p23 == 100:
                if args.test[0] == "11_20-11_20":
                    # self.data_X = torch.from_numpy(np.load("data_6/621_1.npy"))
                    from influxdb import DataFrameClient
                    import pandas as pd

                    client = DataFrameClient('***.***.***.***', ******) #1668910000000ms
                    result = client.query("SELECT * FROM \"input\" WHERE type='rl_seq_621' AND time >= 1668897723099ms and time <= 1668900723099ms;")
                    result['input'].index.name='time'
                    raw2 = result['input'].reset_index(level=0)#.astype('float32')
                    raw2['time'] = pd.to_datetime(raw2['time']).dt.tz_localize(None)
                    raw2 = raw2.set_index('time')
                    del result['input']
                    print(raw2)
                    cols = []
                    for i in range (0, 621):
                        cols.append('x'+str(i))
                    raw2 = raw2[cols]
                    print(raw2, raw2.shape)
                    self.raw2 = raw2
                    self.data_X = torch.from_numpy(raw2.to_numpy())
                elif args.test[0] == "11_10-11_10":
                    torch.set_printoptions(threshold=10000)
                    self.data_X = torch.from_numpy(genfromtxt('feat4.csv', delimiter=','))
                    X_ori = torch.cat([torch.from_numpy(xnn[101775:101775+101])[:, index_all], torch.from_numpy(x[101775:101775+101])], dim=1)
                    print(X_ori[:, 34])
                    # self.data_X = (((self.data_X/abs_v)-mean)/std).float()
                    # X_ori =  (((X_ori/abs_v)-mean)/std).float()
                    print(abs_v[0, 59], mean[0, 59], std[0, 59])
                    loc = 21794
                    X_diff = torch.sum((X_ori - self.data_X)**2)
                    temp = ((X_ori - self.data_X)**2)[loc//621, loc%621]
                    print(temp, X_ori[loc//621, loc%621], self.data_X[loc//621, loc%621], loc//621, loc%621, X_ori[:, 63], X_ori[:, loc%621], self.data_X[:, loc%621])
                    print(X_diff, (X_ori - self.data_X), torch.argmax((X_ori - self.data_X)**2))
                    print(self.data_X.size())
                    print((((self.data_X[0:5]/abs_v)-mean)/std).float())
                    print((((self.data_X[0:5]/abs_v)-mean)/std).float().permute(1,0).unsqueeze(0))
                    np.save("a.npy", (((self.data_X[0:5]/abs_v)-mean)/std).float().permute(1,0).unsqueeze(0))
                else:
                    from influxdb import DataFrameClient
                    import pandas as pd

                    client = DataFrameClient('***.***.***.***', ******)
                    result = client.query("SELECT * FROM \"input\" WHERE type='rl_seq_621' AND time >= 1668149122896ms and time <= 1668149139780ms;")
                    result['input'].index.name='time'
                    raw2 = result['input'].reset_index(level=0)#.astype('float32')
                    raw2['time'] = pd.to_datetime(raw2['time']).dt.tz_localize(None)
                    raw2 = raw2.set_index('time')
                    del result['input']
                    print(raw2)
                    cols = []
                    for i in range (0, 621):
                        cols.append('x'+str(i))
                    raw2 = raw2[cols]
                    print(raw2, raw2.shape)
                    self.data_X0 = torch.from_numpy(raw2.to_numpy())
                    self.data_X = [xnn, x]
                    xnn = torch.from_numpy(self.data_X[0][:, index_all])
                    x = torch.from_numpy(self.data_X[1])
                    self.data_X = torch.cat([xnn, x], dim=1)[813610:813610+len(raw2)]
                    print(self.data_X.size(), self.data_X0.size())
                    # for i in [31, 33, 34, 35, 36, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188]:
                        # self.data_X[:, i] = self.data_X0[:, i]


            else:
                
                self.data_X = [xnn, x]
                print(xnn.shape, x.shape)
            self.data_y = y
        self.T = args.T
        
            
    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i] 

    def __getitem__(self, index):
        if args.use_p23 == 100:
            x_all_i = self.data_X[index:index+self.T]
            x_all_i = x_all_i[:, index_x]
            X = (((x_all_i/abs_v)-mean)/std).float()
            y = torch.tensor(self.data_y[index+self.T-1]).float()
        else:
            if self.split == "train":
                if args.use_p23 == 3:
                    index_here = [i for i in range(645)]
                if args.use_p23 == 4:
                    index_here = [i for i in range(34)] + [i for i in range(57, 645)]
                if args.use_p23 == 5:
                    index_here = [i for i in range(32)] + [i for i in range(57, 645)]
                if args.use_p23 == 6:
                    index_here = [i for i in range(57, 645)]
                if args.use_p23 == 7:
                    index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]
                if args.use_p23 == 11:
                    index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]
                if args.use_p23 == 12 or args.use_p23 == 13:
                    index_here = [i for i in range(601)]
                index_0, index_1 = self.get_index(self.length_list, index)
                x_all_i = torch.from_numpy(self.data_X[index_0][index_1:index_1+self.T, index_here])
                if args.use_p23 == 11:
                    x_all_i = x_all_i[:, index_x]
                X = (((x_all_i/(abs_v+1e-20))-mean)/(std+1e-20)).float()
                
                y = torch.tensor(self.data_y[index_0][index_1+self.T-1]).float()
            else:
                if args.use_p23 == 12 or args.use_p23 == 13:
                    xnn_i = torch.from_numpy(self.data_X[0][index:index+self.T, :33])
                    x_i = torch.from_numpy(self.data_X[1][index:index+self.T])
                    x_all_i = torch.cat([xnn_i, x_i], dim=1)
                    X = (((x_all_i/(abs_v+1e-20))-mean)/(std+1e-20)).float()
                    y = torch.tensor(self.data_y[index+self.T-1]).float()
                elif args.use_p23 == 11:
                    xnn_i = torch.from_numpy(self.data_X[0][index:index+self.T, index_all])
                    x_i = torch.from_numpy(self.data_X[1][index:index+self.T])
                    x_all_i = torch.cat([xnn_i, x_i], dim=1)
                    x_all_i = x_all_i[:, index_x]
                    X = (((x_all_i/abs_v)-mean)/std).float()
                    y = torch.tensor(self.data_y[index+self.T-1]).float()
                elif args.use_p23 != 6:
                    xnn_i = torch.from_numpy(self.data_X[0][index:index+self.T, index_all])
                    x_i = torch.from_numpy(self.data_X[1][index:index+self.T])
                    x_all_i = torch.cat([xnn_i, x_i], dim=1)
                    X = (((x_all_i/abs_v)-mean)/std).float()
                    y = torch.tensor(self.data_y[index+self.T-1]).float()
                else:
                    x_all_i = torch.from_numpy(self.data_X[1][index:index+self.T])
                    if args.div_std:
                        X = (((x_all_i/abs_v)-mean)/std).float()
                    else:
                        X = x_all_i.float()
                    y = torch.tensor(self.data_y[index+self.T-1]).float()
        mask = torch.ones(1,1)
        if args.arch == "TSTransformerEncoderPretrained":
            indice = random.randint(0, int(noise_mask.size(1)-args.input_size))
            mask = noise_mask[:, indice:indice+args.input_size].permute(1, 0)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        if self.split == "train":
            return sum(self.length_list)
        else:
            if args.use_p23 == 100:
                return self.data_X.size(0)-self.T+1
            else:
                return self.data_y.shape[0]-self.T+1

class StockAggregate17(data.Dataset):
    def __init__(self, split):
        self.split = split
        if split == "train":
            data_y1 = np.load('data_6/y_all_05_24-06_17.npy', mmap_mode="r")
            total_length1 = data_y1.shape[0]
            data_X1 = np.memmap('data_6/x_all_05_24-06_17.npy', dtype='float32', mode='r', shape=(total_length1,645))
            data_y2 = np.load('data_6/y_all_06_18-07_18.npy', mmap_mode="r")
            total_length2 = data_y1.shape[0]
            data_X2 = np.memmap('data_6/x_all_06_18-07_18.npy', dtype='float32', mode='r', shape=(total_length2,645))
            self.data_y = [data_y1, data_y2]
            self.data_X = [data_X1, data_X2]
            self.length_list = [total_length1-args.T+1, total_length2-args.T+1]
        elif split == "test":
            self.data_y = y2
            self.data_X = x2
        elif split == "test2":
            self.data_y = y3
            self.data_X = x3
        self.T = args.T
        
            
    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i]

    # def __getitem__(self, index):
    #     index_0, index_1 = self.get_index(self.length_list, index)
    #     # print(self.data_X[0][index_0].shape, self.data_X[0][index_0][index_1:index_1+self.T].shape)
    #     xnn_i = torch.from_numpy(self.data_X[0][index_0][index_1:index_1+self.T])
    #     x_i = torch.from_numpy(self.data_X[1][index_0][index_1:index_1+self.T])
    #     # print(xnn_i.size(), x_i.size())
    #     X = ((((torch.cat([xnn_i, x_i], 1))/abs_v)-mean)/std)[:, index_all].float()
    #     # print(X.size())
    #     y = torch.tensor(self.data_y[index_0][index_1+self.T-1]).float()
    #     # print("---------", y)
    #     mask = torch.ones(1,1)
    #     return X.permute(1, 0), y, index, mask

    def __getitem__(self, index):

        if self.split == "train":
            if args.use_p23 == 3:
                index_here = [i for i in range(645)]
            if args.use_p23 == 4:
                index_here = [i for i in range(34)] + [i for i in range(57, 645)]
            if args.use_p23 == 5:
                index_here = [i for i in range(32)] + [i for i in range(57, 645)]
            if args.use_p23 == 6:
                index_here = [i for i in range(57, 645)]
            if args.use_p23 == 7:
                index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]

            index_0, index_1 = self.get_index(self.length_list, index)
            x_all_i = torch.from_numpy(self.data_X[index_0][index_1:index_1+self.T, index_here])
            # if args.only_xnn:
                # X = (((x_all_i/abs_v)-mean)/std).float()[:, :57]
            # else:
                # X = (((x_all_i/abs_v)-mean)/std).float()
                # print(index_here)
            X = (((x_all_i/abs_v)-mean)/std).float()
                # print(X.size())
                # print(index_here)
                # print(X.size())

            y = torch.tensor(self.data_y[index_0][index_1+self.T-1]).float()
            mask = torch.ones(1,1)
        else:
            x_all_i = self.data_X[index:index+self.T].float()
            # if args.only_xnn:
            #     X = (((x_all_i/abs_v)-mean)/std).float()[:, :57]
            # else:
            X = (((x_all_i/abs_v)-mean)/std).float()
            y = self.data_y[index+self.T-1].float()
            mask = torch.ones(1,1)
        if args.arch == "TSTransformerEncoderPretrained":
            indice = random.randint(0, int(noise_mask.size(1)-args.input_size))
            mask = noise_mask[:, indice:indice+args.input_size].permute(1, 0)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        if self.split == "train":
            return sum(self.length_list)
        else:
            return self.data_y.shape[0]-self.T+1

    
class StockAggregate15(data.Dataset):
    def __init__(self, split):

        #  abs_v_x = np.load('data_6/abs_v_x'+args.train[0]+'.npy').reshape(1, 588)
        # mean_x = np.load('data_6/mean_x'+args.train[0]+'.npy').reshape(1, 588)
        # std_x = np.load('data_6/std_x'+args.train[0]+'.npy').reshape(1, 588)
        self.split = split
        if split == "train":
            self.data_y = np.load('data_6/y_all_'+args.train[0]+'.npy', mmap_mode="r")
            total_length = self.data_y.shape[0]
            self.data_X = np.memmap('data_6/x_all_'+args.train[0]+'.npy', dtype='float32', mode='r', shape=(total_length,645))
        else:
            self.data_y = y2
            self.data_X = x2
        self.T = args.T
        
    def __getitem__(self, index):
        if self.split == "train":
            if args.use_p23 == 3:
                index_here = [i for i in range(645)]
            if args.use_p23 == 4:
                index_here = [i for i in range(34)] + [i for i in range(57, 645)]
            if args.use_p23 == 5:
                index_here = [i for i in range(32)] + [i for i in range(57, 645)]
            if args.use_p23 == 6:
                index_here = [i for i in range(57, 645)]
            if args.use_p23 == 7:
                index_here = [i for i in range(32)] + [33] + [i for i in range(57, 645)]

            x_all_i = torch.from_numpy(self.data_X[index:index+self.T, index_here])
            # if args.only_xnn:
                # X = (((x_all_i/abs_v)-mean)/std).float()[:, :57]
            # else:
                # X = (((x_all_i/abs_v)-mean)/std).float()
                # print(index_here)
            X = (((x_all_i/abs_v)-mean)/std).float()
                # print(X.size())
                # print(index_here)
                # print(X.size())

            y = torch.tensor(self.data_y[index+self.T-1]).float()
            mask = torch.ones(1,1)
        else:
            x_all_i = self.data_X[index:index+self.T].float()
            if args.only_xnn:
                X = (((x_all_i/abs_v)-mean)/std).float()[:, :57]
            else:
                X = (((x_all_i/abs_v)-mean)/std).float()
            y = self.data_y[index+self.T-1].float()
            mask = torch.ones(1,1)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        return self.data_y.shape[0]-self.T+1



class StockAggregate14(data.Dataset):
    def __init__(self, split):
        self.T = args.T
        if split == "train":
            self.data_dates = args.train[0]
        elif split == "test":
            self.data_dates = args.test[0]
    def load_data_tp(self, date_list, tp):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                x_l.append(torch.from_numpy(np.load(f)).float())
            print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)
    
    def load_data_test(self):
        print("load test!!!")
        x2 = self.load_data_tp(self.data_dates, "xnn")[:, index_all]
        if args.only_xnn:
            self.data_X = x2
        else:
            x588_2 = self.load_data_tp(self.data_dates, "x")
            self.data_X = torch.cat([x2, x588_2], dim=1)

        if args.y == "0":
            self.data_y = self.load_data_tp(self.data_dates, "y")
        elif args.y == "3":
            self.data_y = self.load_data_tp(self.data_dates, "y3")
        elif args.y == "4":
            self.data_y = self.load_data_tp(self.data_dates, "y4")
        
    def clean(self):
        del self.data_X, self.data_y

    def load_data(self, date_list, tp, sampled_list):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        x_l = []
        print(start, end)
        for i in range((end-start).days+1):
            if i in sampled_list:
                print(i, sampled_list, [i for i in range((end-start).days+1)])
                day = start + datetime.timedelta(days=i)
                month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
                day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
                with open('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', 'rb') as f:
                    x_l.append(torch.from_numpy(np.load(f)).float())
                print(day, day.month, day.day, x_l[-1].size())
        return torch.cat(x_l, dim=0)

    def resample(self):
        start_month, start_day, end_month, end_day = int(self.data_dates.split("-")[0].split("_")[0]), int(self.data_dates.split("-")[0].split("_")[1]), int(self.data_dates.split("-")[1].split("_")[0]), int(self.data_dates.split("-")[1].split("_")[1])
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        sampled_list = random.sample([i for i in range((end-start).days+1)], args.sampled_days)
        print("sampled dates:", sampled_list)
        x = self.load_data(self.data_dates, "xnn", sampled_list)[:, index_all]
        if args.only_xnn:
            self.data_X = x
        else:
            x588 = self.load_data(self.data_dates, "x", sampled_list)
            self.data_X = torch.cat([x, x588], dim=1)
        if args.y == "0":
            self.data_y = self.load_data(self.data_dates, "y", sampled_list)
        elif args.y == "3":
            self.data_y = self.load_data(self.data_dates, "y3", sampled_list)
        elif args.y == "4":
            self.data_y = self.load_data(self.data_dates, "y4", sampled_list)

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        # if args.only_xnn:
        #     X = X[:, index_all]
        mask = torch.ones(1,1)
        return X.permute(1, 0), self.data_y[index+self.T-1], index, mask

    def __len__(self):
        return len(self.data_X)-self.T+1

class Stock(data.Dataset):
    def __init__(self, split):
        if split == "train":
            self.data_X = train_data_X
            self.data_y = train_data_y
        elif split == "val":
            self.data_X = val_data_X
            self.data_y = val_data_y
        elif split == "test":
            self.data_X = test_data_X
            self.data_y = test_data_y
        self.mean = mean
        self.std = std

    def __getitem__(self, index):
        return (self.data_X[index]-self.mean), self.data_y[index], index

    def __len__(self):
        return len(self.data_X)

import random
class StockAggregate(data.Dataset):
    def __init__(self, split):
        if split == "train":
            self.data_X = train_data_X
            self.data_y = train_data_y
        elif split == "test":
            self.data_X = x2
            self.data_y = y2
        elif split == "test2":
            self.data_X = x3
            self.data_y = y3
        self.T = args.T
    

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]-mean)/std
        mask = torch.ones(1,1)
        if args.arch == "TSTransformerEncoderPretrained":
            indice = random.randint(0, int(noise_mask.size(1)-args.input_size))
            mask = noise_mask[:, indice:indice+args.input_size].permute(1, 0)
        return X.permute(1, 0), self.data_y[index+self.T-1], index, mask

    def __len__(self):
        return len(self.data_X)-self.T+1

import random
class StockAggregate10(data.Dataset):
    def __init__(self, split):
        if split == "train":
            self.data_X = train_data_X
            self.data_y = train_data_y
        elif split == "val":
            self.data_X = val_data_X
            self.data_y = val_data_y
        elif split == "test":
            self.data_X = test_data_X
            self.data_y = test_data_y
        self.T = args.T
    

    def __getitem__(self, index):
        X = (self.data_X[index:index+self.T, :]/abs_v-mean)/std
        mask = torch.ones(1,1)
        return X.permute(1, 0), self.data_y[index+self.T-1], index, mask

    def __len__(self):
        return len(self.data_X)-self.T+1

class StockAggregate12(data.Dataset):
    def __init__(self, split):
        if split == "train":
            self.data_X = train_data_X
            self.data_y = train_data_y
            self.length_list = length_list

        elif split == "val":
            self.data_X = val_data_X
            self.data_y = val_data_y
            self.length_list = length_list
        elif split == "test":
            self.data_X = test_data_X
            self.data_y = test_data_y
            self.length_list = length_list2

        self.T = args.T
        print(split, length_list, length_list2)
        print(self.length_list)
        
    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i]

    def __getitem__(self, index):
        index_0, index_1 = self.get_index(self.length_list, index)
        # print(self.data_X[0][index_0].shape, self.data_X[0][index_0][index_1:index_1+self.T].shape)
        xnn_i = torch.from_numpy(self.data_X[0][index_0][index_1:index_1+self.T])
        x_i = torch.from_numpy(self.data_X[1][index_0][index_1:index_1+self.T])
        # print(xnn_i.size(), x_i.size())
        X = ((((torch.cat([xnn_i, x_i], 1))/abs_v)-mean)/std)[:, index_all].float()
        # print(X.size())
        y = torch.tensor(self.data_y[index_0][index_1+self.T-1]).float()
        # print("---------", y)
        mask = torch.ones(1,1)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        print(self.length_list)
        return sum(self.length_list)


class StockAggregate13(data.Dataset):
    def __init__(self, split):
        if split == "train":
            self.length_list = length_list
            self.data_dates = args.train[0]
        elif split == "test":
            self.length_list = length_list2
            self.data_dates = args.test[0]

        self.T = args.T
    def get_index(self, length_list, index):
        sum = 0
        for i in range(len(length_list)):
            sum += length_list[i]
            if sum > index:
                return i, index-sum+length_list[i]

    def load_data_day(self, date_list, tp, index_0, index_1):
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        # print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        end = datetime.date(2022,end_month,end_day)
        # print(start, end)
        day = start + datetime.timedelta(days=index_0)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        # with np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r") as x_day:
        x_day = np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
        if "y" in tp:
            x_i = x_day[index_1+self.T-1]
        else:
            x_i = x_day[index_1:index_1+self.T]
        del x_day
        return x_i

    def __getitem__(self, index):
        index_0, index_1 = self.get_index(self.length_list, index)
        xnn_day = self.load_data_day(self.data_dates, "xnn", index_0, index_1)
        x_day = self.load_data_day(self.data_dates, "x", index_0, index_1)
        if args.y == "0":
            y_day = self.load_data_day(self.data_dates, "y", index_0, index_1)
        elif args.y == "3":
            y_day = self.load_data_day(self.data_dates, "y3", index_0, index_1)
        elif args.y == "4":
            y_day = self.load_data_day(self.data_dates, "y4", index_0, index_1)
        xnn_i = torch.from_numpy(xnn_day)
        x_i = torch.from_numpy(x_day)
        # print(xnn_i.size(), x_i.size())
        X = ((((torch.cat([xnn_i, x_i], 1))/abs_v)-mean)/std)[:, index_all].float()
        # print(X.size())
        y = torch.FloatTensor([y_day])
        # print("---------", y)
        mask = torch.ones(1,1)
        return X.permute(1, 0), y, index, mask

    def __len__(self):
        # print(self.length_list)
        return sum(self.length_list)
