import argparse

parser = argparse.ArgumentParser(description='MNIST summary generator')
parser.add_argument('--seed', type=str, default="")
parser.add_argument('--method', type=str, default="probability_1step")
parser.add_argument('--outer_lr', default=5e-1, type=float)
parser.add_argument('--max_outer_iter', default=2000, type=int)
parser.add_argument('--runs_name', default="ours", type=str)
parser.add_argument('--project', default="stock_prediction_feature_selection", type=str)
parser.add_argument("--dropout", help="dropout", default=0.5, type=float)
parser.add_argument("--linear", default=False, action="store_true")
parser.add_argument("--lr", help="lr", default=0.1, type=float)
parser.add_argument("--wd", help="wd", default=5e-4, type=float)
parser.add_argument("--opt", help="opt", default="adam", type=str)
parser.add_argument("--hidden", help="hidden", default=256, type=int)
parser.add_argument("--no_bn_decay", default=False, action="store_true")
parser.add_argument("--min_mean", default=False, action="store_true")
parser.add_argument("--div_std", default=False, action="store_true")
parser.add_argument("--input_size", help="input_size", default=28, type=int)
parser.add_argument("--old", type=int, default=2)
parser.add_argument("--batch_size", type=int, default=4096)
parser.add_argument("--x", type=str, default="xnn")
parser.add_argument("--y", type=str, default="3")
parser.add_argument("--T", type=int, default=5)
parser.add_argument("--dim", type=int, default=64)
parser.add_argument("--flying_thres", type=int, default=1000)

parser.add_argument("--arch", type=str, default="CNN")
parser.add_argument("--loss", type=str, default="mse")
parser.add_argument("--name", type=str, default="mse")
parser.add_argument("--train", type=lambda x: [a for a in x.split(";")], default="05_24-06_02")
parser.add_argument("--train3", type=lambda x: [a for a in x.split(";")], default="05_24-06_02")
parser.add_argument("--valid3", type=lambda x: [a for a in x.split(";")], default="05_24-06_02")

parser.add_argument("--valid", type=lambda x: [a for a in x.split(";")], default="05_24-06_02")
parser.add_argument("--test", type=lambda x: [a for a in x.split(";")], default="06_03-06_03")
parser.add_argument("--test2", type=lambda x: [a for a in x.split(";")], default="06_03-06_03")
parser.add_argument("--test4", type=lambda x: [a for a in x.split(";")], default="06_03-06_03")


parser.add_argument("--dim_lstm", type=int, default=256)
parser.add_argument("--lstm_layers", type=int, default=1)
parser.add_argument("--nhead", type=int, default=1)
parser.add_argument("--nlayers", type=int, default=1)
parser.add_argument("--test_interval", type=int, default=2000)
parser.add_argument("--val_split", default=0.2, type=float)
parser.add_argument("--masking_ratio", default=0.5, type=float)
parser.add_argument("--lm", type=int, default=2)

parser.add_argument("--thres_a", default=0.2, type=float)

parser.add_argument("--thres_b", default=0.2, type=float)
parser.add_argument("--thres_c", default=0.2, type=float)

parser.add_argument("--use_p23", type=int, default=0)
parser.add_argument("--dim_feedforward", type=int, default=0)
parser.add_argument("--timepoint", type=int, default=20000)
parser.add_argument("--action_size", type=int, default=2)

parser.add_argument("--lag", type=int, default=1)

parser.add_argument("--dout", type=int, default=4)




parser.add_argument("--only_use_p23", default=False, action="store_true")

parser.add_argument("--leaky", type=float, default=0.01)
parser.add_argument("--bound", type=float, default=0.0)

parser.add_argument("--gamma", type=float, default=1)

parser.add_argument("--test_time", default=False, action="store_true")
parser.add_argument("--pos_encoding", default=False, action="store_true")
parser.add_argument("--absolute_pos", default=False, action="store_true")
parser.add_argument("--batch_norm", default=False, action="store_true")
parser.add_argument("--follow_attn", default=False, action="store_true")
parser.add_argument("--pos_before", default=False, action="store_true")
parser.add_argument("--no_test", default=False, action="store_true")
parser.add_argument("--reweight", default=False, action="store_true")
parser.add_argument("--test_pretrained", default=False, action="store_true")
parser.add_argument("--load_pretrained", default=False, action="store_true")
parser.add_argument("--freeze_pretrained", default=False, action="store_true")
parser.add_argument("--only_xnn", default=False, action="store_true")
parser.add_argument("--save_total_mean", default=False, action="store_true")
parser.add_argument("--change_buyprice", default=False, action="store_true")
parser.add_argument("--div_var", default=False, action="store_true")

parser.add_argument("--div_loss", default=False, action="store_true")
parser.add_argument("--tempannealing", default=False, action="store_true")


parser.add_argument("--rl_profit_path", type=str, default="buy")
parser.add_argument("--rl_profit_path2", type=str, default="sell")

parser.add_argument("--rlbuy_profit_path", type=str, default="buy")
parser.add_argument("--rlbuy_profit_path2", type=str, default="sell")
parser.add_argument("--rlbuy_profit_path3", type=str, default="sell")
parser.add_argument("--rlbuy_profit_path4", type=str, default="sell")


parser.add_argument("--rlsell_profit_path", type=str, default="buy")
parser.add_argument("--rlsell_profit_path2", type=str, default="sell")
parser.add_argument("--rlsell_profit_path3", type=str, default="sell")
parser.add_argument("--rlsell_profit_path4", type=str, default="sell")



parser.add_argument("--valid_buypoint_train", type=str, default="buy")
parser.add_argument("--valid_buypoint_valid", type=str, default="buy")
parser.add_argument("--valid_buypoint_test", type=str, default="buy")
parser.add_argument("--valid_buypoint_test4", type=str, default="buy")



parser.add_argument("--valid_sellpoint_train", type=str, default="buy")
parser.add_argument("--valid_sellpoint_valid", type=str, default="buy")
parser.add_argument("--valid_sellpoint_test", type=str, default="buy")
parser.add_argument("--valid_sellpoint_test4", type=str, default="buy")


parser.add_argument("--valid_2ndbuypoint", type=str, default="buy")
parser.add_argument("--valid_2ndsellpoint", type=str, default="buy")
parser.add_argument("--valid_2ndbuypoint2", type=str, default="buy")
parser.add_argument("--valid_2ndsellpoint2", type=str, default="buy")
parser.add_argument("--valid_2ndbuypoint3", type=str, default="buy")
parser.add_argument("--valid_2ndsellpoint3", type=str, default="buy")
parser.add_argument("--valid_2ndbuypoint4", type=str, default="buy")

parser.add_argument("--valid_2ndsellpoint4", type=str, default="buy")

parser.add_argument("--start", type=int, default=0)




parser.add_argument("--rl_type", type=str, default="buy")

parser.add_argument("--valid_point_train", type=str, default="buy")
parser.add_argument("--valid_point_valid", type=str, default="buy")
parser.add_argument("--valid_point", type=str, default="buy")

parser.add_argument("--valid_buypoint", type=str, default="buy")
parser.add_argument("--valid_sellpoint", type=str, default="buy")
parser.add_argument("--valid_buypoint2", type=str, default="buy")
parser.add_argument("--valid_buypoint3", type=str, default="buy")
parser.add_argument("--valid_buypoint4", type=str, default="buy")

parser.add_argument("--valid_sellpoint2", type=str, default="buy")
parser.add_argument("--valid_sellpoint3", type=str, default="buy")
parser.add_argument("--valid_sellpoint4", type=str, default="buy")
parser.add_argument("--type", type=str, default="buy")
parser.add_argument("--synctype", type=str, default="SyncVectorEnv")



parser.add_argument("--buy_bucket_path", type=str, default="buy")
parser.add_argument("--buy_bucket_path2", type=str, default="buy")
parser.add_argument("--buy_bucket_path3", type=str, default="buy")
parser.add_argument("--buy_bucket_path4", type=str, default="buy")



parser.add_argument("--rand_number", default=False, action="store_true")
parser.add_argument("--draw", default=False, action="store_true")

parser.add_argument("--rand_number0", type=int, default=0)
parser.add_argument("--rand_number3", type=int, default=0)
parser.add_argument("--rand_number4", type=int, default=0)
parser.add_argument("--sampled_days", type=int, default=31)
parser.add_argument("--K", type=int, default=10)
parser.add_argument("--pos", type=int, default=5)


parser.add_argument("--generate_test_predict", default=False, action="store_true")

parser.add_argument("--double_test", default=False, action="store_true")
parser.add_argument("--sharpe", default=False, action="store_true")
parser.add_argument("--sharpe_pg", default=False, action="store_true")
parser.add_argument("--train_pg", default=False, action="store_true")
parser.add_argument("--nonzero_penalty", default=False, action="store_true")
parser.add_argument("--gumbel", default=False, action="store_true")
parser.add_argument("--consider_pos", default=False, action="store_true")

parser.add_argument("--consider_nonzero", default=False, action="store_true")

parser.add_argument("--norm_y", default=False, action="store_true")

parser.add_argument("--eval_per_epoch", type=int, default=1)
parser.add_argument("--train_all_data", default=False, action="store_true")
parser.add_argument("--wandb", default=False, action="store_true")
parser.add_argument("--gae", default=False, action="store_true")


parser.add_argument("--start_eval", type=int, default=20)

parser.add_argument("--d_num", type=int, default=7)
parser.add_argument("--num_steps", type=int, default=1000)
parser.add_argument("--num_envs", type=int, default=2)
parser.add_argument("--gradient_acc_step", type=int, default=1)
parser.add_argument("--bin", type=int, default=5)

parser.add_argument("--indep_std", default=False, action="store_true")
parser.add_argument("--test_clamp", default=False, action="store_true")
parser.add_argument("--for_test_lag1", default=False, action="store_true")
parser.add_argument("--not_squeeze", default=False, action="store_true")



from distutils.util import strtobool

parser.add_argument("--hard_var", default=False, action="store_true")
parser.add_argument("--gae_lambda", type=float, default=0.95, help="the lambda for the general advantage estimation")

parser.add_argument("--norm-adv", default=False, action="store_true")
parser.add_argument("--clip-coef", type=float, default=0.2, help="the surrogate clipping coefficient")
parser.add_argument("--clip-vloss", type=lambda x: bool(strtobool(x)), default=True, nargs="?", const=True, help="Toggles whether or not to use a clipped loss for the value function, as per the paper.")
parser.add_argument("--ent-coef", type=float, default=0.01, help="coefficient of the entropy")
parser.add_argument("--vf-coef", type=float, default=0.5, help="coefficient of the value function")
parser.add_argument("--remaining", type=float, default=1.0, help="coefficient of the value function")
parser.add_argument("--div_grad_acc", default=False, action="store_true")
parser.add_argument("--not_use_bin_feature", default=False, action="store_true")
parser.add_argument("--updates_thres", type=int, default=20)
parser.add_argument("--profit_type", type=int, default=19)

parser.add_argument("--max_p", type=float, default=1625.985, help="coefficient of the value function")
parser.add_argument("--clamp_neg", default=False, action="store_true")
parser.add_argument("--sigmoid_neg", default=False, action="store_true")
parser.add_argument("--exp_neg", default=False, action="store_true")

parser.add_argument("--linear_init", default=False, action="store_true")
parser.add_argument("--take_normal", default=False, action="store_true")
parser.add_argument("--take_logistic", default=False, action="store_true")

parser.add_argument("--consider_std", default=False, action="store_true")

parser.add_argument("--take_mean", default=False, action="store_true")
parser.add_argument("--nop", default=False, action="store_true")
parser.add_argument("--consider_y0", default=False, action="store_true")
parser.add_argument("--learn_bias", default=False, action="store_true")

parser.add_argument("--sig_alpha", type=float, default=6.0, help="coefficient of the value function")

parser.add_argument("--bias_constant", type=float, default=1.386, help="coefficient of the value function")

parser.add_argument("--ip", type=str, default="54.65.16.142")
parser.add_argument("--set_seed", default=False, action="store_true")
parser.add_argument("--write_db", default=False, action="store_true")
parser.add_argument("--predict_all", default=False, action="store_true")
parser.add_argument("--compute_trade", default=False, action="store_true")
parser.add_argument("--perform_backtest", default=False, action="store_true")
parser.add_argument("--early_stop", default=False, action="store_true")
parser.add_argument("--consider_zero", default=False, action="store_true")
parser.add_argument("--use_true_lag", default=False, action="store_true")

parser.add_argument("--bias_const", type=int, default=0)
parser.add_argument("--repeat_times", type=int, default=0)



parser.add_argument("--offset", type=int, default=0)
parser.add_argument("--openoffset", type=int, default=0)

parser.add_argument("--m1", type=int, default=2)
parser.add_argument("--m2", type=int, default=4)


parser.add_argument("--no_order", default=False, action="store_true")
parser.add_argument("--t2", default=False, action="store_true")

parser.add_argument("--fix_open", default=False, action="store_true")
parser.add_argument("--tino", default=False, action="store_true")
parser.add_argument("--seg_sharpe", default=False, action="store_true")


parser.add_argument("--fix_close", default=False, action="store_true")
parser.add_argument("--not_div", default=False, action="store_true")

parser.add_argument("--d_list", nargs="*", type=int, default=[4])




args = parser.parse_args()