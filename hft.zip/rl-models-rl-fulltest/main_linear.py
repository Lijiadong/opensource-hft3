import numpy as np
import pandas as pd
from args import args
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import Ridge
import datetime
from sklearn.neural_network import MLPRegressor

date_list = args.train[0]
start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
print(start_month, start_day, end_month, end_day)
start = datetime.date(2022,start_month,start_day)
end = datetime.date(2022,end_month,end_day)
x_l = []
print(start, end)
for i in range((end-start).days+1):
    day = start + datetime.timedelta(days=i)
    print(day, day.month, day.day)
    month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
    day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 

    with open('data_6/x_'+month_str+'_'+day_str+'.npy', 'rb') as f:
        test = np.load(f)
    with open('data_6/y_'+month_str+'_'+day_str+'.npy', 'rb') as f:
        y = np.load(f)

    from joblib import dump

    l_train = int(test.shape[0]*14/15)
    # model = Ridge(normalize=False, fit_intercept=False, alpha=100)
    model = MLPRegressor(hidden_layer_sizes=(2), verbose=True)
    model = model.fit(test[:l_train], y[:l_train])


    print(r2_score(y[:l_train], model.predict(test[:l_train])))
    print(r2_score(y[l_train:], model.predict(test[l_train:])))
    # print(r2_score(y2, model.predict(test2)))

    # print(model.predict(test2))

    dump(model, 'mlp_'+month_str+'_'+day_str+'.joblib') 

# with open('data_6/xnn_'+file2+'.npy', 'rb') as f:
#     test3 = np.load(f)

# print(test3)


# a = pd.read_pickle('data_6/xnn2_'+file2+'.pkl')
# print(a)
# c = a.to_numpy()
# print(c)

# 0.04769761679400908
# 0.04715703476543387
# 0.0398958424442174
