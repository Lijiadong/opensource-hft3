import torch
import numpy as np
def noise_mask(X, masking_ratio, lm):
    mask = torch.ones_like(X, dtype=torch.bool)
    for m in range(X.size(1)): 
        print(m)
        mask[:, m] = geom_noise_mask_single(X.size(0), masking_ratio, lm)
        print(mask[:, m])
    return mask


def geom_noise_mask_single(L, masking_ratio, lm):
    keep_mask = torch.ones(L, dtype=torch.bool)
    p_m = 1 / lm 
    p_u = p_m * masking_ratio / (1 - masking_ratio)  
    p = [p_m, p_u]

    state = int(np.random.rand() > masking_ratio) 
    for i in range(L):
        keep_mask[i] = state  
        if np.random.rand() < p[state]:
            state = 1 - state
    return keep_mask

a = noise_mask(torch.randn(5, int(2*1e7)), 0.15, 2)
print(a.permute(1, 0))
torch.save(a, "noise_mask_0.15_2.pt")