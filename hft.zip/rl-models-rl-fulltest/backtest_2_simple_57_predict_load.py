import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt
import torch
from multiprocessing import Pool


def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test)
flist = genflist(args.test[0])
print(flist)
filename = "fu"
data = pd.DataFrame()
first = True
data_l =[]
xnn_l = []
# y_l = []

for file in flist:
    print(file)
    # data = pd.read_pickle('data_6/data_'+file+'.pkl')
    # with open('data_6/xnn_'+file+'.npy', 'rb') as f:
        # xnn = np.load(f)
    # with open('data_6/y_'+file+'.npy', 'rb') as f:
        # y = np.load(f)
    # data_l.append(data)
    # xnn_l.append(xnn)
    # y_l.append(y)
# data = pd.concat(data_l)
# xnn = np.concatenate(xnn_l, axis=0)
tmp = np.load("profit_l_08_11-09_05_57_0_1000000-6_predictchange.npy")
profit_l = np.zeros((len(tmp), 6))
from multiprocessing import Process
profit_l_list = []
number = 0
for i in range(0, int(len(tmp)+2e7), int(1e6)):
    if i < len(tmp):
        end = int(i+1e6)
        end = min(len(tmp)-5, end)
        profit_l[int(i):end] = np.load("profit_l_"+args.test[0]+"_57_"+str(int(i))+"_"+str(end)+"-6_predictchange.npy")[int(i):end]
        profit_l_list.append(np.load("profit_l_"+args.test[0]+"_57_"+str(int(i))+"_"+str(end)+"-6_predictchange.npy"))
        # nonzeros = 0
        print("start, end", i, end)
        print(np.sum(np.max(profit_l_list[number], axis=1)))
        print(np.sum(profit_l_list[number][:, 0]), np.sum(profit_l_list[number][:, 0]!=0))
        print(np.sum(profit_l_list[number][:, 1]), np.sum(profit_l_list[number][:, 1]!=0))
        print(np.sum(profit_l_list[number][:, 2]), np.sum(profit_l_list[number][:, 2]!=0))
        print(np.sum(profit_l_list[number][:, 3]), np.sum(profit_l_list[number][:, 3]!=0))
        print(np.sum(profit_l_list[number][:, 4]), np.sum(profit_l_list[number][:, 4]!=0))
        print(np.sum(profit_l_list[number][:, 5]), np.sum(profit_l_list[number][:, 5]!=0))
        # print(np.sum(profit_l_list[number][:, 6]), np.sum(profit_l_list[number][:, 6]!=0))
    # exit(-1)
    # for j in range(int(i), end):
    #     # print(j)
    #     if not np.all(profit_l_list[i][j] == 0):
    #         nonzeros += 1
    #         print(j, nonzeros, profit_l_list[i][j])
        number += 1
        np.save("profit_l_"+args.test[0]+"_57_6_fullpredictchange.npy", profit_l)

    
    # print(i, nonzeros)
    
print(np.sum(np.max(profit_l, axis=1)))
print(np.sum(profit_l[:, 0]), np.sum(profit_l[:, 0]!=0))
print(np.sum(profit_l[:, 1]), np.sum(profit_l[:, 1]!=0))
print(np.sum(profit_l[:, 2]), np.sum(profit_l[:, 2]!=0))
print(np.sum(profit_l[:, 3]), np.sum(profit_l[:, 3]!=0))
print(np.sum(profit_l[:, 4]), np.sum(profit_l[:, 4]!=0))
print(np.sum(profit_l[:, 5]), np.sum(profit_l[:, 5]!=0))

