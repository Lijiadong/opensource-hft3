import torch
import models
from args import args
pretrained = torch.load("best_model_yCNNLSTM"+args.y+"_"+";".join(args.train)+"_"+";".join(args.test)+str(args.seed)+".pt")
print(pretrained)
pretrained.eval()
model = models.CNNLSTMScript().cuda()

pretrained = pretrained.state_dict()

model_state_dict = model.state_dict()
# print(model_state_dict.keys())
for k, v in pretrained.items():
    if k not in model_state_dict or v.size() != model_state_dict[k].size():
        if k not in model_state_dict:
            print("not in state dict")
        else:
            print("size not match")
        print("IGNORE:", k)
    else:
        print("LOAD:", k)
pretrained = {
    k: v
    for k, v in pretrained.items()
    if (k in model_state_dict and v.size() == model_state_dict[k].size())
}
model_state_dict.update(pretrained)
model.load_state_dict(model_state_dict)
model.eval()
input = torch.ones(1, 57, args.T).cuda()
traced_script_module = torch.jit.trace(model, input)
print(model(input))
traced_script_module.save("best_model_y"+args.y+"_"+";".join(args.train)+"_"+";".join(args.test)+"script.pt")

