import torch
import models
from args import args
# model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+str(args.seed)+".pt")
model0 = torch.load("results/best_model_RLTSTransformerEncoderRLSeq7_12_11-01_20_01_21-01_31_02_01-02_081676033376.6132174lag11epoch11.pt")
model = model0.actor_mean0
model.eval()
model.cpu()
input = torch.ones(1, args.input_size, args.T)
traced_script_module = torch.jit.trace(model, input)
print(model(input), model(input).size())
# traced_script_module.save("best_model_y"+args.arch+args.y+"_"+";".join(args.train)+"_"+";".join(args.test)+str(args.seed)+"script.pt")
traced_script_module.save("results_new_3/best_model_RLTSTransformerEncoderRLSeq7_12_11-01_20_01_21-01_31_02_01-02_081676033376.6132174lag11epoch11_open_continuous.pt")

model = model0.actor_mean1
model.eval()
model.cpu()
input = torch.ones(1, args.input_size, args.T)
traced_script_module = torch.jit.trace(model, input)
print(model(input), model(input).size())
# traced_script_module.save("best_model_y"+args.arch+args.y+"_"+";".join(args.train)+"_"+";".join(args.test)+str(args.seed)+"script.pt")
traced_script_module.save("results_new_3/best_model_RLTSTransformerEncoderRLSeq7_12_11-01_20_01_21-01_31_02_01-02_081676033376.6132174lag11epoch11_close_discrete.pt")