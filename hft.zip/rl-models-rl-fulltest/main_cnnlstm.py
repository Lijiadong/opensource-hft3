from args import args
from plistlib import load
from re import T
import torch
import torch.nn as nn
import stock
import numpy as np
import tqdm
import logger
import argparse
import wandb
import copy 
import models
# import torch.utils.benchmark as benchmark
# import multiprocessing as mp
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
if args.old == 9:
    from torch.utils.data.sampler import WeightedRandomSampler
    from stock import wegihtedsampler
# mp.set_start_method('spawn')
import matplotlib.pyplot as plt

torch.set_default_dtype(torch.float32)
epochs = 1000
lr = args.lr
if args.old == 28:
    pass
elif args.old == 24 or args.old == 25:
    from stock import abs_profit, mean_profit, std_profit, exist, y0, arr, vari, abs_profit_, mean_profit_, std_profit_, y0_, vari_
elif args.old == 21 or args.old == 23 or args.old == 26:
    from stock import abs_profit, mean_profit, std_profit, exist, y0, arr, vari
elif args.old == 29 or args.old == 30 or args.old == 31 or args.old == 32 or args.old == 33 or args.old == 41:
    from stock import abs_profit, mean_profit, std_profit, exist, y0, vari
elif args.old != 18 and args.old != 27:
    from stock import y_length_list, y_length_list_2
import datetime
args.eval = False
args.temp = 1
from stock import StockAggregate18, StockAggregate27, StockAggregate29
max_r2 = 0
max_r2_itr = -1
min_l = 0
min_l_itr = -1
max_test2_r2 = 0
max_test2_r2_itr = -1
corr_test2_r2 = 0
max_p = -1
max_p_itr = -1
corr_p = 0

# import psutil
# count = psutil.cpu_count()
# p = psutil.Process()
# cpu_lst = p.cpu_affinity()
# print(cpu_lst)
# p.cpu_affinity([i for i in range(0, 26)])


def mean(l):
    return sum(l)/len(l)

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def assign_learning_rate(optimizer, new_lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = new_lr

def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.reshape(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

def calculate_real_stats(model, dataset, evaluate=True):
    if evaluate:
        model.eval()
    else:
        model.train()
    y_hat_total = torch.zeros(len(dataset)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_total = dataset.data_y[args.T - 1:].cuda()
    with torch.no_grad():
        for i, (x, y, index) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat_total[index] = model(x).squeeze().detach()
            # print(y_hat_total.nonzero().nelement())
        loss = ((y_total-y_hat_total)**2).mean().item()
        corr = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2 = (1-((y_total-y_hat_total)**2).sum()/((y_total-y_total.mean())**2).sum()).item()
    return loss, corr, r2

def calculate_real_stats_test(model, dataset, y_length_list, evaluate=True, step=0, type_="test"):
    if evaluate:
        model.eval()
    else:
        model.train()
    y_hat_total = torch.zeros(len(dataset)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False,
                                             sampler=torch.utils.data.SequentialSampler(dataset),
                                             batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_total = dataset.data_y[args.T - 1:].cuda()
    with torch.no_grad():
        for i, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            if "Normal" not in args.arch:
                y_hat_total[index] = model(x).squeeze().detach()
            else:
                y_hat_total[index] = model(x)[:, 0].squeeze().detach()
            # print(y_hat_total.nonzero().nelement())
        loss_all = ((y_total - y_hat_total) ** 2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1 - ((y_total - y_hat_total) ** 2).sum() / ((y_total - y_total.mean()) ** 2).sum()).item()
        wandb.log({type_+"_all/loss_all": loss_all}, step=step)
        wandb.log({type_+"_all/corr_all": corr_all}, step=step)
        wandb.log({type_+"_all/r2_all": r2_all}, step=step)
        length_to_date = 0
        loss_l, corr_l, r2_l = [], [], []
        for i, l in enumerate(y_length_list):
            length_to_date_end = length_to_date + l
            y_total_seg = y_total[length_to_date:length_to_date_end]
            y_hat_total_seg = y_hat_total[length_to_date:length_to_date_end]
            loss = ((y_total_seg - y_hat_total_seg) ** 2).mean().item()
            corr = abs(np.corrcoef(torch.cat((y_total_seg.unsqueeze(1), y_hat_total_seg.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2 = (1 - ((y_total_seg - y_hat_total_seg) ** 2).sum() / ((y_total_seg - y_total_seg.mean()) ** 2).sum()).item()
            length_to_date = length_to_date_end
            wandb.log({type_+"/loss_" + str(i): loss}, step=step)
            wandb.log({type_+"/corr_" + str(i): corr}, step=step)
            wandb.log({type_+"r2_" + str(i): r2}, step=step)
            print("day", i, loss, corr, r2)
            loss_l.append(loss)
            corr_l.append(corr)
            r2_l.append(r2)
        wandb.log({type_+"/loss_avg": mean(loss_l)}, step=step)
        wandb.log({type_+"/corr_avg": mean(corr_l)}, step=step)
        wandb.log({type_+"/r2_avg": mean(r2_l)}, step=step)
    return loss_all, corr_all, r2_all

def calculate_real_stats_test18(model, evaluate=True, step=0, date_list=args.test, type_="test"):
    import datetime
    if evaluate:
        model.eval()
    else:
        model.train()
    with torch.no_grad():
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        if end_month < start_month:
            year = 2023
        else:
            year = 2022
        end = datetime.date(year,end_month,end_day)
        print(start, end)
        y_hat_total = None
        loss_l, corr_l, r2_l = [], [], []

        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            print(i, day, month_str, day_str)
            if args.use_p23 == 13:
                xnn = np.load('data_6/xnn6'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x3'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.use_p23 == 12:
                xnn = np.load('data_6/xnn5'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x2'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            else:
                xnn = np.load('data_6/xnn'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            if args.y == "0":
                y = np.load('data_6/y'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "3":
                y = np.load('data_6/y3'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "4":
                y = np.load('data_6/y4'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "50":
                y = np.load('data_6/y50'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            dataset = StockAggregate18(type_, xnn=xnn, x=x, y=y)


            y_hat_day_i = torch.zeros(len(dataset)).cuda()
            loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False,
                                                    sampler=torch.utils.data.SequentialSampler(dataset),
                                                    batch_size=args.batch_size, num_workers=4, pin_memory=True)
            y_day_i = torch.from_numpy(dataset.data_y[args.T - 1:]).float().cuda()
            print(y_day_i.size(0))
            for _, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
                x, y = x.cuda(), y.cuda()
                y_hat_day_i[index] = model(x).squeeze().detach()
            loss_day_i = ((y_day_i - y_hat_day_i) ** 2).mean().item()
            corr_day_i = abs(np.corrcoef(torch.cat((y_day_i.unsqueeze(1), y_hat_day_i.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2_day_i = (1 - ((y_day_i - y_hat_day_i) ** 2).sum() / ((y_day_i - y_day_i.mean()) ** 2).sum()).item()
            print(i, day, month_str, day_str, loss_day_i, corr_day_i, r2_day_i)
            wandb.log({type_+"/loss_" + str(i): loss_day_i}, step=step)
            wandb.log({type_+"/corr_" + str(i): corr_day_i}, step=step)
            wandb.log({type_+"r2_" + str(i): r2_day_i}, step=step)
            loss_l.append(loss_day_i)
            corr_l.append(corr_day_i)
            r2_l.append(r2_day_i)
            if i == 0:
                y_hat_total = y_hat_day_i
                y_total = y_day_i
            else:
                y_hat_total = torch.cat([y_hat_total, y_hat_day_i], dim=0)
                y_total = torch.cat([y_total, y_day_i], dim=0)
            del dataset, loader_seq
            print(y_hat_total.size())
        wandb.log({type_+"/loss_avg": mean(loss_l)}, step=step)
        wandb.log({type_+"/corr_avg": mean(corr_l)}, step=step)
        wandb.log({type_+"/r2_avg": mean(r2_l)}, step=step)
        loss_all = ((y_total - y_hat_total) ** 2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1 - ((y_total - y_hat_total) ** 2).sum() / ((y_total - y_total.mean()) ** 2).sum()).item()
        wandb.log({type_+"_all/loss_all": loss_all}, step=step)
        wandb.log({type_+"_all/corr_all": corr_all}, step=step)
        wandb.log({type_+"_all/r2_all": r2_all}, step=step)
    return loss_all, corr_all, r2_all

def calculate_real_stats_test27(model, evaluate=True, step=0, date_list=args.test, type_="test"):
    import datetime
    if evaluate:
        model.eval()
    else:
        model.train()
    with torch.no_grad():
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        if end_month < start_month:
            year = 2023
        else:
            year = 2022
        end = datetime.date(year,end_month,end_day)
        print(start, end)
        y_hat_total = None
        loss_l, corr_l, r2_l = [], [], []

        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            print(i, day, month_str, day_str)
            xnn = np.load('data_6/xnn'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            x = np.load('data_6/x'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            xabs = np.load('data_6/xabs'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            if args.y == "0":
                y = np.load('data_6/y'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "3":
                y = np.load('data_6/y3'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "4":
                y = np.load('data_6/y4'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "50":
                y = np.load('data_6/y50'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            dataset = StockAggregate27(type_, xnn=xnn, x=x, y=y, xabs=xabs)


            y_hat_day_i = torch.zeros(len(dataset)).cuda()
            loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False,
                                                    sampler=torch.utils.data.SequentialSampler(dataset),
                                                    batch_size=args.batch_size, num_workers=4, pin_memory=True)
            y_day_i = torch.from_numpy(dataset.data_y[args.T - 1:]).float().cuda()
            print(y_day_i.size(0))
            for _, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
                x, y = x.cuda(), y.cuda()
                y_hat_day_i[index] = model(x).squeeze().detach()
            loss_day_i = ((y_day_i - y_hat_day_i) ** 2).mean().item()
            corr_day_i = abs(np.corrcoef(torch.cat((y_day_i.unsqueeze(1), y_hat_day_i.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2_day_i = (1 - ((y_day_i - y_hat_day_i) ** 2).sum() / ((y_day_i - y_day_i.mean()) ** 2).sum()).item()
            print(i, day, month_str, day_str, loss_day_i, corr_day_i, r2_day_i)
            wandb.log({type_+"/loss_" + str(i): loss_day_i}, step=step)
            wandb.log({type_+"/corr_" + str(i): corr_day_i}, step=step)
            wandb.log({type_+"r2_" + str(i): r2_day_i}, step=step)
            loss_l.append(loss_day_i)
            corr_l.append(corr_day_i)
            r2_l.append(r2_day_i)
            if i == 0:
                y_hat_total = torch.cat((torch.zeros((args.T-1)).cuda(), y_hat_day_i), dim=0)
                y_total = torch.cat((torch.zeros(args.T-1).cuda(), y_day_i), dim=0)
            else:
                y_hat_total = torch.cat([y_hat_total, torch.zeros((args.T-1)).cuda(), y_hat_day_i], dim=0)
                y_total = torch.cat([y_total, torch.zeros((args.T-1)).cuda(), y_day_i], dim=0)   
            print(y_hat_total.size())
        wandb.log({type_+"/loss_avg": mean(loss_l)}, step=step)
        wandb.log({type_+"/corr_avg": mean(corr_l)}, step=step)
        wandb.log({type_+"/r2_avg": mean(r2_l)}, step=step)
        loss_all = ((y_total - y_hat_total) ** 2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1 - ((y_total - y_hat_total) ** 2).sum() / ((y_total - y_total.mean()) ** 2).sum()).item()
        wandb.log({type_+"_all/loss_all": loss_all}, step=step)
        wandb.log({type_+"_all/corr_all": corr_all}, step=step)
        wandb.log({type_+"_all/r2_all": r2_all}, step=step)
    return loss_all, corr_all, r2_all



def calculate_test_pretrained(model, dataset, evaluate=True, step=0):
    if evaluate:
        model.eval()
    else:
        model.train()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    losses = logger.AverageMeter("Loss", ":.3f")
    progress = logger.ProgressMeter(len(loader_seq), [losses], prefix=f"Val Epoch: [{epoch}]")
    with torch.no_grad():
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y, mask = x.cuda(), y.cuda(), mask.cuda() 
            y_hat = model(x*mask).squeeze()
            loss = criterion(y_hat*(~mask), x*(~mask))
            losses.update(loss.item(), x.size(0))
            if i % 300 == 0:
                progress.display(i)
        progress.display(len(loader_seq))
        wandb.log({f"test/loss": losses.avg}, step=step)
    return losses.avg


def calculate_test_classification(model, dataset, evaluate=True, step=0):
    if evaluate:
        model.eval()
    else:
        model.train()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    losses = logger.AverageMeter("Loss", ":.3f")
    top1 = logger.AverageMeter("Acc@1", ":6.2f")
    top2 = logger.AverageMeter("Acc@2", ":6.2f")
    progress = logger.ProgressMeter(len(loader_seq), [losses, top1, top2], prefix=f"Val Epoch: [{epoch}]")
    y_hat_total = torch.zeros(len(dataset), 5).cuda()
    y_total = dataset.data_y[args.T - 1:].cuda().long()
    confmat = ConfusionMatrix(num_classes=5).cuda()
    with torch.no_grad():
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat = model(x).squeeze()
            loss = criterion(y_hat, y.long())
            losses.update(loss.item(), x.size(0))
            acc1, acc2 = accuracy(y_hat, y, topk=(1, 2))
            top1.update(acc1.item(), x.size(0))
            top2.update(acc2.item(), x.size(0))
            y_hat_total[index] = y_hat
            if i % 300 == 0:
                progress.display(i)
        print(confmat(y_hat_total, y_total))
        progress.display(len(loader_seq))
        wandb.log({f"test/loss": losses.avg}, step=step)
        wandb.log({f"test/top1": top1.avg}, step=step)
        wandb.log({f"test/top2": top2.avg}, step=step)

from torchmetrics import ConfusionMatrix



def calculate_train_RLd3(model, dataset, rl_profit_path, valid_sellpoint, valid_buypoint, type_, step=0, tag="train", rand_number=str(args.seed)):
    model.eval()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    if args.old != 31:
        y_hat_total = torch.zeros((len(dataset), 7)).cuda()
        
    else:
        y_hat_total = torch.zeros((dataset.data_y.size(0), 7)).cuda()
        y_hat_total_shrink = torch.zeros((len(dataset), 7)).cuda()

        print(y_hat_total.size())
    with torch.no_grad():
        start, end = 0, 0
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            
            x = x.cuda()
            out = model(x).squeeze()
            end += out.size(0)
            y_hat_total[index] = out
            if args.old == 31:
                y_hat_total_shrink[start:end] = out
            start = end
    if args.old == 31:
        for j in range(6):
            print(torch.sum(torch.argmax(y_hat_total_shrink, axis=1) == j)/y_hat_total_shrink.size(0))
    # torch.save(y_hat_total, "y_hat_total.pttrain"+str(args.rand_number))
    # y_hat_total = torch.load("y_hat_total.pttrain"+str(args.rand_number))
    if args.old != 31:
        if args.old != 29:
            y_hat_total = torch.cat((torch.zeros((args.T-1, 7)).cuda(), y_hat_total), dim=0)
        else:
            l1, l2, l3 = dataset.length_list[0], dataset.length_list[1], dataset.length_list[2]
            y_hat_total = torch.cat((torch.zeros((args.T-1, 7)).cuda(), y_hat_total[:l1], torch.zeros((args.T-1, 7)).cuda(), y_hat_total[l1:l2+l1], torch.zeros((args.T-1, 7)).cuda(), y_hat_total[l1+l2:]), dim=0)

    # y_hat_total = torch.load("y_hat_total.pttrain960264208")
    y_hat_total = y_hat_total.detach().cpu()
    
    p_sum = calculate_profit(y_hat_total, rl_profit_path, valid_sellpoint, valid_buypoint, type_, step, tag=tag, rand_number=rand_number)

    return p_sum


def calculate_train_RLd3_32(model, dataset, rlbuy_profit_path, rlsell_profit_path, valid_sellpoint, valid_buypoint, step=0, tag="train", rand_number=str(args.seed)):
    # return 0
    
    model.eval()
    # model.train()
    args.eval = True
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    if args.old == 33:
        print(dataset.data_y[0])
        y_hat_total = torch.zeros((dataset.data_y[0].size(0), args.d_num*2)).cuda()
    else:
        y_hat_total = torch.zeros((dataset.data_y.size(0), args.d_num*2)).cuda()
    y_hat_total_shrink = torch.zeros((len(dataset), args.d_num*2)).cuda()
    with torch.no_grad():
        start, end = 0, 0
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x = x.cuda()
            # x = torch.from_numpy(np.load("xin2_seg.npy")).cuda().permute(1,0).unsqueeze(0)
            out = model(x).squeeze()
            # print(x)
            # print(out)
            # np.save("out_seg.npy", out)
            # exit(-1)
            
            end += out.size(0)
            # np.save("x_check.npy", x.detach().cpu().numpy())
            # np.save("out_check.npy", out.detach().cpu().numpy())
            # print(x.size(), x, out.size(), out)
            # exit(-1)
            y_hat_total[index] = out
            y_hat_total_shrink[start:end] = out
            start = end
    # print(y_hat_total_shrink[73])
    # print(torch.nonzero(torch.argmax(y_hat_total_shrink[:, 7:], axis=1) == 4))
    
    for j in range(args.d_num-1):
        print("buy portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, :args.d_num], axis=1) == j)/y_hat_total_shrink.size(0))
        print("sell portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, args.d_num:], axis=1) == j)/y_hat_total_shrink.size(0))
        # print("buy portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, :7], axis=1) == j))
        # print("sell portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, 7:], axis=1) == j))

    # torch.save(y_hat_total, "y_hat_total.pttrain"+str(args.rand_number))
    # y_hat_total = torch.load("y_hat_total.pttrain"+str(args.rand_number))
    # y_hat_total = torch.load("y_hat_total.pttrain960264208")
    y_hat_total = y_hat_total.detach().cpu()
    
    p_sum1, lines_p1, line_chosen_p1 = calculate_profit(y_hat_total[:, :args.d_num], rlbuy_profit_path, valid_sellpoint, valid_buypoint, "buy", step, tag=tag, rand_number=rand_number)
    p_sum2, lines_p2, line_chosen_p2 = calculate_profit(y_hat_total[:, args.d_num:], rlsell_profit_path, valid_sellpoint, valid_buypoint, "sell", step, tag=tag, rand_number=rand_number)
    wandb.log({tag+"/profit_constrained_all": p_sum1+p_sum2}, step=step)
    wandb.log({tag+"/profit_constrained_buy": p_sum1}, step=step)
    wandb.log({tag+"/profit_constrained_sell": p_sum2}, step=step)


    for lag in range(args.start, args.lag):
        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(0, args.d_num-1):
                ax1.plot(lines_p1[lag][j][::interval]+lines_p2[lag][j][::interval])
            ax1.plot(line_chosen_p1[lag][::interval] + line_chosen_p2[lag][::interval])
            plt.legend()
            plt.show()
            plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_"+str(lag+1)+"_position"+str(args.pos)+".png")  
            plt.clf()
    if args.draw:
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        if args.lag == 2:
            for j in range(args.start, args.d_num-1):
                ax1.plot(lines_p1[0][j][::interval]+lines_p2[0][j][::interval]+lines_p1[1][j][::interval]+lines_p2[1][j][::interval])
            ax1.plot(line_chosen_p1[0][::interval] + line_chosen_p2[0][::interval] + line_chosen_p1[1][::interval] + line_chosen_p2[1][::interval])
        elif args.lag == 1:
            for j in range(args.start, args.d_num-1):
                ax1.plot(lines_p1[0][j][::interval]+lines_p2[0][j][::interval])
            ax1.plot(line_chosen_p1[0][::interval] + line_chosen_p2[0][::interval])
        plt.legend()
        plt.show()
        plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_123position"+str(args.pos)+".png")
        plt.clf()
    return p_sum1 + p_sum2  

def calculate_profit(y_hat_total, rl_profit_path, valid_sellpoint_path, valid_buypoint_path, type_, step, tag="test", rand_number="0"):
    p_d_sum = {i:0 for i in range(0, args.d_num-1)}
    p_sum = []
    y_total_123 = None
    chosen_value_total_123 = None
    max_total_123 = None
    lines_lag, line_chosen_lag, lines_position_lag, line_chosen_position_lag, y_total_lag, chosen_value_total_lag = [], [], [], [], [], []

    for lag in range(1, args.lag+1):
        y0 = np.load(rl_profit_path+"_"+str(lag)+str(lag)+".npy")
        y_total = torch.from_numpy(y0)
        print("----------For ", tag, type_, lag, "----------")
        chosen_value_total = y_total.gather(1, torch.argmax(y_hat_total, axis=1).unsqueeze(1)).squeeze()
        max_total = torch.max(y_total, axis=1)[0]
        chosen_value_total_lag.append(chosen_value_total)
        lines = np.cumsum(y0, axis=0)
        lines_lag.append(lines)

        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(args.start, args.d_num):
                ax1.plot(lines[::interval, j])
            
            line_chosen = np.cumsum(chosen_value_total.cpu().detach().numpy())
            line_chosen_lag.append(line_chosen)
            ax1.plot(line_chosen[::interval])

            plt.legend()
            plt.show()
            plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+".png")

        lines_position = []
        

            
        # for j in range(6):
        #     print(torch.sum(torch.argmax(y_hat_total, axis=1) == j)/y_hat_total.size(0))

        if lag == 1:
            y_total_123 = y_total
            chosen_value_total_123 = chosen_value_total
            max_total_123 = max_total
        else:
            y_total_123 = y_total + y_total_123
            chosen_value_total_123 = chosen_value_total + chosen_value_total_123
            max_total_123 = max_total + max_total_123

        if type_ == "buy":
            valid_sellpoint = np.load(valid_sellpoint_path+"_"+str(lag)+str(lag)+".npy")
            for thres in range(0, 1, 1):
                for pos in [args.pos]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = temp_chosen_total.cpu().detach().numpy()
                    p, profit_chosen, pos_dict = calculate_profit_with_chosen(valid_sellpoint, temp_chosen_total, position=pos, lag=lag)
                    profit_chosen_pt = torch.from_numpy(profit_chosen).cuda()
                    nonzero_mask = (profit_chosen_pt!=0)
                    print("chosen buy, pos, p, thres", pos, p, thres, (torch.sum(profit_chosen_pt)/(-torch.sum(torch.clamp(profit_chosen_pt, max=0))+1e-20)).item(), (torch.mean(profit_chosen_pt[nonzero_mask])/(1e-20+torch.std(profit_chosen_pt[nonzero_mask]))).item())
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
                    # exit(-1)

                    if thres == 0 and pos == args.pos:
                        p_sum.append(p)  
                        torch.save(pos_dict, "pos_dict.pttestbuy"+str(lag)+str(args.rand_number))
                        line_chosen_postion = np.cumsum(profit_chosen)
                    wandb.log({tag+str(type_)+str(lag)+"/pos_mean_chosen"+str(args.pos): sum(pos_dict)/len(pos_dict)}, step=step)
                    wandb.log({tag+str(type_)+str(lag)+"/pos_max_chosen"+str(args.pos): max(pos_dict)}, step=step)
            for pos in [args.pos]:
                for j in range(0, args.d_num-1): 
                    p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=pos, lag=lag)
                    profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
                    nonzero_mask = (profit_fix_position_pt!=0)
                    print("fix buy, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item())
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
                    wandb.log({tag+str(type_)+str(lag)+"/pos_mean"+str(j): sum(pos_dict)/len(pos_dict)}, step=step)
                    wandb.log({tag+str(type_)+str(lag)+"/pos_max"+str(j): max(pos_dict)}, step=step) 
                    p_d_sum[j] += p
                    lines_position.append(np.cumsum(profit_fix_position))

        if type_ == "sell":
            valid_buypoint = np.load(valid_buypoint_path+"_"+str(lag)+str(lag)+".npy")
            for thres in range(0, 1, 1):
                for pos in [args.pos]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = temp_chosen_total.cpu().detach().numpy()
                    p, profit_chosen, pos_dict = calculate_profit_with_chosen(valid_buypoint, temp_chosen_total, position=pos, lag=lag)
                    profit_chosen_pt = torch.from_numpy(profit_chosen).cuda()
                    nonzero_mask = (profit_chosen_pt!=0)
                    print("chosen sell, pos, p, thres", pos, p, thres, (torch.sum(profit_chosen_pt)/(-torch.sum(torch.clamp(profit_chosen_pt, max=0))+1e-20)).item(), (torch.mean(profit_chosen_pt[nonzero_mask])/(1e-20+torch.std(profit_chosen_pt[nonzero_mask]))).item())    
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   


                    if thres == 0 and pos == args.pos:
                        p_sum.append(p)  
                        torch.save(pos_dict, "pos_dict.pttestsell"+str(lag)+str(args.rand_number))
                        line_chosen_postion = np.cumsum(profit_chosen)
                    wandb.log({tag+str(type_)+str(lag)+"/pos_mean_chosen"+str(args.pos): sum(pos_dict)/len(pos_dict)}, step=step)
                    wandb.log({tag+str(type_)+str(lag)+"/pos_max_chosen"+str(args.pos): max(pos_dict)}, step=step)

            for pos in [args.pos]:
                for j in range(0, args.d_num-1): 
                    p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_buypoint, y0[:, j], position=pos, lag=lag)
                    profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
                    nonzero_mask = (profit_fix_position_pt!=0)
                    print("fix sell, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item()) 
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict), )   
                    wandb.log({tag+str(type_)+str(lag)+"/pos_mean"+str(j): sum(pos_dict)/len(pos_dict)}, step=step)
                    wandb.log({tag+str(type_)+str(lag)+"/pos_max"+str(j): max(pos_dict)}, step=step) 
                    p_d_sum[j] += p
                    lines_position.append(np.cumsum(profit_fix_position))

        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(args.start, args.d_num-1):
                ax1.plot(lines_position[j][::interval])
            ax1.plot(line_chosen_postion[::interval])
            plt.legend()
            plt.show()
            plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+"position"+str(args.pos)+".png")
            lines_position_lag.append(lines_position)
            line_chosen_position_lag.append(line_chosen_postion)
        
        for j in range(0, 6):
            wandb.log({tag+str(type_)+str(lag)+"/profit-loss"+str(j): torch.sum(y_total[:, j]).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/(profit-loss~loss)"+str(j): (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/profit"+str(j): (torch.sum(torch.clamp(y_total[:, j], min=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/loss"+str(j): (-torch.sum(torch.clamp(y_total[:, j], max=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/sharpe"+str(j): (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item()}, step=step)

        wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_chosen": (torch.sum(chosen_value_total)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_max": (torch.sum(max_total)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_chosen": (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_max": (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/profit_chosen": (torch.sum(torch.clamp(chosen_value_total, min=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/profit_max": (torch.sum(torch.clamp(max_total, min=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/loss_chosen": (-torch.sum(torch.clamp(chosen_value_total, max=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/loss_max": (-torch.sum(torch.clamp(max_total, max=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/sharpe chosen": (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/sharpe max": (torch.mean(max_total)/(1e-20+torch.std(max_total))).item()}, step=step)


        
        
        for j in range(0, args.d_num-1): 
            print(torch.nonzero(y_total[:, j]).size(), y_total[:, j].size())
            tmp = torch.index_select(y_total[:, j], 0, torch.nonzero(y_total[:, j]).squeeze())
            print(tmp.size(), tmp.std())
            print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total[:, j]).item(), (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total[:, j], max=0))).item(), (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item(), torch.std(y_total[:, j]).item())
        tmp = torch.index_select(chosen_value_total, 0, torch.nonzero(chosen_value_total).squeeze())
        print(tmp.size(), tmp.std())
        
        print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total)).item(), (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total, max=0))).item(), (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item(), torch.std(chosen_value_total).item())
        tmp = torch.index_select(max_total, 0, torch.nonzero(max_total).squeeze())
        print(tmp.size(), tmp.std())
        print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total)).item(), (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total, min=0))).item(), (-torch.sum(torch.clamp(max_total, max=0))).item(), (torch.mean(max_total)/(1e-20+torch.std(max_total))).item(), torch.std(max_total).item())
    
    if args.draw:
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(args.start, args.d_num-1):
            if args.lag == 1:
                ax1.plot(lines_lag[0][::interval, j])
            elif args.lag == 2:
                ax1.plot(lines_lag[0][::interval, j]+lines_lag[1][::interval, j])
            else:
                ax1.plot(lines_lag[0][::interval, j]+lines_lag[1][::interval, j]+lines_lag[2][::interval, j])
        if args.lag == 1:
            ax1.plot(line_chosen_lag[0][::interval])
        elif args.lag == 2:
            ax1.plot(line_chosen_lag[0][::interval]+line_chosen_lag[1][::interval])
        else:
            ax1.plot(line_chosen_lag[0][::interval]+line_chosen_lag[1][::interval]+line_chosen_lag[2][::interval])

        plt.legend()
        plt.show()
        plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123"+".png")
        plt.clf()

        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)

        for j in range(args.start, args.d_num-1):
            if args.lag == 1:
                ax1.plot(lines_position_lag[0][j][::interval])
            elif args.lag == 2:
                ax1.plot(lines_position_lag[0][j][::interval]+lines_position_lag[1][j][::interval])
            else:
                ax1.plot(lines_position_lag[0][j][::interval]+lines_position_lag[1][j][::interval]+lines_position_lag[2][j][::interval])
        if args.lag == 1:
            ax1.plot(line_chosen_position_lag[0][::interval])
        elif args.lag == 2:
            ax1.plot(line_chosen_position_lag[0][::interval]+line_chosen_position_lag[1][::interval])
        else:
            ax1.plot(line_chosen_position_lag[0][::interval]+line_chosen_position_lag[1][::interval]+line_chosen_position_lag[2][::interval])
        plt.legend()
        plt.show()
        plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123position"+str(args.pos)+".png")
        plt.clf()

    lag = 123
    for j in range(0, args.d_num-1):
        wandb.log({tag+str(type_)+str(lag)+"/profit-loss"+str(j): torch.sum(y_total_123[:, j]).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/(profit-loss~loss)"+str(j): (torch.sum(y_total_123[:, j])/(-torch.sum(torch.clamp(y_total_123[:, j], max=0))+1e-20)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/profit"+str(j): (torch.sum(torch.clamp(y_total_123[:, j], min=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/loss"+str(j): (-torch.sum(torch.clamp(y_total_123[:, j], max=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/sharpe"+str(j): (torch.mean(y_total_123[:, j])/(1e-20+torch.std(y_total_123[:, j]))).item()}, step=step)

    wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_chosen": (torch.sum(chosen_value_total_123)).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_max": (torch.sum(max_total_123)).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_chosen": (torch.sum(chosen_value_total_123)/(-torch.sum(torch.clamp(chosen_value_total_123, max=0))+1e-20)).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_max": (torch.sum(max_total_123)/(-torch.sum(torch.clamp(max_total_123, max=0))+1e-20)).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/profit_chosen": (torch.sum(torch.clamp(chosen_value_total_123, min=0))).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/profit_max": (torch.sum(torch.clamp(max_total_123, min=0))).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/loss_chosen": (-torch.sum(torch.clamp(chosen_value_total_123, max=0))).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/loss_max": (-torch.sum(torch.clamp(max_total_123, max=0))).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/sharpe chosen": (torch.mean(chosen_value_total_123)/(1e-20+torch.std(chosen_value_total_123))).item()}, step=step)
    wandb.log({tag+str(type_)+str(lag)+"/sharpe max": (torch.mean(max_total_123)/(1e-20+torch.std(max_total_123))).item()}, step=step)


    print("Profit comparison chosen", sum(p_sum))
    wandb.log({tag+str(type_)+str(lag)+"/profit123 chosen": sum(p_sum)}, step=step)

    for j in range(0, args.d_num-1): 
        print("Profit comparison d", j, p_d_sum[j])
        wandb.log({tag+str(type_)+str(lag)+"/profit123"+str(j): p_d_sum[j]}, step=step)



    for j in range(0, args.d_num-1): 
        print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total_123[:, j]).item(), (torch.sum(y_total_123[:, j])/(-torch.sum(torch.clamp(y_total_123[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total_123[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total_123[:, j], max=0))).item(), (torch.mean(y_total_123[:, j])/(1e-20+torch.std(y_total_123[:, j]))).item())
    print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total_123)).item(), (torch.sum(chosen_value_total_123)/(-torch.sum(torch.clamp(chosen_value_total_123, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total_123, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total_123, max=0))).item(), (torch.mean(chosen_value_total_123)/(1e-20+torch.std(chosen_value_total_123))).item())
    print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total_123)).item(), (torch.sum(max_total_123)/(-torch.sum(torch.clamp(max_total_123, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total_123, min=0))).item(), (-torch.sum(torch.clamp(max_total_123, max=0))).item(), (torch.mean(max_total_123)/(1e-20+torch.std(max_total_123))).item())

    return sum(p_sum), lines_position_lag, line_chosen_position_lag

def calculate_test_RLd3(model, rl_profit_path, valid_sellpoint_path, valid_buypoint_path, type_, step, date_list=args.test):
    model.eval()
    with torch.no_grad():
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        if end_month < start_month:
            year = 2023
        else:
            year = 2022
        end = datetime.date(year,end_month,end_day)
        print(start, end)
        y_hat_total = None

        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            print(i, day, month_str, day_str)
            if args.use_p23 == 13:
                xnn = np.load('data_6/xnn6'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x3'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.use_p23 == 12:
                xnn = np.load('data_6/xnn5'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x2'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            else:
                xnn = np.load('data_6/xnn'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            dataset = StockAggregate29(type_, xnn=xnn, x=x)


            y_hat_day_i = torch.zeros(len(dataset), 7).cuda()
            loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False,
                                                    sampler=torch.utils.data.SequentialSampler(dataset),
                                                    batch_size=args.batch_size, num_workers=4, pin_memory=True)
            for _, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
                x, y = x.cuda(), y.cuda()
                y_hat_day_i[index] = model(x).squeeze().detach()
            if i == 0:
                y_hat_total = torch.cat((torch.zeros((args.T-1, 7)).cuda(), y_hat_day_i), dim=0)
            else:
                y_hat_total = torch.cat([y_hat_total, torch.zeros((args.T-1, 7)).cuda(), y_hat_day_i], dim=0)
            del dataset, loader_seq
            print(y_hat_total.size())

    torch.save(y_hat_total, "y_hat_total.pttest"+str(args.rand_number))
    # y_hat_total = torch.load("y_hat_total.pttest"+str(9012919970))
    y_hat_total = y_hat_total.detach().cpu()
    p_sum = calculate_profit(y_hat_total, rl_profit_path, valid_sellpoint_path, valid_buypoint_path,  type_, step, tag="test")
    
    return p_sum

def calculate_test_RL(model, dataset, std_profit, mean_profit, abs_profit, y0, evaluate=True, step=0, type_="test"):
    if evaluate:
        model.eval()
    else:
        model.train()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    losses = logger.AverageMeter("Loss", ":.3f")
    progress = logger.ProgressMeter(len(loader_seq), [losses], prefix=f"Val Epoch: [{epoch}]")
    profit_fix = {i:0 for i in range(7)}
    profit_chosen = 0
    profit_max = 0
    profit_fix_2 = {i:0 for i in range(7)}
    profit_chosen_2 = 0
    profit_max_2 = 0
    profit_fix_3 = {i:0 for i in range(7)}
    profit_chosen_3 = 0
    profit_max_3 = 0
    pure_profit_fix = {i:0 for i in range(7)}
    pure_profit_chosen = 0
    pure_profit_max = 0
    pure_loss_fix = {i:0 for i in range(7)}
    pure_loss_chosen = 0
    pure_loss_max = 0
    chosen_value_total = torch.zeros(len(dataset)).cuda()
    chosen_total = torch.zeros(len(dataset)).cuda()
    max_total =  torch.zeros(len(dataset)).cuda()
    if args.old == 26:
        y0_c = torch.from_numpy(y0[dataset.indices, :]).cuda()
    else:
        y0_c = torch.from_numpy(y0).cuda()
    with torch.no_grad():
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y = y
            y_hat = model(x).squeeze()
            loss = -torch.mean(torch.sum(y_hat*(y), axis=1))
            unnormalized_y = y.clone()
            unnormalized_y = (unnormalized_y*std_profit+mean_profit)*abs_profit
            for j in range(0, 7):
                profit_fix[j] += torch.sum(unnormalized_y[:, j]).item()
            profit_chosen += torch.sum(unnormalized_y.gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1))).item()
            profit_max += torch.sum(torch.max(unnormalized_y, dim=1)[0]).item()

            for j in range(0, 7):
                profit_fix_2[j] += torch.sum(unnormalized_y[:, j]/vari[0, j]).item()
            profit_chosen_2 += torch.sum((unnormalized_y/vari).gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1))).item()
            profit_max_2 += torch.sum(torch.max((unnormalized_y/vari), dim=1)[0]).item()

            for j in range(0, 7):
                profit_div = torch.sum(torch.clamp(unnormalized_y[:, j], min=0))
                loss_div = -torch.sum(torch.clamp(unnormalized_y[:, j], max=0))
                pure_profit_fix[j] += profit_div.item()
                pure_loss_fix[j] += loss_div.item()
            chosen = (unnormalized_y).gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1))
            chosen_value_total[index] = chosen.squeeze()
            profit_div = torch.sum(torch.clamp(chosen, min=0))
            loss_div = -torch.sum(torch.clamp(chosen, max=0))
            # print("why so large", loss_div, torch.sum(chosen))
            # print("why so large", loss_div, torch.sum(chosen), profit_chosen_3)
            pure_profit_chosen += profit_div.item()
            pure_loss_chosen += loss_div.item()
            profit_div = torch.sum(torch.clamp(torch.max((unnormalized_y), dim=1)[0], min=0))
            loss_div = -torch.sum(torch.clamp(torch.max((unnormalized_y), dim=1)[0], max=0))
            pure_profit_max += profit_div.item()
            pure_loss_max += loss_div.item()
            chosen_total[index] = torch.argmax(y_hat, axis=1).float()
            max_total[index] = torch.argmax(y, axis=1).float()
            if i % 300 == 0:
                progress.display(i)
        profit_chosen_3 += (profit_chosen/pure_loss_chosen)
        profit_max_3 += (profit_max/(pure_loss_max+1e-20))
        for j in range(0, 7):
            profit_fix_3[j] += (profit_fix[j]/(pure_loss_fix[j]+1e-20))
        
            # for j in range(0, 7):
                # profit_fix_2[j] += torch.sum(y[:, j]).item()
            # profit_chosen_2 += torch.sum(y.gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1))).item()
            # profit_max_2 += torch.sum(torch.max(y, dim=1)[0]).item()
            # print(arr[20000000:])
            # if type_ == "test":
            #     y3 = torch.from_numpy(y0[arr[11000000:][index]]).cuda()
            # elif type_ == "train":
            #     y3 = torch.from_numpy(y0[arr[:11000000][index]]).cuda()
            # else:
            #     y3 = torch.from_numpy(y0[index]).cuda()
            # for j in range(0, 7):
            #     profit_fix_3[j] += torch.sum(y3[:, j]).item()
            # profit_chosen_3 += torch.sum(y3.gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1))).item()
            # profit_max_3 += torch.sum(torch.max(y3, dim=1)[0]).item()
            # losses.update(loss.item(), x.size(0))
        for j in range(0, 7):
            print("sharpe", torch.mean(y0_c[:, j]), torch.std(y0_c[:, j]), torch.mean(y0_c[:, j])/torch.std(y0_c[:, j]))
        print("sharpe max", torch.mean(torch.max((y0_c), dim=1)[0]), torch.std(torch.max((y0_c), dim=1)[0]), torch.mean(torch.max((y0_c), dim=1)[0])/torch.std(torch.max((y0_c), dim=1)[0]))
        print("sharpe chosen", torch.mean(chosen_value_total), torch.std(chosen_value_total), torch.mean(chosen_value_total)/torch.std(chosen_value_total))

        
        print(torch.sum(chosen_total == 0)/chosen_total.size(0))
        print(torch.sum(chosen_total == 1)/chosen_total.size(0))
        print(torch.sum(chosen_total == 2)/chosen_total.size(0))
        print(torch.sum(chosen_total == 3)/chosen_total.size(0))
        print(torch.sum(chosen_total == 4)/chosen_total.size(0))
        print(torch.sum(chosen_total == 5)/chosen_total.size(0))
        print("acc", torch.sum(chosen_total==max_total)/chosen_total.size(0))

        # plt.savefig("result"+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+"RLcompare.png")
        progress.display(len(loader_seq))
        wandb.log({f"test/loss": losses.avg}, step=step)
        for j in range(0, 7):
            wandb.log({type_+"/profit_fix_"+str(j): profit_fix[j]}, step=step)
            wandb.log({type_+"/profit_fix_3_"+str(j): profit_fix_3[j]}, step=step)
            wandb.log({type_+"/pure_profit_fix_"+str(j): pure_profit_fix[j]}, step=step)
            wandb.log({type_+"/pure_loss_fix_"+str(j): pure_loss_fix[j]}, step=step)
            wandb.log({type_+"/sharpe_fix_"+str(j): torch.mean(y0_c[:, j])/torch.std(y0_c[:, j])}, step=step)

        wandb.log({type_+"/profit_chosen": profit_chosen}, step=step)
        wandb.log({type_+"/profit_max": profit_max}, step=step)
        wandb.log({type_+"/profit_chosen_3": profit_chosen_3}, step=step)
        wandb.log({type_+"/profit_max_3": profit_max_3}, step=step)
        wandb.log({type_+"/pure_profit_chosen": pure_profit_chosen}, step=step)
        wandb.log({type_+"/pure_profit_max": pure_profit_max}, step=step)
        wandb.log({type_+"/pure_loss_chosen": pure_loss_chosen}, step=step)
        wandb.log({type_+"/pure_loss_max": pure_loss_max}, step=step)
        wandb.log({type_+"/sharpe_max": torch.mean(torch.max((y0_c), dim=1)[0])/torch.std(torch.max((y0_c), dim=1)[0])}, step=step)
        wandb.log({type_+"/sharpe_chosen": torch.mean(chosen_value_total)/torch.std(chosen_value_total)}, step=step)

    
    for j in range(0, 7): 
        print("d=", j, "profit_fix[j], profit_fix_3[j], pure_profit_fix[j], pure_loss_fix[j]", profit_fix[j], profit_fix_3[j], pure_profit_fix[j], pure_loss_fix[j])
    print("pure_profit_chosen, pure_loss_chosen, pure_profit_max, pure_loss_max", pure_profit_chosen, pure_loss_chosen, pure_profit_max, pure_loss_max)
    print("profit_chosen, profit_max, profit_chosen_3, profit_max_3", profit_chosen, profit_max, profit_chosen_3, profit_max_3)
    a, b = torch.mean(chosen_value_total).item(), torch.std(chosen_value_total).item()

    del chosen_value_total, chosen_total, max_total
    if args.div_loss:
        return losses.avg, profit_chosen, profit_chosen_3
    elif args.sharpe:
        return losses.avg, profit_chosen, a/b
    else:
        return losses.avg, profit_chosen, a/b

def softmax1d(input, beta=100):
    *_, n = input.shape
    result = nn.functional.softmax(beta * input, dim=-1)
    # indices = torch.linspace(0, 1, n).cuda()
    # result = torch.sum((n - 1) * input * indices, dim=-1)
    return result

def train_pg(model, criterion, loader, opt, epoch, dataset):
    global max_r2, max_r2_itr, min_l, min_l_itr, max_test2_r2_itr, max_test2_r2, corr_test2_r2, max_p, max_p_itr, corr_p
    model.train()
    losses = logger.AverageMeter("Loss", ":.3f")
    corres = logger.AverageMeter("Corr", ":.3f")
    r2es = logger.AverageMeter("R2", ":.3f")
    top1 = logger.AverageMeter("Acc@1", ":6.2f")
    top2 = logger.AverageMeter("Acc@2", ":6.2f")
    l = [losses, corres, r2es, top1, top2]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Train Epoch: [{epoch}]")
    updates = 0
    
    while (updates < 100):
        y_hat_total = torch.zeros(len(dataset), 7).cuda()
        y_total = torch.zeros(len(dataset), 7).cuda()
        loss_grad_total = torch.zeros(len(dataset), args.K).cuda()
        print(updates)
        updates += 1
        opt.zero_grad()
        with torch.no_grad():
            for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
                model.train()
                x, y = x.cuda(), y.cuda()
                y_hat = model(x).squeeze()
                y_hat_total[index] = y_hat
                y_total[index] = y
            # print(y_hat_total.size(), y_total.size())
            sampled_actions = torch.multinomial(y_hat_total.cpu(), args.K, replacement=True) # (len(dataset), 10)
            onehot_sampled_actions = F.one_hot(sampled_actions, num_classes=7).float().cuda() # (len(dataset), 10, 7)
            profit = torch.bmm(onehot_sampled_actions, y_total.unsqueeze(-1)).squeeze() # (len(dataset), 10, 7), (len(dataset), 7, 1), (len(dataset), 10, 1)  
            loss_constant = torch.mean(profit, axis=0)/(torch.std(profit, axis=0)+1e-20) # (1, 10)
            mean_constant = torch.mean(loss_constant) # (1, 1)
        print(torch.sum(profit, axis=0))        
        print(sampled_actions, onehot_sampled_actions, profit, loss_constant, mean_constant)
        # print(sampled_actions.size(), onehot_sampled_actions.size(), profit.size(), loss_constant.size(), mean_constant.size())

        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
            model.train()
            x, y = x.cuda(), y.cuda()
            y_hat = model(x).squeeze()
            onehot_sampled_actions_batch = onehot_sampled_actions[index]
            loss_grad = torch.bmm(onehot_sampled_actions_batch, y_hat.unsqueeze(-1)).squeeze() # (2048, 10, 7), (2048, 7, 1), (2048, 10, 1)  
            print(loss_grad)
            loss_grad_total[index] = torch.log(loss_grad + 1e-20)
            loss_grad = torch.sum(torch.log(loss_grad + 1e-20), axis=0) #(1, 10)
            print(loss_grad)
            loss = -torch.mean((loss_constant)*loss_grad) #(1)
            print(loss, "why not zero")
            loss.backward()
            losses.update(loss.item(), x.size(0))
            # print(loss.item())
        print("what is loss avg, loss grad", losses.avg, torch.sum(loss_grad_total, axis=0))
        torch.nn.utils.clip_grad_norm_(model.parameters(), 3)
        opt.step()
        del x, y, y_hat, sampled_actions, onehot_sampled_actions, onehot_sampled_actions_batch, profit, loss_constant, mean_constant, loss, y_hat_total, y_total,  loss_grad_total


        if updates % 10 == 0 and i != 0:
            l, p, p_ = calculate_test_RL(model, test_dataset, step=epoch*len(loader)+i, type_="test", std_profit=std_profit, mean_profit=mean_profit, abs_profit=abs_profit, y0=y0)
            l2, p2, p2_ = calculate_test_RL(model, train_dataset, step=epoch*len(loader)+i, type_="train2", std_profit=std_profit, mean_profit=mean_profit, abs_profit=abs_profit, y0=y0)
            if p_ > max_p:
                max_p = p_
                corr_p = p
                max_p_itr = epoch*len(loader)+i
                torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
            print("max_p_itr, max_p, corr_p, rand_number", max_p_itr, max_p, corr_p, args.rand_number)
    return 0, 0, 0

def train(model, criterion, loader, opt, epoch, g = None):
    global max_r2, max_r2_itr, min_l, min_l_itr, max_test2_r2_itr, max_test2_r2, corr_test2_r2, max_p, max_p_itr, corr_p
    model.train()
    losses = logger.AverageMeter("Loss", ":.3f")
    corres = logger.AverageMeter("Corr", ":.3f")
    r2es = logger.AverageMeter("R2", ":.3f")
    top1 = logger.AverageMeter("Acc@1", ":6.2f")
    top2 = logger.AverageMeter("Acc@2", ":6.2f")
    l = [losses, corres, r2es, top1, top2]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Train Epoch: [{epoch}]")
    if "RL" in args.arch:
        # x_start, y_start = None, None
        profit_fix = {i:0 for i in range(args.d_num)}
        profit_chosen = 0
        profit_max = 0
        profit_fix_2 = {i:0 for i in range(args.d_num)}
        profit_chosen_2 = 0
        profit_max_2 = 0
        profit_fix_3 = {i:0 for i in range(args.d_num)}
        profit_chosen_3 = 0
        profit_max_3 = 0

    for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
        model.train()
        args.eval = False
        x, y, mask = x.cuda(), y.cuda(), mask.cuda()
        if "Classification" in args.arch:
            y = y.long()
        if "Pretrained" in args.arch:
            mask = mask.cuda()
            y_true = x*(~mask)
            x = x*mask
        if opt:
            opt.zero_grad()
        y_hat = model(x).squeeze()

        if "Pretrained" in args.arch:
            loss = criterion(y_hat*(~mask), y_true)
        elif "Classification" in args.arch or "regressor" in args.arch:
            loss = criterion(y_hat, y)
        elif "RL" in args.arch:
            if args.old == 32 or args.old == 33 or args.old == 41:
                if args.gumbel:
                    loss = 0

                    y = y.unsqueeze(-1)
                    # print(y.size())
                    tmp = torch.sum(y_hat*(y), axis=1)
                    max_tmp1 = torch.max(y[:, :args.d_num], axis=1)[0]
                    max_tmp2 = torch.max(y[:, args.d_num:], axis=1)[0]
                    max_tmp = max_tmp1 + max_tmp2
                    indices_max = (max_tmp != 2*y[0, args.d_num-1])
                    # print("std of maxtmp", (torch.sum(max_tmp[indices_max], axis=0)/(torch.std(max_tmp[indices_max], axis=0) + 1e-20)).item(), torch.sum(max_tmp[indices_max], axis=0).item(), (torch.std(max_tmp[indices_max], axis=0) + 1e-20).item())
                    max_tmpstd = torch.std(max_tmp[indices_max], axis=0).item()
                    # print(y.size(), tmp.size())
                    avg_std = 0
                    avg_sum = 0
                    if args.consider_nonzero:
                        for p in range(args.K):
                            tmptmp = tmp[:, p]
                            # print(tmptmp.size())
                            indices = (tmptmp != 2*y[0, args.d_num-1])
                            # print(indices.size(), torch.sum(indices), 2*y[0, 6])
                            # if torch.mean(tmptmp[indices], axis=0) < 0:
                            #     loss += -torch.mean(tmptmp[indices], axis=0)
                            # else:
                            #     loss += -(torch.log(torch.mean(tmptmp[indices], axis=0))-torch.log(torch.std(tmptmp[indices], axis=0) + 1e-20))
                            # # print(tmptmp[indices])
                            # print("what is std", torch.std(tmptmp[indices], axis=0))
                            stdtmp = torch.std(tmptmp[indices], axis=0)
                            sumtmp = torch.sum(tmptmp, axis=0)
                            # print("why so diff 2", torch.sum(tmptmp), sumtmp)
                            if sumtmp < 0:
                                loss += -(sumtmp)/(torch.clamp(stdtmp.data, min=max_tmpstd)+1e-20)
                            else:
                                loss += -(sumtmp)/(torch.clamp(stdtmp, min=max_tmpstd)+1e-20)
                            # print("what is std", torch.std(tmptmp[indices], axis=0))
                            avg_std += stdtmp.item()
                            avg_sum += sumtmp.item()
                        loss = loss/args.K
                        # print(-loss.item(), avg_sum/args.K, avg_std/args.K, args.rand_number)
                        profit_chosen_3 += avg_sum/args.K
                        profit_max_3 += torch.sum(max_tmp)
                        profit_chosen_2 += torch.sum(tmp)/args.K
                        # print("whsy so diff", profit_chosen_3, profit_max_3, profit_chosen_2)
                    # pos_loc = tmp>0
                    # std = torch.std(tmp, axis=0)
                    # tmp[pos_loc] = tmp[pos_loc]/std
                    else:
                        loss = -torch.mean(torch.mean(tmp, axis=0)/(torch.std(tmp, axis=0) + 1e-20))
                    # print(y.size(), tmp.size(), torch.mean(tmp, axis=0).size(), torch.std(tmp, axis=0).size(), loss.size())
                else:
                    if args.consider_pos:
                        if args.gumbel:
                            tmp = torch.sum(y_hat*(y), axis=1)
                            tmp_mask = (tmp != 2*y[0, args.d_num-1])
                            pos_loc = tmp>2*y[0, args.d_num-1]
                            neg_loc = tmp<2*y[0, args.d_num-1] 
                            std = torch.std(tmp*tmp_mask, axis=0)
                            loss = -torch.mean((torch.sum(tmp[pos_loc]/std, axis=0) + torch.sum(tmp[neg_loc], axis=0))/args.batch_size)

                        else:
                            tmp = torch.sum(y_hat*(y), axis=1)
                            pos_loc = tmp>2*y[0, args.d_num-1]
                            neg_loc = tmp<=2*y[0, args.d_num-1] 
                            std = torch.std(tmp, axis=0)
                            if torch.mean(tmp) <3*y[0, args.d_num-1]:
                                loss = -torch.mean(tmp)
                            else:
                                loss = -torch.mean(tmp)/(torch.std(tmp, axis=0) + 1e-20)
                            # loss = -(torch.sum(tmp[pos_loc]/std) + torch.sum(tmp[neg_loc]))/args.batch_size
                    else:
                        tmp = torch.sum(y_hat*(y), axis=1)

                        if args.sharpe:
                            # if torch.mean(tmp) <= 0:
                            #     loss = -torch.mean(tmp)
                            # else:
                            print(loss)
                            loss = -(torch.mean(tmp))/(torch.std(tmp) + 1e-20)
                        else:
                            loss = -torch.mean(tmp)
                
            else:
                if args.div_var:
                    loss = -torch.mean(torch.sum(y_hat*(y)/vari, axis=1))
                else:
                    loss = -torch.mean(torch.sum(y_hat*(y), axis=1))
                if args.nonzero_penalty:
                    # print("yhat", y_hat)
                    tmp = args.gamma*torch.mean(torch.sum((y!=0)*y_hat, axis=1))
                    # print("values", loss.item(), tmp.item())
                    if epoch > 10:
                        loss += tmp
                if args.div_loss:
                    profit_div = torch.mean(torch.clamp(y_hat*y, min=y[0, -1]))
                    loss_div = -torch.mean(torch.clamp(y_hat*y, max=y[0, -1])) + 1e-20
                    print(profit_div, loss_div, loss)
                    loss = loss/loss_div
                if args.sharpe:
                    if args.hard_var:
                        # var_profit = torch.std(torch.sum(y*softmax1d(y_hat), axis=1)) + 1e-20
                        tmp0 = torch.sum(y_hat*(y), axis=1)
                        tmp = tmp0[tmp0<0]
                        print(torch.sum(tmp0<0), torch.sum(tmp0>0), tmp0.size(), torch.sum(tmp), torch.sum(tmp0[tmp0 > 0]))
                        var_profit = torch.std(tmp) + 1e-20
                    else:
                        var_profit = torch.std(torch.sum(y_hat*(y), axis=1)) + 1e-20
                    print("what is var_profit", torch.std(torch.max(y, axis=1)[0]), var_profit.item(), loss.item(), (loss/var_profit).item(), loss/torch.clamp(var_profit, min=args.bound).item(), y_hat.size(), 0.003*torch.mean(y_hat[:, -1]))
                    # loss = loss/(torch.clamp(var_profit, min=args.bound)**args.gamma) + args.gamma*torch.mean(y_hat[:, -1])
                    if loss.item() > 0:
                        loss = loss
                    else:
                        loss = loss/(1+torch.clamp(var_profit, min=args.bound)**args.gamma)
                if args.sharpe_pg:
                    sampled_actions = torch.multinomial(y_hat, args.K, replacement=True) # (2048, 10)
                    # print("sampled_actions", sampled_actions, sampled_actions.size())
                    onehot_sampled_actions = F.one_hot(sampled_actions, num_classes=7).float() # (2048, 10, 7)
                    # print("onehot_sampled_actions", onehot_sampled_actions, onehot_sampled_actions.size())
                    # profit = y.index_select(sampled_actions)# (2048, 10)
                    profit = torch.bmm(onehot_sampled_actions, y.unsqueeze(-1)).squeeze() # (2048, 10, 7), (2048, 7, 1), (2048, 10, 1)  
                    # print("profit", profit, profit.size())
                    loss_constant = torch.zeros((1, 10)).cuda()
                    for j in range(args.K):
                        loss_constant[0, j] = profit[:, j].sum()/torch.std(torch.index_select(profit[:, j], 0, torch.nonzero(profit[:, j]).squeeze()))
                    # loss_constant = torch.sum(profit, axis=0)/torch.std(profit, axis=0) # (1, 10)
                    # print("loss_constant", loss_constant, loss_constant.size())
                    mean_constant = torch.mean(loss_constant) # (1, 1)
                    # print("mean_constant", mean_constant, mean_constant.size())
                    loss_grad = torch.bmm(onehot_sampled_actions, y_hat.unsqueeze(-1)).squeeze() # (2048, 10, 7), (2048, 7, 1), (2048, 10, 1)  
                    # print("loss_grad", loss_grad, loss_grad.size())
                    # loss_grad = y_hat.index_select(sampled_actions)#(2048, 10)
                    loss_grad = torch.sum(torch.log(loss_grad + 1e-20), axis=0) #(1, 10)
                    # print("loss_grad", loss_grad, loss_grad.size())
                    # print("(loss_constant-mean_constant)", (loss_constant-mean_constant), (loss_constant-mean_constant).size())
                    # print("unmean", (loss_constant-mean_constant)*loss_grad, ((loss_constant-mean_constant)*loss_grad).size())
                    loss = -torch.mean((loss_constant)*loss_grad) #(1)
                    # print("loss", loss, loss.size())
        if "Classification" in args.arch:
            acc1, acc2 = accuracy(y_hat, y, topk=(1, 2))
            top1.update(acc1.item(), x.size(0))
            top2.update(acc2.item(), x.size(0))
        if "Pretrained" in args.arch or "RL" in args.arch:
            losses.update(loss.item(), x.size(0))
        # if "RL" in args.arch:
        #     for j in range(0, 7):
        #         profit_fix_2[j] += torch.sum(y[:, j]).item()
        #     profit_chosen_2 += np.sum(y.detach().cpu().numpy()[np.arange(y.size(0)), torch.argmax(y_hat, axis=1).detach().cpu().numpy()])
        #     profit_max_2 += torch.sum(torch.max(y, dim=1)[0]).item()
            # y3 = torch.from_numpy(y0[index]).cuda()
            # for j in range(0, 7):
            #     profit_fix_3[j] += torch.sum(y3[:, j]).item()
            # profit_chosen_3 +=  np.sum(y3.detach().cpu().numpy()[np.arange(y3.size(0)), torch.argmax(y_hat, axis=1).detach().cpu().numpy()])
            # profit_max_3 += torch.sum(torch.max(y3, dim=1)[0]).item()

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 3)
        if opt:
            opt.step()
        if "Pretrained" in args.arch or "Class" in args.arch or "RL" in args.arch:
            if i % 200 == 0:
                progress.display(i) 
        
        if args.old != 29 and i % args.test_interval == 0 and i != 0:
            if "RL" in args.arch:
                # for j in range(0, 7):
                #     wandb.log({f"test/profit_fix_"+str(j): profit_fix_3[j]}, step=epoch*len(loader)+i)
                # wandb.log({f"train/loss": losses.avg}, step=epoch*len(loader)+i)
                # wandb.log({f"train/profit_chosen": profit_chosen_3}, step=epoch*len(loader)+i)
                # wandb.log({f"train/profit_max": profit_max_3}, step=epoch*len(loader)+i)
                # print("profit comparison,", profit_fix_2, profit_chosen_2, profit_max_2,  profit_fix_3, profit_chosen_3, profit_max_3)
                # profit_fix = {}
                # profit_chosen = 0
                # profit_max = 0
                # profit_fix_4_2 = {}
                # profit_chosen_2 = 0
                # profit_max_2 = 0
                # profit_fix_4_3 = {}
                # profit_chosen_3 = 0
                # profit_max_3 = 0
                pass
            if "Pretrained" in args.arch:
                l = calculate_test_pretrained(model, test_dataset, step=epoch*len(loader)+i)
                wandb.log({f"train/loss": losses.avg}, step=epoch*len(loader)+i)
                print(args.rand_number)
                if l < min_l:
                    min_l = l
                    min_l_itr = epoch*len(loader)+i
                    torch.save(model, "results/best_model_pretrained"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                print("min_loss_itr, min_l", min_l_itr, min_l, args.rand_number)
            elif "Classification" in args.arch:
                calculate_test_classification(model, test_dataset, step=epoch*len(loader)+i)
                calculate_test_classification(model, train_dataset, step=epoch*len(loader)+i)
                wandb.log({f"train/loss": losses.avg}, step=epoch*len(loader)+i)
                wandb.log({f"train/top1": top1.avg}, step=epoch*len(loader)+i)
                wandb.log({f"train/top2": top2.avg}, step=epoch*len(loader)+i)
                print(args.rand_number)
                torch.save(model, "results/best_model_class"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")

            elif "regressor" in args.arch:
                if args.old == 27:
                    l, c, r = calculate_real_stats_test27(model, step=epoch*len(loader)+i, date_list=args.test[0], type_="test")
                    l2, c2, r2 = calculate_real_stats_test27(model, step=epoch*len(loader)+i, date_list=args.test2[0],  type_="test2")
                    if r > max_r2:
                        max_r2_itr = epoch*len(loader)+i
                        max_r2 = r
                        corr_test2_r2 = r2
                        print("new_best!!!")
                        torch.save(model, "results/best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")
                    if r2 > max_test2_r2:
                        max_test2_r2_itr = epoch*len(loader)+i
                        max_test2_r2 = r2
                        torch.save(model, "results/best_model_y_test2_"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")

                    print("max_r2_itr, max_r2, corr_test2_r2", max_r2_itr, max_r2, corr_test2_r2, max_test2_r2_itr, max_test2_r2, args.rand_number)
                    print("max_test2_r2_itr, max_test2_r2", max_test2_r2_itr, max_test2_r2, args.rand_number)
                elif args.old == 18:
                    l, c, r = calculate_real_stats_test18(model, step=epoch*len(loader)+i, date_list=args.test[0], type_="test")
                    l2, c2, r2 = calculate_real_stats_test18(model, step=epoch*len(loader)+i, date_list=args.test2[0],  type_="test2")
                    if r > max_r2:
                        max_r2_itr = epoch*len(loader)+i
                        max_r2 = r
                        corr_test2_r2 = r2
                        print("new_best!!!")
                        torch.save(model, "results/best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")
                    if r2 > max_test2_r2:
                        max_test2_r2_itr = epoch*len(loader)+i
                        max_test2_r2 = r2
                        torch.save(model, "results/best_model_y_test2_"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")

                    print("max_r2_itr, max_r2, corr_test2_r2", max_r2_itr, max_r2, corr_test2_r2, max_test2_r2_itr, max_test2_r2, args.rand_number)
                    print("max_test2_r2_itr, max_test2_r2", max_test2_r2_itr, max_test2_r2, args.rand_number)
                elif args.old ==19:
                    l, c, r = calculate_real_stats_test(model, test_dataset, y_length_list, step=epoch*len(loader)+i, type_="test")
                    # l2, c2, r2 = calculate_real_stats_test(model, test_dataset_2, y_length_list_2, step=epoch*len(loader)+i, type_="test2")
                    l2, c2, r2 = calculate_real_stats_test18(model, step=epoch*len(loader)+i, date_list=args.test2[0],  type_="test2")

                    if r > max_r2:
                        max_r2_itr = epoch*len(loader)+i
                        max_r2 = r
                        corr_test2_r2 = r2
                        print("new_best!!!")
                        torch.save(model, "results/best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")
                    if r2 > max_test2_r2:
                        max_test2_r2_itr = epoch*len(loader)+i
                        max_test2_r2 = r2
                        torch.save(model, "results/best_model_y_test2_"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")

                    print("max_r2_itr, max_r2, corr_test2_r2", max_r2_itr, max_r2, corr_test2_r2, max_test2_r2_itr, max_test2_r2, args.rand_number)
                    print("max_test2_r2_itr, max_test2_r2", max_test2_r2_itr, max_test2_r2, args.rand_number)
                elif args.old != 12:
                    l, c, r = calculate_real_stats_test(model, test_dataset, y_length_list, step=epoch*len(loader)+i, type_="test")
                    l2, c2, r2 = calculate_real_stats_test(model, test_dataset_2, y_length_list_2, step=epoch*len(loader)+i, type_="test2")
                    if r > max_r2:
                        max_r2_itr = epoch*len(loader)+i
                        max_r2 = r
                        corr_test2_r2 = r2
                        print("new_best!!!")
                        torch.save(model, "results/best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")
                    if r2 > max_test2_r2:
                        max_test2_r2_itr = epoch*len(loader)+i
                        max_test2_r2 = r2
                        torch.save(model, "results/best_model_y_test2_"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+"_"+';'.join(args.test2)+args.rand_number+".pt")

                    print("max_r2_itr, max_r2, corr_test2_r2", max_r2_itr, max_r2, corr_test2_r2, max_test2_r2_itr, max_test2_r2, args.rand_number)
                    print("max_test2_r2_itr, max_test2_r2", max_test2_r2_itr, max_test2_r2, args.rand_number)
            elif "RL" in args.arch:
                if args.old == 29:
                    p_ = calculate_test_RLd3(model, args.rl_profit_path2, type_=args.type, step=epoch*len(loader)+i, date_list=args.test[0])
                    p2_ = calculate_train_RLd3(model, train_dataset, args.rl_profit_path, args.valid_sellpoint2, args.valid_buypoint2, type_=args.type, step=epoch*len(loader)+i)
                    if p_ > max_p:
                        max_p = p_
                        max_p_itr = epoch*len(loader)+i
                        torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
                elif args.old == 30:
                    p2_ = calculate_train_RLd3(model, train_dataset, args.rl_profit_path, args.valid_sellpoint, args.valid_buypoint, type_=args.type, step=epoch*len(loader)+i, tag="train")
                    p_ = calculate_train_RLd3(model, test_dataset, args.rl_profit_path2, args.valid_sellpoint2, args.valid_buypoint2, type_=args.type, step=epoch*len(loader)+i, tag="test")
                    if p_ > max_p:
                        max_p = p_
                        max_p_itr = epoch*len(loader)+i
                        torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
                elif args.old == 31:
                    p2_ = calculate_train_RLd3(model, train_dataset, args.rl_profit_path, args.valid_sellpoint, args.valid_buypoint, type_=args.type, step=epoch*len(loader)+i, tag="train")
                    p_ = calculate_train_RLd3(model, test_dataset, args.rl_profit_path2, args.valid_sellpoint2, args.valid_buypoint2, type_=args.type, step=epoch*len(loader)+i, tag="test")
                    if p_ > max_p:
                        max_p = p_
                        max_p_itr = epoch*len(loader)+i
                        torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
                elif args.old == 32 or args.old == 33 or args.old ==41:
                    temp_K = args.K
                    args.K = 1
                    p_ = 0
                    if (epoch+1) % args.eval_per_epoch == 0:
                        # p2_ = calculate_train_RLd3_32(model, train_dataset, args.rlbuy_profit_path, args.rlsell_profit_path, args.valid_2ndsellpoint, args.valid_2ndbuypoint, step=epoch*len(loader)+i, tag="train")
                        p_ = calculate_train_RLd3_32(model, test_dataset, args.rlbuy_profit_path2, args.rlsell_profit_path2, args.valid_2ndsellpoint2, args.valid_2ndbuypoint2, step=epoch*len(loader)+i, tag="test")
                    args.K = temp_K
                    if p_ >= max_p:
                        max_p = p_
                        max_p_itr = epoch*len(loader)+i
                        torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    torch.save(model, "results/last_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
                elif args.old != 29 and args.old !=30 and args.old != 31:
                    
                    l, p, p_ = calculate_test_RL(model, test_dataset, step=epoch*len(loader)+i, type_="test", std_profit=std_profit, mean_profit=mean_profit, abs_profit=abs_profit, y0=y0)
                    l2, p2, p2_ = calculate_test_RL(model, train_dataset, step=epoch*len(loader)+i, type_="train2", std_profit=std_profit, mean_profit=mean_profit, abs_profit=abs_profit, y0=y0)
                    
                    if p_ > max_p:
                        max_p = p_
                        corr_p = p
                        max_p_itr = epoch*len(loader)+i
                        torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    torch.save(model, "results/last_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    print("max_p_itr, max_p, corr_p, rand_number", max_p_itr, max_p, corr_p, args.rand_number)
                
    # if args.old == 29:
    #     if epoch % 5 == 0:
    #         p_ = calculate_test_RLd3(model, args.rl_profit_path2, args.valid_sellpoint2, args.valid_buypoint2, type_=args.type, step=epoch*len(loader)+i, date_list=args.test[0])
    #         p2_ = calculate_train_RLd3(model, train_dataset, args.rl_profit_path, args.valid_sellpoint, args.valid_buypoint, type_=args.type, step=epoch*len(loader)+i)
    #         if p_ > max_p:
    #             max_p = p_
    #             max_p_itr = epoch*len(loader)+i
    #             torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    #         print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
    # if args.old == 30:
    #     if epoch % 1 == 0:
    #         p2_ = calculate_train_RLd3(model, train_dataset, args.rl_profit_path, args.valid_sellpoint, args.valid_buypoint, type_=args.type, step=epoch*len(loader)+i)
    #         p_ = calculate_train_RLd3(model, test_dataset, args.rl_profit_path2, args.valid_sellpoint2, args.valid_buypoint2, type_=args.type, step=epoch*len(loader)+i)
    #         if p_ > max_p:
    #             max_p = p_
    #             max_p_itr = epoch*len(loader)+i
    #             torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    #         print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
    return 0, 0, 0

def validate(model, criterion, loader, epoch):
    model.eval()
    losses = logger.AverageMeter("Loss", ":.3f")
    corres = logger.AverageMeter("Corr", ":.3f")
    r2es = logger.AverageMeter("R2", ":.3f")
    l = [losses, corres, r2es]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Epoch: [{epoch}]")
    with torch.no_grad():
        for i, (x, y, _) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
            x, y = x.cuda(), y.cuda()
            y_hat = model(x).squeeze()
            loss = criterion(y_hat, y)
            corr = abs(np.corrcoef(torch.cat((y.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            losses.update(loss.item(), x.size(0))
            corres.update(corr.item(), x.size(0))
            r2 = 1 - ((y - y_hat) ** 2).sum() / ((y - y.mean()) ** 2).sum()
            r2es.update(r2.item(), x.size(0))
            if i % 700 == 0:
                progress.display(i)
        progress.display(len(loader))
    return losses.avg, corres.avg, r2es.avg

@torch.no_grad()
def run_inference(model: nn.Module,
                  input_tensor: torch.Tensor) -> torch.Tensor:

    return model.forward(input_tensor)

def test_time(model):
    # model = torch.quantization.quantize_dynamic(
    #     model, {nn.Conv1d, nn.LeakyReLU, nn.BatchNorm1d, nn.MaxPool1d, nn.LSTM, nn.Linear}, dtype=torch.qint8
    # )

    
    num_threads = 1
    num_warmups = 100
    num_repeats = 1000
    
    model.eval()
    input = torch.randn(1, 57, args.T).cuda()
    timer = benchmark.Timer(stmt="run_inference(model, input_tensor)",
                            setup="from __main__ import run_inference",
                            globals={
                                "model": model,
                                "input_tensor": input
                            },
                            num_threads=num_threads,
                            label="Latency Measurement",
                            sub_label="torch.utils.benchmark.")

    profile_result = timer.timeit(num_repeats)
    # https://pytorch.org/docs/stable/_modules/torch/utils/benchmark/utils/common.html#Measurement
    print(f"Latency: {profile_result.mean * 1000:.5f} ms")


    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    repetitions = 300
    for _ in range(10):
        y = model(input)
    starter.record()
    for rep in range(repetitions):
        y = model(input)
    ender.record()
    torch.cuda.synchronize()
    curr_time = starter.elapsed_time(ender)
    print(curr_time/repetitions)

def export_model(model):
    model.eval()
    input = torch.ones(1, 57, args.T).cuda()
    traced_script_module = torch.jit.trace(model, input)
    # traced_script_module = torch.jit.script(model)
    print(model(input))
    traced_script_module.save("trans0.pt")

from numba import jit

# @jit
# def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1):
#     # print(valid_sellpoint)
#     chosen_vt = chosen_value_total
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     # profit_positions = [0 for i in range(len(valid_sellpoint))]
#     # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

#     valid_buypoint = (chosen_vt != 0).nonzero()[0]
#     # for i in range(len(chosen_vt)):
#         # print(chosen_vt[i])
#     profit_position = np.zeros(len(chosen_vt))
#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb <= valid_sellpoint[i] + lag - 1:
#                 return i, True

#     total_profit = 0
#     # print(len(valid_buypoint))
#     for vb in valid_buypoint:
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += chosen_vt[vb]
#                     profit_position[vb] = chosen_vt[vb]
#                     positions_dict[bin] += 1
#             else:
#                 if positions_dict[bin] < position:
#                     total_profit += chosen_vt[vb]
#                     profit_position[vb] = chosen_vt[vb]
#                     positions_dict[bin+1] += 1
#                     positions_dict[bin] += 1
#                 # profit_positions[get_loc(vb)] += chosen_vt[vb]
#                 # addedvb_positions[get_loc(vb)].append([vb,chosen_vt[vb]])
#         else:
#             print(vb, valid_sellpoint[-1], valid_sellpoint)
#             print("why larger")
#     # for i in range(len(positions_dict)):
#         # print(positions_dict[i], profit_positions[i], addedvb_positions[i])
#     return total_profit, profit_position    

@jit
def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True
    trades_num = 0
    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]

                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)
                    trades_num += 1
            else:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]

                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    trades_num += 1
                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    print("nonempty buypoints, actual trades", len(valid_buypoint), trades_num)
    return total_profit, profit_position, positions_dict  
 

# @jit
# def calculate_profit_with_position(y0, valid_sellpoint, d=4, position=5, lag=1):
#     # print(valid_sellpoint)

#     profit = y0
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     valid_buypoint = (y0[:, d] != 0).nonzero()[0]
#     profit_position = np.zeros(len(y0))

#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb <= valid_sellpoint[i] + lag - 1:
#                 return i, True

#     total_profit = 0
#     for vb in valid_buypoint:
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     profit_position[vb] = profit[vb, d]
#                     positions_dict[bin] += 1
#             else:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     profit_position[vb] = profit[vb, d]
#                     positions_dict[bin+1] += 1
#                     positions_dict[bin] += 1
#         else:
#             print("why larger")
#     return total_profit, profit_position  


@jit
def calculate_profit_with_position(y0, valid_sellpoint, d=4, position=5, lag=1):
    # print(valid_sellpoint)

    profit = y0
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    valid_buypoint = (y0[:, d] != 0).nonzero()[0]
    profit_position = np.zeros(len(y0))
    deferred_position_bin = -1
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True

            
    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items 
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
            else:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
        else:
            print("why larger")
    return total_profit, profit_position, positions_dict      
     

def generate_test_predictRL(model, dataset, type_, std_profit, mean_profit, abs_profit, y0, rand_number):

    model.eval()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    profit_fix = {i:0 for i in range(7)}
    profit_chosen = 0
    profit_max = 0
    chosen_total = torch.zeros(len(dataset)).cuda()
    max_total =  torch.zeros(len(dataset)).cuda()
    profit_chosen_total = torch.zeros(len(dataset)).cuda()
    y_total = torch.from_numpy(y0[args.T - 1:]).cuda()
    pure_profit_fix = {i:0 for i in range(7)}
    pure_profit_chosen = 0
    pure_profit_max = 0
    pure_loss_fix = {i:0 for i in range(7)}
    pure_loss_chosen = 0
    pure_loss_max = 0   
    profit_fix_3 = {i:0 for i in range(7)}
    profit_chosen_3 = 0
    profit_max_3 = 0
    chosen_value_total = torch.zeros(len(dataset)).cuda()

    lines_position = []
    if type_ == "buy":
        valid_sellpoint = np.load(args.valid_sellpoint)
        print(valid_sellpoint)
        for pos in [5]:
            for j in range(0, 6): 
                p, profit_fix_position, positions_dict = calculate_profit_with_position(y0, valid_sellpoint, d=j, position=pos, lag=lag)
                print("pos, j, p", pos, j, p)
                lines_position.append(np.cumsum(profit_fix_position))

    if type_ == "sell":
        valid_buypoint = np.load(args.valid_buypoint)
        for pos in [5]:
            for j in range(0, 6): 
                p, profit_fix_position, positions_dict = calculate_profit_with_position(y0, valid_buypoint, d=j, position=pos, lag=lag)
                print("pos, j, p", pos, j, p)    
                lines_position.append(np.cumsum(profit_fix_position))


    with torch.no_grad():
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat = model(x).squeeze()
            # print(y_hat)
            unnormalized_y = y.clone()
            unnormalized_y = (unnormalized_y*std_profit+mean_profit)*abs_profit
            for j in range(0, 7):
                profit_fix[j] += torch.sum(unnormalized_y[:, j]).item()
            profit_chosen += torch.sum(unnormalized_y.gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1))).item()
            profit_max += torch.sum(torch.max(unnormalized_y, dim=1)[0]).item()
            chosen_total[index] = torch.argmax(y_hat, axis=1).float()
            max_total[index] = torch.argmax(y, axis=1).float()
            profit_chosen_total[index] = unnormalized_y.gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1)).squeeze()

            for j in range(0, 7):
                profit_div = torch.sum(torch.clamp(unnormalized_y[:, j], min=0))
                loss_div = -torch.sum(torch.clamp(unnormalized_y[:, j], max=0))
                pure_profit_fix[j] += profit_div.item()
                pure_loss_fix[j] += loss_div.item()
            chosen = (unnormalized_y).gather(1, torch.argmax(y_hat, axis=1).unsqueeze(1))
            chosen_value_total[index] = chosen.squeeze()

            profit_div = torch.sum(torch.clamp(chosen, min=0))
            loss_div = -torch.sum(torch.clamp(chosen, max=0))
            # print("why so large", loss_div, torch.sum(chosen))
            # print("why so large", loss_div, torch.sum(chosen), profit_chosen_3)
            pure_profit_chosen += profit_div.item()
            pure_loss_chosen += loss_div.item()
            profit_div = torch.sum(torch.clamp(torch.max((unnormalized_y), dim=1)[0], min=0))
            loss_div = -torch.sum(torch.clamp(torch.max((unnormalized_y), dim=1)[0], max=0))
            pure_profit_max += profit_div.item()
            pure_loss_max += loss_div.item()
            chosen_total[index] = torch.argmax(y_hat, axis=1).float()
            max_total[index] = torch.argmax(y, axis=1).float()

        for j in range(0, 7):
            print("sharpe", torch.mean(y_total[:, j]), torch.std(y_total[:, j]), torch.mean(y_total[:, j])/torch.std(y_total[:, j]))
        print("sharpe max", torch.mean(torch.max((y_total), dim=1)[0]), torch.std(torch.max((y_total), dim=1)[0]), torch.mean(torch.max((y_total), dim=1)[0])/torch.std(torch.max((y_total), dim=1)[0]))
        print("sharpe chosen", torch.mean(chosen_value_total), torch.std(chosen_value_total), torch.mean(chosen_value_total)/torch.std(chosen_value_total))

        profit_chosen_3 += (profit_chosen/pure_loss_chosen)
        profit_max_3 += (profit_max/(pure_loss_max+1e-20))
        for j in range(0, 7):
            profit_fix_3[j] += (profit_fix[j]/(pure_loss_fix[j]+1e-20))
        # with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+args.rand_number+"RL_buyopen.npy", 'wb') as f:
            # np.save(f, chosen_total.detach().cpu().numpy())
        # with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+args.rand_number+"RL_buyopenmax.npy", 'wb') as f:
            # np.save(f, max_total.detach().cpu().numpy())
        # with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+args.rand_number+"RL_buyopen.npy", 'rb') as f:
        #     chosen_total = torch.from_numpy(np.load(f))
        # with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+args.rand_number+"RL_buyopenmax.npy", 'rb') as f:
        #     max_total = torch.from_numpy(np.load(f))
        print("for all positions")
        print(torch.sum(chosen_total == 0)/chosen_total.size(0))
        print(torch.sum(chosen_total == 1)/chosen_total.size(0))
        print(torch.sum(chosen_total == 2)/chosen_total.size(0))
        print(torch.sum(chosen_total == 3)/chosen_total.size(0))
        print(torch.sum(chosen_total == 4)/chosen_total.size(0))
        print(torch.sum(chosen_total == 5)/chosen_total.size(0))
        print("acc", torch.sum(chosen_total==max_total)/chosen_total.size(0))
        print("for positions with trades")
        indices = []
        tmp =  y_total != 0
        indices = tmp[:,0].logical_or(tmp[:, 1]).logical_or(tmp[:, 2]).logical_or(tmp[:, 3]).logical_or(tmp[:, 4]).logical_or(tmp[:, 5])
        print(indices)

        import matplotlib.pyplot as plt

        lines = np.cumsum(y0, axis=0)
        
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(0, 7):
            ax1.plot(lines[:, j])
        
        profit_chosen_np = profit_chosen_total.cpu().detach().numpy()
        line_chosen = np.cumsum(profit_chosen_np)
        ax1.plot(line_chosen)

        # plt.title(args.arch+";a:"+str(a)+"b:"+str(b)+"d:"+str(d))
        plt.legend()
        plt.show()
        plt.savefig("result_"+args.rl_profit_path[:17]+"_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+".png")

        import matplotlib.pyplot as plt
        
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(0, 6):
            ax1.plot(lines_position[j])
        
        

        # for i in range(y_total.size(0)):
            # if not torch.all(y_total[i] == 0):
                # print(i)
                # indices.append(i)
        # indices = [not torch.all(y_total[i] == 0) for i in range(y_total.size(0))]
        chosen_total_shrink = chosen_total[indices]
        max_total_shrink = max_total[indices]
        print(chosen_total_shrink.size(), max_total_shrink.size())
        print(torch.sum(chosen_total_shrink == 0)/chosen_total_shrink.size(0))
        print(torch.sum(chosen_total_shrink == 1)/chosen_total_shrink.size(0))
        print(torch.sum(chosen_total_shrink == 2)/chosen_total_shrink.size(0))
        print(torch.sum(chosen_total_shrink == 3)/chosen_total_shrink.size(0))
        print(torch.sum(chosen_total_shrink == 4)/chosen_total_shrink.size(0))
        print(torch.sum(chosen_total_shrink == 5)/chosen_total_shrink.size(0))
        print("acc", torch.sum(chosen_total_shrink==max_total_shrink)/chosen_total_shrink.size(0))
        # print((chosen_total == 0).shape, )
        print(torch.sum(max_total[chosen_total == 0] == 0)/chosen_total.size(0))
        print(torch.sum(max_total[chosen_total == 1] == 1)/chosen_total.size(0))
        print(torch.sum(max_total[chosen_total == 2] == 2)/chosen_total.size(0))
        print(torch.sum(max_total[chosen_total == 3] == 3)/chosen_total.size(0))
        print(torch.sum(max_total[chosen_total == 4] == 4)/chosen_total.size(0))
        print(torch.sum(max_total[chosen_total == 5] == 5)/chosen_total.size(0))

    if type_ == "buy":
        valid_sellpoint = np.load(args.valid_sellpoint)
        print(valid_sellpoint)
        for pos in [5]:
            chosen_value_total = y_total.gather(1, chosen_total.unsqueeze(1).long()).squeeze()
            temp_chosen_total = np.concatenate([np.zeros(args.T-1), chosen_value_total.cpu().detach().numpy()], axis=0)
            # temp_chosen_total[np.abs(temp_chosen_total) < 1e-10] = 0
            p, profit_chosen, positions_dict = calculate_profit_with_chosen(valid_sellpoint, temp_chosen_total, position=pos)
            line_chosen_postion = np.cumsum(profit_chosen)
            print("pos, p", pos, p)

    if type_ == "sell":
        valid_buypoint = np.load(args.valid_buypoint)
        for pos in [5]:
            chosen_value_total = y_total.gather(1, chosen_total.unsqueeze(1).long()).squeeze()
            temp_chosen_total = np.concatenate([np.zeros(args.T-1), chosen_value_total.cpu().detach().numpy()], axis=0)
            # temp_chosen_total[np.abs(temp_chosen_total) < 1e-10] = 0
            p, profit_chosen, positions_dict = calculate_profit_with_chosen(valid_buypoint, temp_chosen_total, position=pos)
            line_chosen_postion = np.cumsum(profit_chosen)
            print("pos, p", pos, p)    

    ax1.plot(line_chosen_postion)
    plt.legend()
    plt.show()
    plt.savefig("result_"+args.rl_profit_path[:17]+"_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"position5.png")


    for j in range(0, 7): 
        print("d=", j, "profit_fix[j], profit_fix_3[j], pure_profit_fix[j], pure_loss_fix[j]", profit_fix[j], profit_fix_3[j], pure_profit_fix[j], pure_loss_fix[j])
    print("pure_profit_chosen, pure_loss_chosen, pure_profit_max, pure_loss_max", pure_profit_chosen, pure_loss_chosen, pure_profit_max, pure_loss_max)
    print("profit_chosen, profit_max, profit_chosen_3, profit_max_3", profit_chosen, profit_max, profit_chosen_3, profit_max_3)
    

    return lines, line_chosen, y_total, chosen_value_total, lines_position, line_chosen_postion


def generate_test_predictRLd3(model, dataset, rl_profit_path, type_, rand_number):
    model.eval()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_hat_total = torch.zeros((len(dataset), 7)).cuda()
    if type_ == "buyyy":
        with torch.no_grad():
            for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
                x = x.cuda()
                y_hat_total[index] = model(x).squeeze()
        torch.save(y_hat_total, "y_hat_total.pt"+type_)
    else:
        y_hat_total = torch.load("y_hat_total.pt"+type_)
    lines_lag, line_chosen_lag, lines_position_lag, line_chosen_position_lag, y_total_lag, chosen_value_total_lag = [], [], [], [], [], []
    chosen_value_total = torch.argmax(y_hat_total, axis=1)
    print(torch.sum(chosen_value_total == 0)/chosen_value_total.size(0))
    print(torch.sum(chosen_value_total == 1)/chosen_value_total.size(0))
    print(torch.sum(chosen_value_total == 2)/chosen_value_total.size(0))
    print(torch.sum(chosen_value_total == 3)/chosen_value_total.size(0))
    print(torch.sum(chosen_value_total == 4)/chosen_value_total.size(0))
    print(torch.sum(chosen_value_total == 5)/chosen_value_total.size(0))
    print(torch.sum(chosen_value_total == 6)/chosen_value_total.size(0))

    for lag in range(1, 4):
        y0 = np.load(rl_profit_path+"_"+str(lag)+".npy")
        y_total = torch.from_numpy(y0[args.T - 1:]).cuda()
        chosen_value_total = y_total.gather(1, torch.argmax(y_hat_total, axis=1).unsqueeze(1)).squeeze()
        max_total = torch.max(y_total, axis=1)[0]
        y_total_lag.append(y_total)
        chosen_value_total_lag.append(chosen_value_total)
        lines = np.cumsum(y0, axis=0)
        lines_lag.append(lines)
        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(0, 7):
                ax1.plot(lines[::interval, j])
            
            line_chosen = np.cumsum(chosen_value_total.cpu().detach().numpy())
            line_chosen_lag.append(line_chosen)
            ax1.plot(line_chosen[::interval])

            plt.legend()
            plt.show()
            plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+".png")
            
        lines_position = []
        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)

        if type_ == "buy":
            valid_sellpoint = np.load(args.valid_sellpoint+"_"+str(lag)+".npy")
            for thres in range(15, 25, 1):
                for pos in [args.pos]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = np.concatenate([np.zeros(args.T-1), temp_chosen_total.cpu().detach().numpy()], axis=0)
                    p, profit_chosen, positions_dict = calculate_profit_with_chosen(valid_sellpoint, temp_chosen_total, position=pos, lag=lag)
                    if thres == 20:
                        line_chosen_postion = np.cumsum(profit_chosen)
                    print("chosen buy, pos, p, thres", pos, p, thres)
            for pos in [args.pos]:
                for j in range(0, 6): 
                    p, profit_fix_position, positions_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=pos, lag=lag)
                    
                    print("fix buy, pos, j, p", pos, j, p)
                    lines_position.append(np.cumsum(profit_fix_position))

        if type_ == "sell":
            valid_buypoint = np.load(args.valid_buypoint+"_"+str(lag)+".npy")
            for thres in range(15, 25, 1):
                for pos in [args.pos]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = np.concatenate([np.zeros(args.T-1), temp_chosen_total.cpu().detach().numpy()], axis=0)
                    p, profit_chosen, positions_dict = calculate_profit_with_chosen(valid_buypoint, temp_chosen_total, position=pos, lag=lag)
                    if thres == 20:
                        line_chosen_postion = np.cumsum(profit_chosen)
                    print("chosen sell, pos, p", pos, p)    
            for pos in [args.pos]:
                for j in range(0, 6): 
                    p, profit_fix_position, positions_dict = calculate_profit_with_chosen(valid_buypoint, y0[:, j], position=pos, lag=lag)
                    print("fix sell, pos, j, p", pos, j, p)    
                    lines_position.append(np.cumsum(profit_fix_position))
        
        if args.draw:
            for j in range(0, 6):
                ax1.plot(lines_position[j][::interval])
            ax1.plot(line_chosen_postion[::interval])
            plt.legend()
            plt.show()
            plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+"position"+str(args.pos)+".png")
            lines_position_lag.append(lines_position)
            line_chosen_position_lag.append(line_chosen_postion)
        for j in range(0, 7): 
            print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total[:, j]).item(), (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total[:, j], max=0))).item(), (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item(), (torch.mean(y_total[:, j])/(1e-20+torch.var(y_total[:, j]))).item())
        print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total)).item(), (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total, max=0))).item(), (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item(), (torch.mean(chosen_value_total)/(1e-20+torch.var(chosen_value_total))).item())
        print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total)).item(), (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total, min=0))).item(), (-torch.sum(torch.clamp(max_total, max=0))).item(), (torch.mean(max_total)/(1e-20+torch.std(max_total))).item(), (torch.mean(max_total)/(1e-20+torch.var(max_total))).item())
    
    if args.draw:
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(0, 7):
            ax1.plot(lines_lag[0][::interval, j]+lines_lag[1][::interval, j]+lines_lag[2][::interval, j])
        ax1.plot(line_chosen_lag[0][::interval]+line_chosen_lag[1][::interval]+line_chosen_lag[2][::interval])

        plt.legend()
        plt.show()
        plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123"+".png")
        plt.clf()

        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)

        for j in range(0, 6):
            ax1.plot(lines_position_lag[0][j][::interval]+lines_position_lag[1][j][::interval]+lines_position_lag[2][j][::interval])
        ax1.plot(line_chosen_position_lag[0][::interval]+line_chosen_position_lag[1][::interval]+line_chosen_position_lag[2][::interval])
        plt.legend()
        plt.show()
        plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123position"+str(args.pos)+".png")
        plt.clf()

    return lines_lag, line_chosen_lag, lines_position_lag, line_chosen_position_lag, y_total_lag, chosen_value_total_lag


def generate_test_predict18(model, date_list=args.test[0], type_='test'):
    import datetime
    model.eval()
    with torch.no_grad():
        start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
        print(start_month, start_day, end_month, end_day)
        start = datetime.date(2022,start_month,start_day)
        if end_month < start_month:
            year = 2023
        else:
            year = 2022
        end = datetime.date(year,end_month,end_day)
        print(start, end)
        y_hat_total = None
        loss_l, corr_l, r2_l = [], [], []

        for i in range((end-start).days+1):
            day = start + datetime.timedelta(days=i)
            month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
            day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
            print(i, day, month_str, day_str)
            if args.use_p23 == 13:
                xnn = np.load('data_6/xnn6'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x3'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.use_p23 == 12:
                xnn = np.load('data_6/xnn5'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x2'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            else:
                xnn = np.load('data_6/xnn'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
                x = np.load('data_6/x'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            if args.y == "0":
                y = np.load('data_6/y'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "3":
                y = np.load('data_6/y3'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "4":
                y = np.load('data_6/y4'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            elif args.y == "50":
                y = np.load('data_6/y50'+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r")
            dataset = StockAggregate18(type_, xnn=xnn, x=x, y=y)

            y_hat_day_i = torch.zeros(len(dataset)).cuda()
            loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False,
                                                    sampler=torch.utils.data.SequentialSampler(dataset),
                                                    batch_size=args.batch_size, num_workers=4, pin_memory=True)
            y_day_i = torch.from_numpy(dataset.data_y[args.T - 1:]).float().cuda()
            print(y_day_i.size(0))
            index_zero = [45, 46, 47, 48, 69, 70, 71, 72]
            for _, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
                # x_np = x.cpu().detach().numpy()
                # np.save("504_batched1.npy", x_np)
                if args.test=="01_01-01_10":
                    x[:, index_zero] = 0
                x, y = x.cuda(), y.cuda()
                # print("x nan?", torch.isnan(x).sum(), torch.isinf(x).sum(), (x>1e10).nonzero(), x[:, 45])
                y_hat_day_i[index] = model(x).squeeze().detach()
                # print(y, y_hat_day_i[index], x)
                # print(((y - y_hat_day_i[index]) ** 2).mean().item())
                # print(abs(np.corrcoef(torch.cat((y.unsqueeze(1), y_hat_day_i[index].unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1]))
                # print((1 - ((y - y_hat_day_i[index]) ** 2).sum() / ((y - y.mean()) ** 2).sum()).item())

                # print(torch.isnan(y_hat_day_i[index]).sum())
            np.save("wierd.npy", y_hat_day_i.cpu().detach().numpy())
            if args.use_p23 == 100:
                import pandas as pd
                dataset.raw2['predict1']=pd.DataFrame(np.concatenate([np.zeros((4, )), y_hat_day_i.detach().cpu().numpy()], axis=0), index = dataset.raw2.index)
                data = dataset.raw2
                from influxdb import DataFrameClient
                client = DataFrameClient('***.***.***.***', ******)
                i = 0
                for i in range(1, int(len(data[['predict1']])//1e5)):
                    print((i-1)*int(1e5), i*int(1e5))
                    client.write_points(data[['predict1']][(i-1)*int(1e5):i*int(1e5)], "backtest_y0_1", {})
                print(i*int(1e5), len(data[['predict1']]))
                client.write_points(data[['predict1']][i*int(1e5):], "backtest_y0_1", {})
                print("output", y_hat_day_i)
            loss_day_i = ((y_day_i - y_hat_day_i) ** 2).mean().item()
            corr_day_i = abs(np.corrcoef(torch.cat((y_day_i.unsqueeze(1), y_hat_day_i.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2_day_i = (1 - ((y_day_i - y_hat_day_i) ** 2).sum() / ((y_day_i - y_day_i.mean()) ** 2).sum()).item()
            print(i, day, month_str, day_str, loss_day_i, corr_day_i, r2_day_i)
            loss_l.append(loss_day_i)
            corr_l.append(corr_day_i)
            r2_l.append(r2_day_i)

            if i == 0:
                y_hat_total = torch.cat((torch.zeros((args.T-1)).cuda(), y_hat_day_i), dim=0)
                y_total = torch.cat((torch.zeros(args.T-1).cuda(), y_day_i), dim=0)
            else:
                y_hat_total = torch.cat([y_hat_total, torch.zeros((args.T-1)).cuda(), y_hat_day_i], dim=0)
                y_total = torch.cat([y_total, torch.zeros((args.T-1)).cuda(), y_day_i], dim=0)                  
            del dataset, loader_seq
        loss_all = ((y_total - y_hat_total) ** 2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1 - ((y_total - y_hat_total) ** 2).sum() / ((y_total - y_total.mean()) ** 2).sum()).item()
        print("all", loss_all, corr_all, r2_all)
    if args.use_p23 == 100:
        with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number)+".npy100", 'wb') as f:
            np.save(f, y_hat_total.detach().cpu().numpy())
    else:
        with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number)+".npy", 'wb') as f:
            np.save(f, y_hat_total.detach().cpu().numpy())


def generate_test_predict(model, dataset):
    model.eval()
    y_hat_total = torch.zeros(len(dataset)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=8, pin_memory=True)
    y_total = dataset.data_y[args.T - 1:].cuda()
    
    with torch.no_grad():
        for i, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat_total[index] = model(x).squeeze().detach()
        loss_all = ((y_total-y_hat_total)**2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1-((y_total-y_hat_total)**2).sum()/((y_total-y_total.mean())**2).sum()).item()
        print("all", loss_all, corr_all, r2_all)
        length_to_date = 0
        loss_l, corr_l, r2_l = [], [], []
        for i, l in enumerate(y_length_list):
            length_to_date_end = length_to_date + l
            y_total_seg = y_total[length_to_date:length_to_date_end]
            y_hat_total_seg = y_hat_total[length_to_date:length_to_date_end]
            loss = ((y_total_seg-y_hat_total_seg)**2).mean().item()
            corr = abs(np.corrcoef(torch.cat((y_total_seg.unsqueeze(1), y_hat_total_seg.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2 = (1-((y_total_seg-y_hat_total_seg)**2).sum()/((y_total_seg-y_total_seg.mean())**2).sum()).item()
            length_to_date = length_to_date_end
            print("day", i, loss, corr, r2)
            loss_l.append(loss)
            corr_l.append(corr)
            r2_l.append(r2)
    with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+args.rand_number+".npy", 'wb') as f:
        np.save(f, y_hat_total.detach().cpu().numpy())

if args.old == 33:
    train_dataset = stock.StockAggregate33("train")
    test_dataset = stock.StockAggregate33("test")
elif args.old == 32  or args.old ==41:
    if not args.generate_test_predict:
        train_dataset = stock.StockAggregate32("train")
    test_dataset = stock.StockAggregate32("test")
elif args.old == 31:
    train_dataset = stock.StockAggregate31("train")
    test_dataset = stock.StockAggregate31("test")
elif args.old == 30:
    train_dataset = stock.StockAggregate30("train")
    test_dataset = stock.StockAggregate30("test")

elif args.old == 29:
    train_dataset = stock.StockAggregate29("train")

elif args.old == 28:
    test_dataset_2_buy = stock.StockAggregate28("test2", "buy")
    test_dataset_2_sell = stock.StockAggregate28("test2", "sell")

elif args.old == 27:
    train_dataset = stock.StockAggregate27("train")
    test_dataset = stock.StockAggregate27("test")
    test_dataset_2 = stock.StockAggregate27("test2")
elif args.old == 26:
    train_dataset = stock.StockAggregate26("train")
    test_dataset = stock.StockAggregate26("test")
    test_dataset_2 = stock.StockAggregate26("test2")
elif args.old == 25:
    train_dataset = stock.StockAggregate25("train")
    test_dataset = stock.StockAggregate25("test")
    test_dataset_2 = stock.StockAggregate25("test2")
elif args.old == 24:
    test_dataset_2_buy = stock.StockAggregate24("test2", "buy")
    test_dataset_2_sell = stock.StockAggregate24("test2", "sell")

elif args.old == 23:
    test_dataset_2 = stock.StockAggregate21("test2")
elif args.old == 21:
    train_dataset = stock.StockAggregate21("train")
    test_dataset = stock.StockAggregate21("test")
    test_dataset_2 = stock.StockAggregate21("test2")
elif args.old == 20:
    train_dataset = stock.StockAggregate20("train")
    test_dataset = stock.StockAggregate20("test")
    test_dataset_2 = stock.StockAggregate20("test2")
elif args.old == 19:
    train_dataset = stock.StockAggregate19("train")
    test_dataset = stock.StockAggregate19("test")
    test_dataset_2 = stock.StockAggregate19("test2")
elif args.old == 18:
    if not args.generate_test_predict:
        train_dataset = stock.StockAggregate18("train")
elif args.old == 17:
    train_dataset = stock.StockAggregate17("train")
    # val_dataset = stock.StockAggregate12("val")
    test_dataset = stock.StockAggregate17("test")
    test_dataset_2 = stock.StockAggregate17("test2")

elif args.old == 15:
    train_dataset = stock.StockAggregate15("train")
    # val_dataset = stock.StockAggregate12("val")
    test_dataset = stock.StockAggregate15("test")
    test_dataset_2 = stock.StockAggregate15("test2")

elif args.old == 10:
    train_dataset = stock.StockAggregate10("train")
    # val_dataset = stock.StockAggregate10("val")
    test_dataset = stock.StockAggregate10("test")
    test_dataset_2 = stock.StockAggregate10("test2")

else:
    train_dataset = stock.StockAggregate("train")
    # val_dataset = stock.StockAggregate("val")
    test_dataset = stock.StockAggregate("test")
    test_dataset_2 = stock.StockAggregate("test2")

if not args.generate_test_predict:

    if args.old != 23 and args.old != 24 and args.old != 28:
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=8, pin_memory=True)
    if args.old == 26:
        train_loader = torch.utils.data.DataLoader(train_dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(train_dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)

if "Classification" in args.arch:
    if args.reweight:
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True, sampler=wegihtedsampler)
    else:
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True)

# test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=64, shuffle=False, num_workers=20, pin_memory=True)

if args.loss == "mse":
    criterion = nn.MSELoss()
elif args.loss == "l1":
    criterion = nn.L1Loss()
elif args.loss == "huber":
    criterion = nn.HuberLoss()
elif args.loss == "smoothl1":
    criterion = nn.SmoothL1Loss()
if "Classification" in args.arch:
    criterion = nn.CrossEntropyLoss()

if not args.linear:
    # model = nn.Sequential(nn.Linear(args.input_size, 256), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, 256), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, 1)).cuda()
    # model = nn.Sequential(nn.Linear(args.input_size, args.hidden), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(args.hidden), nn.ReLU(), nn.Linear(args.hidden, args.hidden), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(args.hidden), nn.ReLU(), nn.Linear(args.hidden, 1)).cuda()
    # model = CNN().cuda()
    model = models.__dict__[args.arch]()
    # model = torch.quantization.quantize_dynamic(
        # model, {nn.LSTM, nn.Linear}, dtype=torch.qint8
    # )
    model = model.cuda()
else:
    model = nn.Linear(args.input_size, 1, bias=False).cuda()

interval = int(1e3)
if args.generate_test_predict:
    # model = torch.load("best_model_y"+args.y+"_05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27_05_30-05_30;06_07-06_07;06_14-06_14;06_21-06_21.pt").cuda()
    print(args.valid)
    args.rand_number = str(args.seed)
    # model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_copy.pt")
    if args.old == 32 or args.old == 33 or args.old == 41:
        model = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+args.rand_number+".pt")
        temp_K = args.K
        args.K = 1
        # p2_ = calculate_train_RLd3_32(model, train_dataset, args.rlbuy_profit_path, args.rlsell_profit_path, args.valid_2ndsellpoint, args.valid_2ndbuypoint, step=0, tag="train")
        p_ = calculate_train_RLd3_32(model, test_dataset, args.rlbuy_profit_path2, args.rlsell_profit_path2, args.valid_2ndsellpoint2, args.valid_2ndbuypoint2, step=0, tag="test")
        args.K = temp_K
        
    elif args.old == 29 or args.old == 31:
        model_buy = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")

        p2_ = calculate_train_RLd3(model_buy, train_dataset, args.rl_profit_path, args.valid_sellpoint, args.valid_buypoint, type_=args.type, tag="train", rand_number=args.rand_number)
        p_ = calculate_train_RLd3(model_buy, test_dataset, args.rl_profit_path2, args.valid_sellpoint2, args.valid_buypoint2, type_=args.type, tag="test", rand_number=args.rand_number)

    elif args.old == 28:
        print("model buy", "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
        model_buy = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
        model_sell = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+str(args.rand_number0)+".pt")

        lines_1, line_chosen_1, lines_p1, line_chosen_p1, y_total1, chosen_value_total1 = generate_test_predictRLd3(model_buy, test_dataset_2_buy, args.rl_profit_path, "buy", args.rand_number)
        lines_2, line_chosen_2, lines_p2, line_chosen_p2, y_total2, chosen_value_total2 = generate_test_predictRLd3(model_sell, test_dataset_2_sell, args.rl_profit_path2,  "sell", str(args.rand_number0))
        for lag in range(0, 3):
            y_total = y_total1[lag] + y_total2[lag]
            chosen_value_total = chosen_value_total1[lag] + chosen_value_total2[lag]
            max_total = torch.max(y_total1[lag], axis=1)[0] + torch.max(y_total2[lag], axis=1)[0]
            for j in range(0, 7): 
                print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total[:, j]).item(), (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total[:, j], max=0))).item(), (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item(), (torch.mean(y_total[:, j])/(1e-20+torch.var(y_total[:, j]))).item())
            print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total)).item(), (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total, max=0))).item(), (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item(), (torch.mean(chosen_value_total)/(1e-20+torch.var(chosen_value_total))).item())
            print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total)).item(), (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total, min=0))).item(), (-torch.sum(torch.clamp(max_total, max=0))).item(), (torch.mean(max_total)/(1e-20+torch.std(max_total))).item(), (torch.mean(max_total)/(1e-20+torch.var(max_total))).item())
            if args.draw:
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(0, 7):
                    ax1.plot(lines_1[lag][::interval, j]+lines_2[lag][::interval, j])
                ax1.plot(line_chosen_1[lag][::interval] + line_chosen_2[lag][::interval])
                plt.legend()
                plt.show()
                plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_"+str(lag+1)+".png")    
                plt.clf()

                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                for j in range(0, 6):
                    ax1.plot(lines_p1[lag][j][::interval]+lines_p2[lag][j][::interval])
                ax1.plot(line_chosen_p1[lag][::interval] + line_chosen_p2[lag][::interval])
                plt.legend()
                plt.show()
                plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_"+str(lag+1)+"_position"+str(args.pos)+".png")  
                plt.clf()
        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(0, 7):
                ax1.plot(lines_1[0][::interval, j]+lines_2[0][::interval, j]+lines_1[1][::interval, j]+lines_2[1][::interval, j]+lines_1[2][::interval, j]+lines_2[2][::interval, j])
            ax1.plot(line_chosen_1[0][::interval] + line_chosen_2[0][::interval] + line_chosen_1[1][::interval] + line_chosen_2[1][::interval] + line_chosen_1[2][::interval] + line_chosen_2[2][::interval])

            plt.legend()
            plt.show()
            plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_123"+".png")
            plt.clf()

            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)

            for j in range(0, 6):
                ax1.plot(lines_p1[0][j][::interval]+lines_p2[0][j][::interval]+lines_p1[1][j][::interval]+lines_p2[1][j][::interval]+lines_p1[2][j][::interval]+lines_p2[2][j][::interval])
            ax1.plot(line_chosen_p1[0][::interval] + line_chosen_p2[0][::interval] + line_chosen_p1[1][::interval] + line_chosen_p2[1][::interval] + line_chosen_p1[2][::interval] + line_chosen_p2[2][::interval])
            plt.legend()
            plt.show()
            plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_123position"+str(args.pos)+".png")
            plt.clf()

    elif args.old == 24:
        model_buy = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
        model_sell = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+str(args.rand_number0)+".pt")
        lines_1, line_chosen_1, y_total1, chosen_value_total1, lines_p1, line_chosen_p1 = generate_test_predictRL(model_buy, test_dataset_2_buy, "buy", std_profit, mean_profit, abs_profit, y0, args.rand_number)
        lines_2, line_chosen_2, y_total2, chosen_value_total2, lines_p2, line_chosen_p2 = generate_test_predictRL(model_sell, test_dataset_2_sell, "sell", std_profit_, mean_profit_, abs_profit_, y0_, str(args.rand_number0))
        y_total = y_total1+ y_total2
        chosen_value_total = chosen_value_total1+ chosen_value_total2
        

        for j in range(0, 7):
            print("sharpe", torch.mean(y_total[:, j]), torch.std(y_total[:, j]), torch.mean(y_total[:, j])/torch.std(y_total[:, j]))
        print("sharpe max", torch.mean(torch.max((y_total), dim=1)[0]), torch.std(torch.max((y_total), dim=1)[0]), torch.mean(torch.max((y_total), dim=1)[0])/torch.std(torch.max((y_total), dim=1)[0]))
        print("sharpe chosen", torch.mean(chosen_value_total), torch.std(chosen_value_total), torch.mean(chosen_value_total)/torch.std(chosen_value_total))
        
        import matplotlib.pyplot as plt

        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(0, 7):
            ax1.plot(lines_1[:, j]+lines_2[:, j])
        ax1.plot(line_chosen_1 + line_chosen_2)
        plt.legend()
        plt.show()
        plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+".png")    

        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(0, 6):
            ax1.plot(lines_p1[j]+lines_p2[j])
        ax1.plot(line_chosen_p1 + line_chosen_p2)
        plt.legend()
        plt.show()
        plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"position5.png")    
    elif args.old == 21 or args.old == 23:
        model = torch.load("results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
        generate_test_predictRL(model, test_dataset_2, args.rl_profit_path[12:15], std_profit, mean_profit, abs_profit, y0, args.rand_number)
    elif args.old == 18:
        model = torch.load("results/best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_"+';'.join(args.test2)+args.rand_number+".pt")
        generate_test_predict18(model)
    else:
        model = torch.load("results/best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_"+';'.join(args.test2)+args.rand_number+".pt")
        generate_test_predict(model, test_dataset)
    exit(0)

if args.test_pretrained:
    # model = torch.load("best_model_y"+args.y+"_05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27_05_30-05_30;06_07-06_07;06_14-06_14;06_21-06_21.pt").cuda()
    print(args.valid)
    epoch = 0
    args.rand_number = str(args.seed)
    model = torch.load("results/best_model_pretrained"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    # model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_copy.pt")
    calculate_test_pretrained(model, test_dataset)
    exit(0)

if args.test_time:
    test_time(model)
    export_model(model)
    exit(0)

if args.load_pretrained:
    args.rand_number = str(args.seed)
    pretrained_model = torch.load("results/best_model_pretrained"+"TSTransformerEncoderPretrained"+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    print(pretrained_model)
    pretrained_state_dict = pretrained_model.state_dict()
    model_state_dict = model.state_dict()
    # print(model_state_dict.keys())
    for k, v in pretrained_state_dict.items():
        if k not in model_state_dict or v.size() != model_state_dict[k].size():
            if k not in model_state_dict:
                print("not in state dict")
            else:
                print("size not match")
            print("IGNORE:", k)
        else:
            print("LOAD:", k)
            
    pretrained_state_dict = {
        k: v
        for k, v in pretrained_state_dict.items()
        if (k in model_state_dict and v.size() == model_state_dict[k].size())
    }
    model_state_dict.update(pretrained_state_dict)
    model.load_state_dict(model_state_dict)
    if args.freeze_pretrained:
        for n, p in model.named_parameters():
            if n in pretrained_state_dict:
                print("Freeze", n)
                p.requires_grad = False
print("number of parameters:", count_parameters(model))
print(model)
bn_params = [v for n, v in list(model.named_parameters()) if ("bn" in n) and v.requires_grad]
rest_params = [v for n, v in list(model.named_parameters()) if ("bn" not in n) and v.requires_grad]
if args.opt == "sgd":
    opt = torch.optim.SGD([
        {
            "params": bn_params,
            "weight_decay": 0 if args.no_bn_decay else args.wd,
        },
        {"params": rest_params, "weight_decay": args.wd},
    ], lr=lr, momentum=0.9, weight_decay = args.wd)
elif args.opt == "adamw":
    if args.follow_attn:
        opt = torch.optim.AdamW([
            {
                "params": bn_params,
                "weight_decay": 0 if args.no_bn_decay else args.wd,
            },
            {"params": rest_params, "weight_decay": args.wd},
        ], lr=lr, weight_decay = args.wd, eps=1e-09, betas=(0.9, 0.98),)
    else:
        opt = torch.optim.AdamW([
            {
                "params": bn_params,
                "weight_decay": 0 if args.no_bn_decay else args.wd,
            },
            {"params": rest_params, "weight_decay": args.wd},
        ], lr=lr, weight_decay = args.wd)

elif args.opt == "adam":
    opt = torch.optim.Adam([
        {
            "params": bn_params,
            "weight_decay": 0 if args.no_bn_decay else args.wd,
        },
        {"params": rest_params, "weight_decay": args.wd},
    ], lr=lr, weight_decay = args.wd)




best_loss = 200
best_corr = -200
best_r2 = -200
best_epoch_loss = -1
best_epoch_corr = -1
best_epoch_r2 = -1
from random import randrange
args.rand_number = str(randrange(1e10))
for epoch in range(epochs):
    if args.tempannealing:
        args.temp = 1 / ((1 - 0.03) * (1 - epoch / epochs) + 0.03)
    else:
        args.temp = 1
    # assign_learning_rate(opt, 0.5 * (1 + np.cos(np.pi * epoch / epochs)) * lr)
    if args.train_pg:
        trainloss, traincorr, trainr2 = train_pg(model, criterion, train_loader, opt, epoch, train_dataset)
    else:
        trainloss, traincorr, trainr2 = train(model, criterion, train_loader, opt, epoch)
    # trainloss, traincorr, trainr2 = calculate_real_stats(model, train_dataset, evaluate=True)
    # print("real train loss, corr, r2",  trainloss, traincorr, trainr2) 
    # valloss, valcorr, valr2 = validate(model, criterion, val_loader, epoch)
    # valloss, valcorr, valr2 = calculate_real_stats(model, val_dataset, evaluate=True)
    # print("real val loss, corr, r2",  valloss, valcorr, valr2) 
    # testloss, testcorr, testr2 = validate(model, criterion, test_loader, epoch)
    # testloss, testcorr, testr2 = calculate_real_stats(model, test_dataset, evaluate=True)
    # print("real test loss, corr, r2",  testloss, testcorr, testr2) 
    # best_epoch_loss = epoch if testloss < best_loss else best_epoch_loss
    # best_loss = testloss if testloss < best_loss else best_loss
    # best_epoch_corr = epoch if testcorr > best_corr else best_epoch_corr
    # best_corr = testcorr if testcorr > best_corr else best_corr
    # best_epoch_r2 = epoch if testr2 > best_r2 else best_epoch_r2
    # best_r2 = testr2 if testr2 > best_r2 else best_r2
    # print("best_loss, best_epoch_loss, best_corr, best_epoch_corr, best_r2, best_epoch_r2", best_loss, best_epoch_loss, best_corr, best_epoch_corr, best_r2, best_epoch_r2)
    
