from args import args
from plistlib import load
from re import T
import torch
import torch.nn as nn
import stock

import numpy as np
import tqdm
import logger
import wandb
import models
import torch.utils.benchmark as benchmark
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
torch.set_default_dtype(torch.float32)
epochs = 1000
lr = args.lr
from stock import StockEnv, abs_profit, mean_profit, std_profit, exist, y0, vari
import datetime
args.temp = 1
max_r2 = 0
max_r2_itr = -1
min_l = 0
min_l_itr = -1
max_test2_r2 = 0
max_test2_r2_itr = -1
corr_test2_r2 = 0
max_p = -1
max_p_itr = -1
corr_p = 0
from numba import jit

import torch
torch.manual_seed(0)
import random
random.seed(0)
import numpy as np
np.random.seed(0)
def mean(l):
    return sum(l)/len(l)

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def assign_learning_rate(optimizer, new_lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = new_lr
interval = int(1e4)
def calculate_train_RLd3_34(model, dataset, rlbuy_profit_path, rlsell_profit_path, valid_sellpoint, valid_buypoint, step=0, tag="train", rand_number=str(args.seed)):
    model = model.actor
    model.eval()
    args.eval = True
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_hat_total = torch.zeros((dataset.data_X.size(0), args.d_num)).cuda()
    y_hat_total_shrink = torch.zeros((len(dataset), args.d_num)).cuda()
    with torch.no_grad():
        start, end = 0, 0
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x = x.cuda()
            out = model(x).squeeze()
            end += out.size(0)
            y_hat_total[index] = out
            y_hat_total_shrink[start:end] = out
            start = end
    
    for j in range(args.d_num-1):
        print("buy portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, :args.d_num], axis=1) == j)/y_hat_total_shrink.size(0))
        # print("sell portition", j, torch.sum(torch.argmax(y_hat_total_shrink[:, args.d_num:], axis=1) == j)/y_hat_total_shrink.size(0))

    y_hat_total = y_hat_total.detach().cpu()
    
    p_sum1, lines_p1, line_chosen_p1 = calculate_profit(y_hat_total, rlbuy_profit_path, valid_sellpoint, valid_buypoint, "buy", step, tag=tag, rand_number=rand_number)
    # p_sum2, lines_p2, line_chosen_p2 = calculate_profit(y_hat_total[:, args.d_num:], rlsell_profit_path, valid_sellpoint, valid_buypoint, "sell", step, tag=tag, rand_number=rand_number)
    # wandb.log({tag+"/profit_constrained_all": p_sum1+p_sum2}, step=step)
    # wandb.log({tag+"/profit_constrained_buy": p_sum1}, step=step)
    # wandb.log({tag+"/profit_constrained_sell": p_sum2}, step=step)


    for lag in range(args.start, args.lag):
        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(0, args.d_num-1):
                ax1.plot(lines_p1[lag][j][::interval]+lines_p2[lag][j][::interval])
            ax1.plot(line_chosen_p1[lag][::interval] + line_chosen_p2[lag][::interval])
            plt.legend()
            plt.show()
            plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_"+str(lag+1)+"_position"+str(args.pos)+".png")  
            plt.clf()
    if args.draw:
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)

        for j in range(args.start, args.d_num-1):
            ax1.plot(lines_p1[0][j][::interval]+lines_p2[0][j][::interval]+lines_p1[1][j][::interval]+lines_p2[1][j][::interval])
        ax1.plot(line_chosen_p1[0][::interval] + line_chosen_p2[0][::interval] + line_chosen_p1[1][::interval] + line_chosen_p2[1][::interval])
        plt.legend()
        plt.show()
        plt.savefig("result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfixall"+args.rand_number+"_"+str(args.rand_number0)+"_123position"+str(args.pos)+".png")
        plt.clf()
    return p_sum1

def calculate_profit(y_hat_total, rl_profit_path, valid_sellpoint_path, valid_buypoint_path, type_, step, tag="test", rand_number="0"):
    p_d_sum = {i:0 for i in range(0, args.d_num-1)}
    p_sum = []
    y_total_123 = None
    chosen_value_total_123 = None
    max_total_123 = None
    lines_lag, line_chosen_lag, lines_position_lag, line_chosen_position_lag, y_total_lag, chosen_value_total_lag = [], [], [], [], [], []

    for lag in range(1, args.lag+1):
        y0 = np.load(rl_profit_path+"_"+str(lag)+".npy")
        y_total = torch.from_numpy(y0)
        print("----------For ", tag, type_, lag, "----------")
        chosen_value_total = y_total.gather(1, torch.argmax(y_hat_total, axis=1).unsqueeze(1)).squeeze()
        max_total = torch.max(y_total, axis=1)[0]
        chosen_value_total_lag.append(chosen_value_total)
        lines = np.cumsum(y0, axis=0)
        lines_lag.append(lines)

        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(args.start, args.d_num):
                ax1.plot(lines[::interval, j])
            
            line_chosen = np.cumsum(chosen_value_total.cpu().detach().numpy())
            line_chosen_lag.append(line_chosen)
            ax1.plot(line_chosen[::interval])

            plt.legend()
            plt.show()
            plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+".png")

        lines_position = []
        

            
        # for j in range(6):
        #     print(torch.sum(torch.argmax(y_hat_total, axis=1) == j)/y_hat_total.size(0))

        if lag == 1:
            y_total_123 = y_total
            chosen_value_total_123 = chosen_value_total
            max_total_123 = max_total
        else:
            y_total_123 = y_total + y_total_123
            chosen_value_total_123 = chosen_value_total + chosen_value_total_123
            max_total_123 = max_total + max_total_123

        if type_ == "buy":
            valid_sellpoint = np.load(valid_sellpoint_path+"_"+str(lag)+".npy")
            for thres in range(0, 1, 1):
                for pos in [args.pos, 10000]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = temp_chosen_total.cpu().detach().numpy()
                    p, profit_chosen, pos_dict = calculate_profit_with_chosen(valid_sellpoint, temp_chosen_total, position=pos, lag=lag)
                    profit_chosen_pt = torch.from_numpy(profit_chosen).cuda()
                    nonzero_mask = (profit_chosen_pt!=0)
                    print("chosen buy, pos, p, thres", pos, p, thres, (torch.sum(profit_chosen_pt)/(-torch.sum(torch.clamp(profit_chosen_pt, max=0))+1e-20)).item(), (torch.mean(profit_chosen_pt[nonzero_mask])/(1e-20+torch.std(profit_chosen_pt[nonzero_mask]))).item())
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
                    # exit(-1)

                    if thres == 0 and pos == args.pos:
                        p_sum.append(p)  
                        torch.save(pos_dict, "pos_dict.pttestbuy"+str(lag)+str(args.rand_number))
                        line_chosen_postion = np.cumsum(profit_chosen)
                    if args.wandb:
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean_chosen"+str(args.pos): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max_chosen"+str(args.pos): max(pos_dict)}, step=step)
            for pos in [args.pos]:
                for j in range(0, args.d_num-1): 
                    p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, y0[:, j], position=pos, lag=lag)
                    profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
                    nonzero_mask = (profit_fix_position_pt!=0)
                    print("fix buy, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item())
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
                    if args.wandb:
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean"+str(j): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max"+str(j): max(pos_dict)}, step=step) 
                    p_d_sum[j] += p
                    lines_position.append(np.cumsum(profit_fix_position))
            p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_sellpoint, np.max(y0, axis=1), position=pos, lag=lag)
            profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
            nonzero_mask = (profit_fix_position_pt!=0)
            print("max buy, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item())
            print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   
        if type_ == "sell":
            valid_buypoint = np.load(valid_buypoint_path+"_"+str(lag)+".npy")
            for thres in range(0, 1, 1):
                for pos in [args.pos, 10000]:
                    masking_matrix = (torch.max(y_hat_total, axis=1)[0] > float(thres)/100).float()
                    temp_chosen_total = chosen_value_total * masking_matrix
                    temp_chosen_total = temp_chosen_total.cpu().detach().numpy()
                    p, profit_chosen, pos_dict = calculate_profit_with_chosen(valid_buypoint, temp_chosen_total, position=pos, lag=lag)
                    profit_chosen_pt = torch.from_numpy(profit_chosen).cuda()
                    nonzero_mask = (profit_chosen_pt!=0)
                    print("chosen sell, pos, p, thres", pos, p, thres, (torch.sum(profit_chosen_pt)/(-torch.sum(torch.clamp(profit_chosen_pt, max=0))+1e-20)).item(), (torch.mean(profit_chosen_pt[nonzero_mask])/(1e-20+torch.std(profit_chosen_pt[nonzero_mask]))).item())    
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict))   


                    if thres == 0 and pos == args.pos:
                        p_sum.append(p)  
                        torch.save(pos_dict, "pos_dict.pttestsell"+str(lag)+str(args.rand_number))
                        line_chosen_postion = np.cumsum(profit_chosen)
                    if args.wandb:
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean_chosen"+str(args.pos): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max_chosen"+str(args.pos): max(pos_dict)}, step=step)

            for pos in [args.pos]:
                for j in range(0, args.d_num-1): 
                    p, profit_fix_position, pos_dict = calculate_profit_with_chosen(valid_buypoint, y0[:, j], position=pos, lag=lag)
                    profit_fix_position_pt = torch.from_numpy(profit_fix_position).cuda()
                    nonzero_mask = (profit_fix_position_pt!=0)
                    print("fix sell, pos, j, p", pos, j, p, (torch.sum(profit_fix_position_pt)/(-torch.sum(torch.clamp(profit_fix_position_pt, max=0))+1e-20)).item(), (torch.mean(profit_fix_position_pt[nonzero_mask])/(1e-20+torch.std(profit_fix_position_pt[nonzero_mask]))).item()) 
                    print("pos dict mean, max", sum(pos_dict)/len(pos_dict), max(pos_dict), sum(pos_dict), len(pos_dict), )  
                    if args.wandb: 
                        wandb.log({tag+str(type_)+str(lag)+"/pos_mean"+str(j): sum(pos_dict)/len(pos_dict)}, step=step)
                        wandb.log({tag+str(type_)+str(lag)+"/pos_max"+str(j): max(pos_dict)}, step=step) 
                    p_d_sum[j] += p
                    lines_position.append(np.cumsum(profit_fix_position))

        if args.draw:
            fig, ax1 = plt.subplots()
            fig.set_figwidth(16)
            fig.set_figheight(12)
            for j in range(args.start, args.d_num-1):
                ax1.plot(lines_position[j][::interval])
            ax1.plot(line_chosen_postion[::interval])
            plt.legend()
            plt.show()
            plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_"+str(lag)+"position"+str(args.pos)+".png")
            lines_position_lag.append(lines_position)
            line_chosen_position_lag.append(line_chosen_postion)
        if args.wandb: 
            for j in range(0, 6):
                wandb.log({tag+str(type_)+str(lag)+"/profit-loss"+str(j): torch.sum(y_total[:, j]).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/(profit-loss~loss)"+str(j): (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/profit"+str(j): (torch.sum(torch.clamp(y_total[:, j], min=0))).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/loss"+str(j): (-torch.sum(torch.clamp(y_total[:, j], max=0))).item()}, step=step)
                wandb.log({tag+str(type_)+str(lag)+"/sharpe"+str(j): (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item()}, step=step)

            wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_chosen": (torch.sum(chosen_value_total)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_max": (torch.sum(max_total)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_chosen": (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_max": (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/profit_chosen": (torch.sum(torch.clamp(chosen_value_total, min=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/profit_max": (torch.sum(torch.clamp(max_total, min=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/loss_chosen": (-torch.sum(torch.clamp(chosen_value_total, max=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/loss_max": (-torch.sum(torch.clamp(max_total, max=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/sharpe chosen": (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/sharpe max": (torch.mean(max_total)/(1e-20+torch.std(max_total))).item()}, step=step)


        
        
        for j in range(0, args.d_num-1): 
            print(torch.nonzero(y_total[:, j]).size(), y_total[:, j].size())
            tmp = torch.index_select(y_total[:, j], 0, torch.nonzero(y_total[:, j]).squeeze())
            print(tmp.size(), tmp.std())
            print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total[:, j]).item(), (torch.sum(y_total[:, j])/(-torch.sum(torch.clamp(y_total[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total[:, j], max=0))).item(), (torch.mean(y_total[:, j])/(1e-20+torch.std(y_total[:, j]))).item(), torch.std(y_total[:, j]).item())
        tmp = torch.index_select(chosen_value_total, 0, torch.nonzero(chosen_value_total).squeeze())
        print(tmp.size(), tmp.std())
        
        print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total)).item(), (torch.sum(chosen_value_total)/(-torch.sum(torch.clamp(chosen_value_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total, max=0))).item(), (torch.mean(chosen_value_total)/(1e-20+torch.std(chosen_value_total))).item(), torch.std(chosen_value_total).item())
        tmp = torch.index_select(max_total, 0, torch.nonzero(max_total).squeeze())
        print(tmp.size(), tmp.std())
        print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total)).item(), (torch.sum(max_total)/(-torch.sum(torch.clamp(max_total, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total, min=0))).item(), (-torch.sum(torch.clamp(max_total, max=0))).item(), (torch.mean(max_total)/(1e-20+torch.std(max_total))).item(), torch.std(max_total).item())
    
    if args.draw:
        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)
        for j in range(args.start, args.d_num-1):
            if args.lag == 2:
                ax1.plot(lines_lag[0][::interval, j]+lines_lag[1][::interval, j])
            else:
                ax1.plot(lines_lag[0][::interval, j]+lines_lag[1][::interval, j]+lines_lag[2][::interval, j])
        if args.lag == 2:
            ax1.plot(line_chosen_lag[0][::interval]+line_chosen_lag[1][::interval])
        else:
            ax1.plot(line_chosen_lag[0][::interval]+line_chosen_lag[1][::interval]+line_chosen_lag[2][::interval])

        plt.legend()
        plt.show()
        plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123"+".png")
        plt.clf()

        fig, ax1 = plt.subplots()
        fig.set_figwidth(16)
        fig.set_figheight(12)

        for j in range(args.start, args.d_num-1):
            if args.lag == 2:
                ax1.plot(lines_position_lag[0][j][::interval]+lines_position_lag[1][j][::interval])
            else:
                ax1.plot(lines_position_lag[0][j][::interval]+lines_position_lag[1][j][::interval]+lines_position_lag[2][j][::interval])
        if args.lag == 2:
            ax1.plot(line_chosen_position_lag[0][::interval]+line_chosen_position_lag[1][::interval])
        else:
            ax1.plot(line_chosen_position_lag[0][::interval]+line_chosen_position_lag[1][::interval]+line_chosen_position_lag[2][::interval])
        plt.legend()
        plt.show()
        plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"RLfix"+type_+rand_number+"_123position"+str(args.pos)+".png")
        plt.clf()
    if args.wandb:
        lag = 123
        for j in range(0, args.d_num-1):
            wandb.log({tag+str(type_)+str(lag)+"/profit-loss"+str(j): torch.sum(y_total_123[:, j]).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/(profit-loss~loss)"+str(j): (torch.sum(y_total_123[:, j])/(-torch.sum(torch.clamp(y_total_123[:, j], max=0))+1e-20)).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/profit"+str(j): (torch.sum(torch.clamp(y_total_123[:, j], min=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/loss"+str(j): (-torch.sum(torch.clamp(y_total_123[:, j], max=0))).item()}, step=step)
            wandb.log({tag+str(type_)+str(lag)+"/sharpe"+str(j): (torch.mean(y_total_123[:, j])/(1e-20+torch.std(y_total_123[:, j]))).item()}, step=step)

        wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_chosen": (torch.sum(chosen_value_total_123)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/(profit-loss)_max": (torch.sum(max_total_123)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_chosen": (torch.sum(chosen_value_total_123)/(-torch.sum(torch.clamp(chosen_value_total_123, max=0))+1e-20)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/((profit-loss~loss))_max": (torch.sum(max_total_123)/(-torch.sum(torch.clamp(max_total_123, max=0))+1e-20)).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/profit_chosen": (torch.sum(torch.clamp(chosen_value_total_123, min=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/profit_max": (torch.sum(torch.clamp(max_total_123, min=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/loss_chosen": (-torch.sum(torch.clamp(chosen_value_total_123, max=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/loss_max": (-torch.sum(torch.clamp(max_total_123, max=0))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/sharpe chosen": (torch.mean(chosen_value_total_123)/(1e-20+torch.std(chosen_value_total_123))).item()}, step=step)
        wandb.log({tag+str(type_)+str(lag)+"/sharpe max": (torch.mean(max_total_123)/(1e-20+torch.std(max_total_123))).item()}, step=step)


    print("Profit comparison chosen", sum(p_sum))
    if args.wandb:
        wandb.log({tag+str(type_)+str(lag)+"/profit123 chosen": sum(p_sum)}, step=step)

    for j in range(0, args.d_num-1): 
        print("Profit comparison d", j, p_d_sum[j])
        if args.wandb:
            wandb.log({tag+str(type_)+str(lag)+"/profit123"+str(j): p_d_sum[j]}, step=step)



    for j in range(0, args.d_num-1): 
        print("d=", j, "profit-loss, (profit-loss/loss), profit, loss, sharpe", torch.sum(y_total_123[:, j]).item(), (torch.sum(y_total_123[:, j])/(-torch.sum(torch.clamp(y_total_123[:, j], max=0))+1e-20)).item(), (torch.sum(torch.clamp(y_total_123[:, j], min=0))).item(), (-torch.sum(torch.clamp(y_total_123[:, j], max=0))).item(), (torch.mean(y_total_123[:, j])/(1e-20+torch.std(y_total_123[:, j]))).item())
    print("(profit-loss)_chosen, ((profit-loss/loss))_chosen, profit_chosen, loss_chosen, sharpe max", (torch.sum(chosen_value_total_123)).item(), (torch.sum(chosen_value_total_123)/(-torch.sum(torch.clamp(chosen_value_total_123, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(chosen_value_total_123, min=0))).item(), (-torch.sum(torch.clamp(chosen_value_total_123, max=0))).item(), (torch.mean(chosen_value_total_123)/(1e-20+torch.std(chosen_value_total_123))).item())
    print("(profit-loss)_max, ((profit-loss/loss))_max, profit_max, loss_max, sharpe chosen", (torch.sum(max_total_123)).item(), (torch.sum(max_total_123)/(-torch.sum(torch.clamp(max_total_123, max=0))+1e-20)).item(),  (torch.sum(torch.clamp(max_total_123, min=0))).item(), (-torch.sum(torch.clamp(max_total_123, max=0))).item(), (torch.mean(max_total_123)/(1e-20+torch.std(max_total_123))).item())

    return sum(p_sum), lines_position_lag, line_chosen_position_lag

def train(model, loader, opt, epoch):
    global max_r2, max_r2_itr, min_l, min_l_itr, max_test2_r2_itr, max_test2_r2, corr_test2_r2, max_p, max_p_itr, corr_p
    model.train()
    pg_loss_meter = logger.AverageMeter("pg_loss", ":.3f")
    ratio_meter = logger.AverageMeter("ratio", ":.3f")
    v_loss_meter = logger.AverageMeter("v_loss", ":.3f")
    v_loss_term_meter = logger.AverageMeter("v_loss * args.vf_coef", ":.3f")
    entropy_loss_meter = logger.AverageMeter("entropy_loss", ":.3f")
    entropy_loss_term_meter = logger.AverageMeter("args.ent_coef * entropy_loss", ":.3f")

    l = [pg_loss_meter, ratio_meter, v_loss_meter, v_loss_term_meter, entropy_loss_meter, entropy_loss_term_meter]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Train Epoch: [{epoch}]")
    # old_train_dataset = stock.StockAggregate35("train")
    # i = 0
    # p_ = 0
    # p2_ = calculate_train_RLd3_34(model, old_train_dataset, args.rlbuy_profit_path, args.rlsell_profit_path, args.valid_2ndsellpoint, args.valid_2ndbuypoint, step=epoch*len(loader)+i, tag="train")
    # # p_ = calculate_train_RLd3_32(model, test_dataset, args.rlbuy_profit_path2, args.rlsell_profit_path2, args.valid_2ndsellpoint2, args.valid_2ndbuypoint2, step=epoch*len(loader)+i, tag="test")
    # if p_ >= max_p:
    #     max_p = p_
    #     max_p_itr = epoch*len(loader)+i
    #     torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    # torch.save(model, "results/last_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    # print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
    for i, (b_obs, b_logprobs, b_actions, b_advantages, b_returns, b_values) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
        model.train()
        b_obs, b_logprobs, b_actions, b_advantages, b_returns, b_values = b_obs.cuda(), b_logprobs.cuda(), b_actions.cuda(), b_advantages.cuda(), b_returns.cuda(), b_values.cuda()
        opt.zero_grad()
        # print("why unmatch",b_obs.size())
        _, newlogprob, entropy, newvalue = model.get_action_and_value(b_obs, b_actions.long())
        logratio = newlogprob - b_logprobs
        ratio = logratio.exp()

        pg_loss1 = -b_advantages * ratio
        pg_loss2 = -b_advantages * torch.clamp(ratio, 1 - args.clip_coef, 1 + args.clip_coef)
        pg_loss = torch.max(pg_loss1, pg_loss2).mean()

        # Value loss
        newvalue = newvalue.reshape(-1)
        if args.clip_vloss:
            v_loss_unclipped = (newvalue - b_returns) ** 2
            v_clipped = b_values + torch.clamp(
                newvalue - b_values,
                -args.clip_coef,
                args.clip_coef,
            )
            v_loss_clipped = (v_clipped - b_returns) ** 2
            v_loss_max = torch.max(v_loss_unclipped, v_loss_clipped)
            v_loss = 0.5 * v_loss_max.mean()
        else:
            v_loss = 0.5 * ((newvalue - b_returns) ** 2).mean()

        entropy_loss = entropy.mean()
        loss = pg_loss - args.ent_coef * entropy_loss + v_loss * args.vf_coef
        print("ratio.mean.item()", ratio.mean().item())
        pg_loss_meter.update(pg_loss.item(), b_obs.size(0))
        ratio_meter.update(ratio.mean().item(), b_obs.size(0))
        v_loss_meter.update(v_loss.item(), b_obs.size(0))
        v_loss_term_meter.update(v_loss.item()* args.vf_coef, b_obs.size(0))
        entropy_loss_meter.update(entropy_loss.item(), b_obs.size(0))
        entropy_loss_term_meter.update(- args.ent_coef * entropy_loss.item(), b_obs.size(0))

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
        opt.step()
        if "RL" in args.arch:
            if i % 200 == 0:
                progress.display(i) 
        # if i % (len(loader)-1) == 0 and i != 0:
        #     old_train_dataset = stock.StockAggregate35("train")
        #     old_test_dataset = stock.StockAggregate35("test")

        #     p_ = 0
        #     p2_ = calculate_train_RLd3_34(model, old_train_dataset, args.rlbuy_profit_path, args.rlsell_profit_path, args.valid_2ndsellpoint, args.valid_2ndbuypoint, step=epoch*len(loader)+i, tag="train")
        #     p_ = calculate_train_RLd3_34(model, old_test_dataset, args.rlbuy_profit_path2, args.rlsell_profit_path2, args.valid_2ndsellpoint2, args.valid_2ndbuypoint2, step=epoch*len(loader)+i, tag="test")
        #     if p_ >= max_p:
        #         max_p = p_
        #         max_p_itr = epoch*len(loader)+i
        #         torch.save(model, "results/best_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
        #     torch.save(model, "results/last_model_RL"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
        #     print("max_p_itr, max_p, rand_number", max_p_itr, max_p, args.rand_number)
    return 0, 0, 0


@jit
def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]

                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin+1] < position:
                    total_profit += chosen_vt[vb]
                    # profit_position[vb] = chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]

                    # deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    return total_profit, profit_position, positions_dict  

# @jit
# def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1):
#     # print(valid_sellpoint)
#     chosen_vt = chosen_value_total
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     # profit_positions = [0 for i in range(len(valid_sellpoint))]
#     # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

#     valid_buypoint = (chosen_vt != 0).nonzero()[0]
#     # for i in range(len(chosen_vt)):
#         # print(chosen_vt[i])
#     profit_position = np.zeros(len(chosen_vt))
#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
#                 return i, True

#     total_profit = 0
#     # print(len(valid_buypoint))
#     deferred_positions = [(0, 0)]
#     deferred_positions = deferred_positions[1:]
#     for vb in valid_buypoint:
#         i = 0
#         retained_items = []
#         for i in range(len(deferred_positions)):
#             if vb >= deferred_positions[i][1]:
#                 positions_dict[deferred_positions[i][0]] += 1
#             else:
#                 retained_items.append(deferred_positions[i])
#         deferred_positions = retained_items
#         # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += chosen_vt[vb]
#                     # profit_position[vb] = chosen_vt[vb]
#                     profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]

#                     deferred_positions.append((bin, vb + lag))
#                     # print(deferred_positions)

#             else:
#                 if positions_dict[bin] < position:
#                     total_profit += chosen_vt[vb]
#                     # profit_position[vb] = chosen_vt[vb]
#                     profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]

#                     deferred_positions.append((bin, vb + lag))
#                     deferred_positions.append((bin+1, vb + lag))
#                     # print(deferred_positions)
#         else:
#             print(vb, valid_sellpoint[-1], valid_sellpoint)
#             print("why larger")
#         # if vb > 10000:
#             # break
#     return total_profit, profit_position, positions_dict  
model = models.__dict__[args.arch]()
model = model.cuda()
print("number of parameters:", count_parameters(model))
print(model)


bn_params = [v for n, v in list(model.named_parameters()) if ("bn" in n) and v.requires_grad]
rest_params = [v for n, v in list(model.named_parameters()) if ("bn" not in n) and v.requires_grad]

opt = torch.optim.AdamW([
    {
        "params": bn_params,
        "weight_decay": 0 if args.no_bn_decay else args.wd,
    },
    {"params": rest_params, "weight_decay": args.wd},
], lr=lr, weight_decay = args.wd)

from random import randrange
args.rand_number = str(randrange(1e6))

import gym


def make_env(fulltest=False, i=0):
    def thunk():
        env = stock.StockEnv(fulltest, i)
        return env
    return thunk

envs = gym.vector.SyncVectorEnv(
    [make_env()] * args.num_envs,
)

obs = torch.zeros((args.num_steps, args.num_envs, args.input_size, args.T))
actions = torch.zeros((args.num_steps, args.num_envs))
logprobs = torch.zeros((args.num_steps, args.num_envs))
rewards = torch.zeros((args.num_steps, args.num_envs))
dones = torch.zeros((args.num_steps, args.num_envs))
values = torch.zeros((args.num_steps, args.num_envs))

envs.reset()
ob = torch.Tensor(envs.reset()).cuda()
done = torch.zeros(args.num_envs)
num_envs = args.num_envs
for epoch in range(epochs):
    model.eval()
    envs0 = gym.vector.SyncVectorEnv(
        [make_env(True, i) for i in range(num_envs)],
    )
    ob0 = torch.Tensor(envs0.reset()).cuda()
    reward_sum = 0
    reward_l = []
    running_steps = 0
    mask = np.ones((args.num_envs,))
    pre_traj_index = np.zeros((args.num_envs, 1))
    for step in range(0, 4000000):
        print(step)
        with torch.no_grad():
            action, _, _, _ = model.get_action_and_value(ob0, argmax=True)
        # print("action.size(), logprob.size(), value.size()", action.size(), logprob.size(), value.size())
        # print("action", step, action)
        # print(action.size(), action.cpu().numpy().shape)
        ob0, reward, done0, info = envs0.step(action.cpu().numpy())
        # print(reward)
        ob0 = torch.Tensor(ob0).cuda()
        # print("reward, done, info", reward, done, info)
        for i in range(len(info)):
            if info[i]["traj_index"] < pre_traj_index[i]:
                # print(i, info[i]["traj_index"], pre_traj_index[i])
                mask[i] = 0 
            pre_traj_index[i] = info[i]["traj_index"]
        # print("before", reward_sum, np.sum(reward), mask, np.sum(mask*reward), reward.shape, mask.shape)
        reward_sum += np.sum(mask*reward)
        # print(reward_sum, mask, reward, pre_traj_index)
        # print("after", reward_sum, np.sum(reward), mask, np.sum(mask*reward), np.sum(mask), np.max(pre_traj_index), (reward_sum * stock.std_profit + stock.mean_profit)*stock.abs_profit)
        # exit(-1)
        if np.sum(mask) == 0:
            # print(step)
            break
        # if ob0 == "False":
        #     break
        # else:
        #     # print((reward * stock.std_profit + stock.mean_profit)*stock.abs_profit, info)
        #     reward_sum += (reward.astype(float) * stock.std_profit + stock.mean_profit)*stock.abs_profit
    running_steps = step
    print("for argmax sampler:", (reward_sum * stock.std_profit + stock.mean_profit)*stock.abs_profit, ((reward_sum * stock.std_profit + stock.mean_profit)*stock.abs_profit)/running_steps)
    
    # envs0 = stock.StockEnv(True)
    # ob0 = torch.Tensor(envs0.reset()).cuda()
    # reward_sum = 0
    # reward_l = []
    # running_steps = 0
    
    # for step in range(0, 4000000):
    #     with torch.no_grad():
    #         action, _, _, _ = model.get_action_and_value(ob0.unsqueeze(0).cuda())
    #     # print("action.size(), logprob.size(), value.size()", action.size(), logprob.size(), value.size())
    #     # print("action", step, action)
    #     ob0, reward, done, info = envs0.step(action.cpu().numpy())
        
    #     # print("reward, done, info", reward, done, info)
    #     if ob0 == "False":
    #         break
    #     else:
    #         # print((reward * stock.std_profit + stock.mean_profit)*stock.abs_profit, info)
    #         reward_sum += (reward.astype(float) * stock.std_profit + stock.mean_profit)*stock.abs_profit
    #         # reward_l.append((reward.astype(float) * stock.std_profit + stock.mean_profit)*stock.abs_profit)
    # running_steps = step
    # print("for random sampler:", reward_sum, reward_sum/running_steps)
    # # print(reward_l)


    for step in range(0, args.num_steps):
        obs[step] = ob.detach().cpu()
        dones[step] = done 
        with torch.no_grad():
            action, logprob, _, value = model.get_action_and_value(ob)
        # print("action.size(), logprob.size(), value.size()", action.size(), logprob.size(), value.size())
        # print("action, logprob, value", action, logprob, value)
        values[step] = value.flatten()
        actions[step] = action
        logprobs[step] = logprob
        ob, reward, done, info = envs.step(action.cpu().numpy())
        # print("ob, reward, done, info", ob, reward, done, info)
        rewards[step] = torch.tensor(reward).cuda().view(-1)
        ob, done = torch.Tensor(ob).cuda(), torch.Tensor(done)
        # print("ob.size(), done.size()", ob.size(), done.size())
        # print("ob, done", ob, done)
    with torch.no_grad():
        next_value = model.get_value(ob).reshape(args.num_envs).detach().cpu()
        if args.gae:
            advantages = torch.zeros_like(rewards)
            lastgaelam = 0
            for t in reversed(range(args.num_steps)):
                if t == args.num_steps - 1:
                    nextnonterminal = 1.0 - done
                    nextvalues = next_value
                else:
                    nextnonterminal = 1.0 - dones[t + 1]
                    nextvalues = values[t + 1]
                delta = rewards[t] + args.gamma * nextvalues * nextnonterminal - values[t]
                advantages[t] = lastgaelam = delta + args.gamma * args.gae_lambda * nextnonterminal * lastgaelam
            returns = advantages + values
        else:
            returns = torch.zeros_like(rewards)
            for t in reversed(range(args.num_steps)):
                if t == args.num_steps - 1:
                    nextnonterminal = 1.0 - done
                    next_return = next_value
                else:
                    nextnonterminal = 1.0 - dones[t + 1]
                    next_return = returns[t + 1]
                returns[t] = rewards[t] + args.gamma * nextnonterminal * next_return
            advantages = returns - values
    print("rewards, values", rewards.mean(), (rewards.mean() * stock.std_profit + stock.mean_profit)*stock.abs_profit, running_steps* (rewards.mean() * stock.std_profit + stock.mean_profit)*stock.abs_profit, values.mean())
    b_obs = obs.reshape((-1, args.input_size, args.T))
    b_logprobs = logprobs.reshape(-1)
    b_actions = actions.reshape(-1)
    b_advantages = advantages.reshape(-1)
    b_returns = returns.reshape(-1)
    b_values = values.reshape(-1)

    if args.norm_adv:
        print("b_advantages.mean(), b_advantages.std()", b_advantages.mean(), b_advantages.std())
        b_advantages = (b_advantages - b_advantages.mean()) / (b_advantages.std() + 1e-8)

    train_dataset = stock.StockAggregate34(b_obs, b_logprobs, b_actions, b_advantages, b_returns, b_values)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=8, pin_memory=True)
    print(len(train_loader))
    train(model, train_loader, opt, epoch)
    
