from typing import Optional, Any
import math

import torch
from torch import nn, Tensor
from torch.nn import functional as F
from torch.nn.modules import MultiheadAttention, Linear, Dropout, BatchNorm1d, TransformerEncoderLayer
from args import args
from torch.distributions.normal import Normal

def model_factory(config, data):
    task = config['task']
    feat_dim = data.feature_df.shape[1]  # dimensionality of data features
    # data windowing is used when samples don't have a predefined length or the length is too long
    max_seq_len = config['data_window_len'] if config['data_window_len'] is not None else config['max_seq_len']
    if max_seq_len is None:
        try:
            max_seq_len = data.max_seq_len
        except AttributeError as x:
            print("Data class does not define a maximum sequence length, so it must be defined with the script argument `max_seq_len`")
            raise x
    print("max_seq_len", max_seq_len)
    if (task == "imputation") or (task == "transduction"):
        if config['model'] == 'LINEAR':
            return DummyTSTransformerEncoder(feat_dim, max_seq_len, config['d_model'], config['num_heads'],
                                             config['num_layers'], config['dim_feedforward'], dropout=config['dropout'],
                                             pos_encoding=config['pos_encoding'], activation=config['activation'],
                                             norm=config['normalization_layer'], freeze=config['freeze'])
        elif config['model'] == 'transformer':
            return TSTransformerEncoder(feat_dim, max_seq_len, config['d_model'], config['num_heads'],
                                        config['num_layers'], config['dim_feedforward'], dropout=config['dropout'],
                                        pos_encoding=config['pos_encoding'], activation=config['activation'],
                                        norm=config['normalization_layer'], freeze=config['freeze'])

    if (task == "classification") or (task == "regression"):
        num_labels = len(data.class_names) if task == "classification" else data.labels_df.shape[1]  # dimensionality of labels
        if config['model'] == 'LINEAR':
            return DummyTSTransformerEncoderClassiregressor(feat_dim, max_seq_len, config['d_model'],
                                                            config['num_heads'],
                                                            config['num_layers'], config['dim_feedforward'],
                                                            num_classes=num_labels,
                                                            dropout=config['dropout'], pos_encoding=config['pos_encoding'],
                                                            activation=config['activation'],
                                                            norm=config['normalization_layer'], freeze=config['freeze'])
        elif config['model'] == 'transformer':
            return TSTransformerEncoderClassiregressor(feat_dim, max_seq_len, config['d_model'],
                                                        config['num_heads'],
                                                        config['num_layers'], config['dim_feedforward'],
                                                        num_classes=num_labels,
                                                        dropout=config['dropout'], pos_encoding=config['pos_encoding'],
                                                        activation=config['activation'],
                                                        norm=config['normalization_layer'], freeze=config['freeze'])
    else:
        raise ValueError("Model class for task '{}' does not exist".format(task))


def _get_activation_fn(activation):
    if activation == "relu":
        return F.relu
    elif activation == "gelu":
        return F.gelu
    raise ValueError("activation should be relu/gelu, not {}".format(activation))


# From https://github.com/pytorch/examples/blob/master/word_language_model/model.py
class FixedPositionalEncoding(nn.Module):
    r"""Inject some information about the relative or absolute position of the tokens
        in the sequence. The positional encodings have the same dimension as
        the embeddings, so that the two can be summed. Here, we use sine and cosine
        functions of different frequencies.
    .. math::
        \text{PosEncoder}(pos, 2i) = sin(pos/10000^(2i/d_model))
        \text{PosEncoder}(pos, 2i+1) = cos(pos/10000^(2i/d_model))
        \text{where pos is the word position and i is the embed idx)
    Args:
        d_model: the embed dim (required).
        dropout: the dropout value (default=0.1).
        max_len: the max. length of the incoming sequence (default=1024).
    """

    def __init__(self, d_model, dropout=0.1, max_len=1024, scale_factor=1.0):
        super(FixedPositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)  # positional encoding
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = scale_factor * pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)  # this stores the variable in the state_dict (used for non-trainable variables)

    def forward(self, x):
        r"""Inputs of forward function
        Args:
            x: the sequence fed to the positional encoder model (required).
        Shape:
            x: [sequence length, batch size, embed dim]
            output: [sequence length, batch size, embed dim]
        """

        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)


class LearnablePositionalEncoding(nn.Module):

    def __init__(self, d_model, dropout=0.1, max_len=1024):
        super(LearnablePositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        # Each position gets its own embedding
        # Since indices are always 0 ... max_len, we don't have to do a look-up
        self.pe = nn.Parameter(torch.empty(max_len, 1, d_model))  # requires_grad automatically set to True
        nn.init.uniform_(self.pe, -0.02, 0.02)

    def forward(self, x):
        r"""Inputs of forward function
        Args:
            x: the sequence fed to the positional encoder model (required).
        Shape:
            x: [sequence length, batch size, embed dim]
            output: [sequence length, batch size, embed dim]
        """

        x = x + self.pe
        return self.dropout(x)


def get_pos_encoder(pos_encoding):
    if pos_encoding == "learnable":
        return LearnablePositionalEncoding
    elif pos_encoding == "fixed":
        return FixedPositionalEncoding

    raise NotImplementedError("pos_encoding should be 'learnable'/'fixed', not '{}'".format(pos_encoding))


class TransformerBatchNormEncoderLayer(nn.modules.Module):
    r"""This transformer encoder layer block is made up of self-attn and feedforward network.
    It differs from TransformerEncoderLayer in torch/nn/modules/transformer.py in that it replaces LayerNorm
    with BatchNorm.

    Args:
        d_model: the number of expected features in the input (required).
        nhead: the number of heads in the multiheadattention models (required).
        dim_feedforward: the dimension of the feedforward network model (default=2048).
        dropout: the dropout value (default=0.1).
        activation: the activation function of intermediate layer, relu or gelu (default=relu).
    """

    def __init__(self, d_model, nhead, dim_feedforward=2048, dropout=0.1, activation="relu"):
        super(TransformerBatchNormEncoderLayer, self).__init__()
        self.self_attn = MultiheadAttention(d_model, nhead, dropout=dropout)
        # Implementation of Feedforward model
        self.linear1 = Linear(d_model, dim_feedforward)
        self.dropout = Dropout(dropout)
        self.linear2 = Linear(dim_feedforward, d_model)

        self.norm1 = BatchNorm1d(d_model, eps=1e-5)  # normalizes each feature across batch samples and time steps
        self.norm2 = BatchNorm1d(d_model, eps=1e-5)
        self.dropout1 = Dropout(dropout)
        self.dropout2 = Dropout(dropout)

        self.activation = _get_activation_fn(activation)

    def __setstate__(self, state):
        if 'activation' not in state:
            state['activation'] = F.relu
        super(TransformerBatchNormEncoderLayer, self).__setstate__(state)

    def forward(self, src: Tensor, src_mask: Optional[Tensor] = None,
                src_key_padding_mask: Optional[Tensor] = None) -> Tensor:
        r"""Pass the input through the encoder layer.

        Args:
            src: the sequence to the encoder layer (required).
            src_mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).

        Shape:
            see the docs in Transformer class.
        """
        src2 = self.self_attn(src, src, src, attn_mask=src_mask,
                              key_padding_mask=src_key_padding_mask)[0]
        src = src + self.dropout1(src2)  # (seq_len, batch_size, d_model)
        src = src.permute(1, 2, 0)  # (batch_size, d_model, seq_len)
        # src = src.reshape([src.shape[0], -1])  # (batch_size, seq_length * d_model)
        src = self.norm1(src)
        src = src.permute(2, 0, 1)  # restore (seq_len, batch_size, d_model)
        src2 = self.linear2(self.dropout(self.activation(self.linear1(src))))
        src = src + self.dropout2(src2)  # (seq_len, batch_size, d_model)
        src = src.permute(1, 2, 0)  # (batch_size, d_model, seq_len)
        src = self.norm2(src)
        src = src.permute(2, 0, 1)  # restore (seq_len, batch_size, d_model)
        return src


class TSTransformerEncoderPretrained(nn.Module):

    def __init__(self):
        feat_dim = args.input_size
        max_len = args.T
        d_model = args.dim
        n_heads = args.nhead
        num_layers = args.nlayers
        dim_feedforward = args.dim_feedforward
        dropout = args.dropout
        pos_encoding = "learnable"
        activation='gelu'
        norm='BatchNorm'
        freeze=False
        
        super(TSTransformerEncoderPretrained, self).__init__()
        self.max_len = max_len
        self.d_model = d_model
        self.n_heads = n_heads

        self.project_inp = nn.Linear(feat_dim, d_model)
        self.pos_enc = get_pos_encoder(pos_encoding)(d_model, dropout=dropout*(1.0 - freeze), max_len=max_len)

        if norm == 'LayerNorm':
            encoder_layer = TransformerEncoderLayer(d_model, self.n_heads, dim_feedforward, dropout*(1.0 - freeze), activation=activation)
        else:
            encoder_layer = TransformerBatchNormEncoderLayer(d_model, self.n_heads, dim_feedforward, dropout*(1.0 - freeze), activation=activation)

        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.output_layer = nn.Linear(d_model, feat_dim)

        self.act = _get_activation_fn(activation)

        self.dropout1 = nn.Dropout(dropout)

        self.feat_dim = feat_dim

    def forward(self, x):
        inp = x.permute(2, 0, 1)  
        inp = self.project_inp(inp) * math.sqrt(self.d_model) 
        inp = self.pos_enc(inp) 
        output = self.transformer_encoder(inp) 
        output = self.act(output)  
        output = output.permute(1, 0, 2)
        output = self.dropout1(output)
        output = self.output_layer(output).permute(0, 2, 1)
        return output


class TSTransformerEncoderClassiregressor(nn.Module):
    """
    Simplest classifier/regressor. Can be either regressor or classifier because the output does not include
    softmax. Concatenates final layer embeddings and uses 0s to ignore padding embeddings in final output layer.
    """

    def __init__(self):
        super(TSTransformerEncoderClassiregressor, self).__init__()
        feat_dim = args.input_size
        max_len = args.T
        d_model = args.dim
        n_heads = args.nhead
        num_layers = args.nlayers
        dim_feedforward = args.dim_feedforward
        num_classes = 1
        dropout = args.dropout
        pos_encoding = "learnable"
        activation='gelu'
        norm='BatchNorm'
        freeze=False
        self.max_len = max_len
        self.d_model = d_model
        self.n_heads = n_heads

        self.project_inp = nn.Linear(feat_dim, d_model)
        self.pos_enc = get_pos_encoder(pos_encoding)(d_model, dropout=dropout*(1.0 - freeze), max_len=max_len)

        encoder_layer = TransformerBatchNormEncoderLayer(d_model, self.n_heads, dim_feedforward, dropout*(1.0 - freeze), activation=activation)

        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.act = _get_activation_fn(activation)

        self.dropout1 = nn.Dropout(dropout)

        self.feat_dim = feat_dim
        self.num_classes = num_classes
        self.output_layer = nn.Linear(d_model * max_len, num_classes)


    def forward(self, x):
        inp = x.permute(2, 0, 1)  
        inp = self.project_inp(inp) * math.sqrt(self.d_model) 
        inp = self.pos_enc(inp) 
        output = self.transformer_encoder(inp) 
        output = self.act(output)  
        output = output.permute(1, 0, 2) 
        output = self.dropout1(output)
        output = output.reshape(output.shape[0], -1) 
        output = self.output_layer(output)
        return output



class TSTransformerEncoderRL(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRL, self).__init__()
        feat_dim = args.input_size
        max_len = args.T
        d_model = args.dim
        n_heads = args.nhead
        num_layers = args.nlayers
        dim_feedforward = args.dim_feedforward
        num_classes = args.d_num
        dropout = args.dropout
        pos_encoding = "learnable"
        activation='gelu'
        norm='BatchNorm'
        freeze=False
        self.max_len = max_len
        self.d_model = d_model
        self.n_heads = n_heads

        self.project_inp = nn.Linear(feat_dim, d_model)
        self.pos_enc = get_pos_encoder(pos_encoding)(d_model, dropout=dropout*(1.0 - freeze), max_len=max_len)

        encoder_layer = TransformerBatchNormEncoderLayer(d_model, self.n_heads, dim_feedforward, dropout*(1.0 - freeze), activation=activation)

        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.act = _get_activation_fn(activation)

        self.dropout1 = nn.Dropout(dropout)

        self.feat_dim = feat_dim
        self.num_classes = num_classes
        self.output_layer = nn.Linear(d_model * max_len, num_classes)


    def forward(self, x):
        
        inp = x.permute(2, 0, 1)  
        inp = self.project_inp(inp) * math.sqrt(self.d_model) 
        inp = self.pos_enc(inp) 
        output = self.transformer_encoder(inp) 
        output = self.act(output)  
        output = output.permute(1, 0, 2) 
        output = self.dropout1(output)
        output = output.reshape(output.shape[0], -1) 
        output = self.output_layer(output)
        if args.gumbel:
            U = torch.rand(output.size(0), output.size(1), args.K).cuda()
            U = -torch.log(-torch.log(U + 1e-10) + 1e-10)
            # output = torch.nn.functional.gumbel_softmax(output, tau=1, hard=False, eps=1e-10, dim=-1)
            output1 = F.softmax((output.unsqueeze(-1) + U)*args.temp, dim=1)
            _, ind = output1.max(dim=1)
            # print(ind.size(), ind)
            output_hard = F.one_hot(ind, 7).permute(0, 2, 1)
            # print(output_hard.size(), output_hard)
            output = (output_hard - output1).detach() + output1
            # print(output, output.size())
            # exit(-1)
        else:
            output = torch.nn.Softmax(dim=1)(output*args.temp)
            # if args.eval:
            #     output = F.one_hot(torch.multinomial(output, 1), 7)
            #     print(output.size(), output)
        if output.size()[-1] == 1:
            return output.reshape(output.size(0), output.size(1))
        else:
            return output


class TSTransformerEncoderRLSub(nn.Module):
    def __init__(self, d_num):
        super(TSTransformerEncoderRLSub, self).__init__()
        feat_dim = args.input_size
        max_len = args.T
        d_model = args.dim
        n_heads = args.nhead
        num_layers = args.nlayers
        dim_feedforward = args.dim_feedforward
        num_classes = d_num
        dropout = args.dropout
        pos_encoding = "learnable"
        activation='gelu'
        norm='BatchNorm'
        freeze=False
        self.max_len = max_len
        self.d_model = d_model
        self.n_heads = n_heads

        self.project_inp = nn.Linear(feat_dim, d_model)
        self.pos_enc = get_pos_encoder(pos_encoding)(d_model, dropout=dropout*(1.0 - freeze), max_len=max_len)

        encoder_layer = TransformerBatchNormEncoderLayer(d_model, self.n_heads, dim_feedforward, dropout*(1.0 - freeze), activation=activation)

        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers)

        self.act = _get_activation_fn(activation)

        self.dropout1 = nn.Dropout(dropout)

        self.feat_dim = feat_dim
        self.num_classes = num_classes
        self.output_layer = nn.Linear(d_model * max_len, num_classes)


    def forward(self, x):
        inp = x.permute(2, 0, 1)
        inp = self.project_inp(inp) * math.sqrt(self.d_model) 
        inp = self.pos_enc(inp) 
        output = self.transformer_encoder(inp) 
        output = self.act(output)  
        output = output.permute(1, 0, 2) 
        output = self.dropout1(output)
        output = output.reshape(output.shape[0], -1) 
        output = self.output_layer(output)
        return output

from torch.distributions.categorical import Categorical

class TSTransformerEncoderRLSeq(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq, self).__init__()
        self.actor = TSTransformerEncoderRLSub(d_num=7)
        self.critic = TSTransformerEncoderRLSub(d_num=1)

    def get_action_and_value(self, x, action=None, argmax=False):
        logits = self.actor(x)
        probs = Categorical(logits=logits)
        if action is None:
            action = probs.sample()
        if argmax:
            action = torch.argmax(logits, axis=1)
        return action, probs.log_prob(action), probs.entropy(), self.critic(x)

    def get_value(self, x):
        return self.critic(x)

class TSTransformerEncoderRLSeq2(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq2, self).__init__()
        self.actor = TSTransformerEncoderRLSub(d_num=7)

    def get_action(self, x, action=None, argmax=False):
        logits = self.actor(x)
        probs = Categorical(logits=logits)
        if action is None:
            action = probs.sample()
        if argmax:
            action = torch.argmax(logits, axis=1)
        return action, probs.log_prob(action)

import numpy as np
def layer_init(layer, std=np.sqrt(2), bias_const=0.0):
    torch.nn.init.orthogonal_(layer.weight, std)
    torch.nn.init.constant_(layer.bias, bias_const)
    return layer

class TSTransformerEncoderRLSeq3(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq3, self).__init__()
        if args.indep_std:
            self.actor_meanstd = TSTransformerEncoderRLSub(d_num=2)
        else:
            self.actor_mean = TSTransformerEncoderRLSub(d_num=1)
            self.actor_logstd = nn.Parameter(torch.zeros(1, 1))
            if args.linear_init:
                self.actor_mean.output_layer = layer_init(self.actor_mean.output_layer, bias_const=3)
        

    def get_action(self, x, action=None, argmax=False):
        if args.indep_std:
            action_meanstd = self.actor_meanstd(x)
            action_mean = action_meanstd[:, 0].unsqueeze(-1)
            action_logstd = torch.clamp(action_meanstd[:, 1].unsqueeze(-1), max=1.5)
            # print(action_meanstd.size(), action_mean.size(), action_logstd.size())
        else:
            action_mean = self.actor_mean(x)
            action_logstd = self.actor_logstd.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        if args.take_normal:
            probs = Normal(action_mean, action_std)
        elif args.take_logistic:
            base_distribution = torch.distributions.uniform.Uniform(torch.zeros(action_mean.shape).cuda(), torch.ones(action_mean.shape).cuda())
            transforms = [torch.distributions.transforms.SigmoidTransform().inv, torch.distributions.transforms.AffineTransform(loc=action_mean, scale=action_std)]
            probs = torch.distributions.TransformedDistribution(base_distribution, transforms)

            # probs = torch.distributions.LogitRelaxedBernoulli(temperature=1/scale, logits=loc/scale)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action = probs.sample()
        if argmax:
            action = action_mean
        
        # print(action_mean.size(), action_logstd.size(), action.size())
        if args.not_squeeze:
            return action, probs.log_prob(action).sum(1)
        else:
            return action.squeeze(), probs.log_prob(action).sum(1)


class TSTransformerEncoderRLSeq4(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq4, self).__init__()
        if args.learn_bias:
            self.actor_mean0 = TSTransformerEncoderRLSub(d_num=1)
            self.actor_mean1 = TSTransformerEncoderRLSub(d_num=1)
            self.actor_logstd = nn.Parameter(torch.zeros(1, 2))
        else:
            if args.indep_std:
                self.actor_meanstd = TSTransformerEncoderRLSub(d_num=2)
            else:
                self.actor_mean = TSTransformerEncoderRLSub(d_num=1)
                self.actor_logstd = nn.Parameter(torch.zeros(1, 1))
                if args.linear_init:
                    self.actor_mean.output_layer = layer_init(self.actor_mean.output_layer, bias_const=3)
        

    def get_action(self, x, action=None, argmax=False):
        if args.learn_bias:
            action_mean = torch.cat([self.actor_mean0(x), self.actor_mean1(x)], axis=1)
            action_logstd = self.actor_logstd.expand_as(action_mean)
        else:
            if args.indep_std:
                action_meanstd = self.actor_meanstd(x)
                action_mean = action_meanstd[:, 0].unsqueeze(-1)
                action_logstd = torch.clamp(action_meanstd[:, 1].unsqueeze(-1), max=1.5)
                # print(action_meanstd.size(), action_mean.size(), action_logstd.size())
            else:
                action_mean = self.actor_mean(x)
                action_logstd = self.actor_logstd.expand_as(action_mean)
            
        action_std = torch.exp(action_logstd) + 1e-20
        if args.take_normal:
            probs = Normal(action_mean, action_std)
        elif args.take_logistic:
            base_distribution = torch.distributions.uniform.Uniform(torch.zeros(action_mean.shape).cuda(), torch.ones(action_mean.shape).cuda())
            transforms = [torch.distributions.transforms.SigmoidTransform().inv, torch.distributions.transforms.AffineTransform(loc=action_mean, scale=action_std)]
            probs = torch.distributions.TransformedDistribution(base_distribution, transforms)

        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action = probs.sample()
        if argmax:
            action = action_mean
        return action.squeeze(), probs.log_prob(action).sum(1)
import math
class TSTransformerEncoderRLSeq5(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq5, self).__init__()
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_logstd0 = nn.Parameter(torch.zeros(1, 1))
        self.actor_logstd1 = nn.Parameter(torch.zeros(1, 1))

        if args.linear_init:
            self.actor_mean0.output_layer = layer_init(self.actor_mean0.output_layer, bias_const=args.bias_const)
            self.actor_mean1.output_layer = layer_init(self.actor_mean1.output_layer, bias_const=args.bias_const)
    
    def get_action0(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean0(x)
        action_logstd = self.actor_logstd0.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        if argmax:
            action = action_mean
        return action, probs.log_prob(action).sum(1)
        

    def get_action1(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean1(x)
        action_logstd = self.actor_logstd1.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        if argmax:
            action = action_mean
        return action, probs.log_prob(action).sum(1)

class TSTransformerEncoderRLSeq7(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq7, self).__init__()
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=args.d_num)
        self.actor_logstd0 = nn.Parameter(torch.zeros(1, 1))

    def get_action0(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean0(x)
        action_logstd = self.actor_logstd0.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if argmax:
            action = action_mean
            return action.unsqueeze(-1), probs.log_prob(action).sum(1).unsqueeze(-1)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        return action, probs.log_prob(action).sum(1)
        

    def get_action1(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean1(x)
        probs = Categorical(logits=logits)
        if argmax:
            action = torch.argmax(logits, axis=1)
            return action.unsqueeze(-1), probs.log_prob(action).unsqueeze(-1)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                # print(ri)
                action_i = probs.sample()
                # print(action_i)
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
                # print(probs.log_prob(action_i))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            # print(action.size(), probs.size())
            return action, probs
        return action, probs.log_prob(action)



class TSTransformerEncoderRLSeq75(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq75, self).__init__()
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=args.d_num)
        self.actor_logstd1 = nn.Parameter(torch.zeros(1, 1))

    def get_action1(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean1(x)
        action_logstd = self.actor_logstd1.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if argmax:
            action = action_mean
            return action.unsqueeze(-1), probs.log_prob(action).sum(1).unsqueeze(-1)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        return action, probs.log_prob(action).sum(1)

    def get_action0(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean0(x)
        probs = Categorical(logits=logits)
        if argmax:
            action = torch.argmax(logits, axis=1)
            return action.unsqueeze(-1), probs.log_prob(action).unsqueeze(-1)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                # print(ri)
                action_i = probs.sample()
                # print(action_i)
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
                # print(probs.log_prob(action_i))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            # print(action.size(), probs.size())
            return action, probs
        return action, probs.log_prob(action)

class TSTransformerEncoderRLSeq72(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq72, self).__init__()
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_logstd1 = nn.Parameter(torch.zeros(1, 1))
        self.actor_logstd0 = nn.Parameter(torch.zeros(1, 1))

    def get_action0(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean0(x)
        action_logstd = self.actor_logstd0.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if argmax:
            action = action_mean
            return action.unsqueeze(-1), probs.log_prob(action).sum(1).unsqueeze(-1)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        return action, probs.log_prob(action).sum(1)
        

    def get_action1(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean1(x)
        action_logstd = self.actor_logstd1.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if argmax:
            action = action_mean
            return action.unsqueeze(-1), probs.log_prob(action).sum(1).unsqueeze(-1)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        return action, probs.log_prob(action).sum(1)

class TSTransformerEncoderRLSeq73(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq73, self).__init__()
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_mean2 = TSTransformerEncoderRLSub(d_num=2)
        self.actor_mean3 = TSTransformerEncoderRLSub(d_num=2)
        
        # torch.nn.init.constant_(self.actor_mean0.output_layer.bias, 1.386)
        # torch.nn.init.constant_(self.actor_mean1.output_layer.bias, 1.386)

        self.actor_logstd1 = nn.Parameter(torch.zeros(1, 1))
        self.actor_logstd0 = nn.Parameter(torch.zeros(1, 1))

    def get_action0(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean0(x)
        action_logstd = self.actor_logstd0.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if argmax:
            action = action_mean
            return action.unsqueeze(-1), probs.log_prob(action).sum(1).unsqueeze(-1)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        return action, probs.log_prob(action).sum(1)
        
    def get_action2(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean2(x)
        probs = Categorical(logits=logits)
        if argmax:
            action = torch.argmax(logits, axis=1)
            return action.unsqueeze(-1), probs.log_prob(action).unsqueeze(-1)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                action_i = probs.sample()
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            return action, probs
        return action, probs.log_prob(action)

    def get_action1(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean1(x)
        action_logstd = self.actor_logstd1.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if argmax:
            action = action_mean
            return action.unsqueeze(-1), probs.log_prob(action).sum(1).unsqueeze(-1)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        return action, probs.log_prob(action).sum(1)

    def get_action3(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean3(x)
        probs = Categorical(logits=logits)
        if argmax:
            action = torch.argmax(logits, axis=1)
            return action.unsqueeze(-1), probs.log_prob(action).unsqueeze(-1)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                action_i = probs.sample()
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            return action, probs
        return action, probs.log_prob(action)


class TSTransformerEncoderRLSeq74(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq74, self).__init__()
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=1)
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=args.d_num)
        self.actor_mean2 = TSTransformerEncoderRLSub(d_num=2)
        self.actor_logstd0 = nn.Parameter(torch.zeros(1, 1))

    def get_action0(self, x, action=None, argmax=False, r=1):
        action_mean = self.actor_mean0(x)
        action_logstd = self.actor_logstd0.expand_as(action_mean)
        action_std = torch.exp(action_logstd) + 1e-20
        probs = Normal(action_mean, action_std)
        if argmax:
            action = action_mean
            return action.unsqueeze(-1), probs.log_prob(action).sum(1).unsqueeze(-1)
        if action is None:
            if args.take_mean:
                action = action_mean
            else:
                action_l = []
                probs_l = []
                for ri in range(r):
                    action_i = probs.sample()
                    action_l.append(action_i.unsqueeze(-1))
                    probs_l.append(probs.log_prob(action_i).sum(1).unsqueeze(-1))
                action = torch.cat(action_l, dim=-1)
                probs = torch.cat(probs_l, dim=-1)
                return action, probs
        return action, probs.log_prob(action).sum(1)
        
    def get_action2(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean2(x)
        probs = Categorical(logits=logits)
        if argmax:
            action = torch.argmax(logits, axis=1)
            return action.unsqueeze(-1), probs.log_prob(action).unsqueeze(-1)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                action_i = probs.sample()
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            return action, probs
        return action, probs.log_prob(action)

    def get_action1(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean1(x)
        probs = Categorical(logits=logits)
        if argmax:
            action = torch.argmax(logits, axis=1)
            return action.unsqueeze(-1), probs.log_prob(action).unsqueeze(-1)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                action_i = probs.sample()
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            return action, probs
        return action, probs.log_prob(action)

class TSTransformerEncoderRLSeq9(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq9, self).__init__()
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=7)
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=args.d_num)

    def get_action0(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean0(x)
        probs = Categorical(logits=logits)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                action_i = probs.sample()
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            return action, probs
        if argmax:
            action = torch.argmax(logits, axis=1)
        return action, probs.log_prob(action)

    def get_action1(self, x, action=None, argmax=False, r=1):
        logits = self.actor_mean1(x)
        probs = Categorical(logits=logits)
        if action is None:
            action_l = []
            probs_l = []
            for ri in range(r):
                action_i = probs.sample()
                action_l.append(action_i.unsqueeze(-1))
                probs_l.append(probs.log_prob(action_i).unsqueeze(-1))
            action = torch.cat(action_l, dim=-1)
            probs = torch.cat(probs_l, dim=-1)
            return action, probs
        if argmax:
            action = torch.argmax(logits, axis=1)
        return action, probs.log_prob(action)

class TSTransformerEncoderRLSeq6(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLSeq6, self).__init__()
        self.actor_mean0 = TSTransformerEncoderRLSub(d_num=7)
        self.actor_mean1 = TSTransformerEncoderRLSub(d_num=7)

    def get_action(self, x, action=None, argmax=False):
        logits0 = self.actor_mean0(x)
        probs0 = Categorical(logits=logits0)
        logits1 = self.actor_mean1(x)
        probs1 = Categorical(logits=logits1)
        if action is None:
            action0 = probs0.sample()
            action1 = probs1.sample()
            action = torch.cat([action0.unsqueeze(-1).float(), action1.unsqueeze(-1).float()], dim=1)
        if argmax:
            action0 = torch.argmax(logits0, axis=1)
            action1 = torch.argmax(logits1, axis=1)
            action = torch.cat([action0.unsqueeze(-1).float(), action1.unsqueeze(-1).float()], dim=1)


        # print(action0.size(), action1.size())
        return action, probs0.log_prob(action[:, 0]) + probs1.log_prob(action[:, 1]) 
           
        
class TSTransformerEncoderRLCombined(nn.Module):
    def __init__(self):
        super(TSTransformerEncoderRLCombined, self).__init__()
        self.m1 = TSTransformerEncoderRL()
        self.m2 = TSTransformerEncoderRL()

    def forward(self, x):
        out1 = self.m1(x)
        out2 = self.m2(x)
        # return torch.cat([out1, torch.zeros(out1.size(0), 1).cuda(), out2, torch.zeros(out1.size(0), 1).cuda()], dim=1)
        return torch.cat([out1, out2], dim=1)

    