start='2022-12-01'
end='2023-01-31'

start=$(date -d $start +%Y%m%d)
end=$(date -d $end +%Y%m%d)
filen="x_data"
while [[ $start -le $end ]]
do
        echo $(date -d $start +%m_%d)
        wdate=$(date -d $start +%m_%d)
        echo $wdate
        mv $filen/xnn5_$wdate.pkl $filen/xnn6_$wdate.pkl
        mv $filen/x2_$wdate.npy $filen/x3_$wdate.npy
        start=$(date -d"$start + 1 day" +"%Y%m%d")

done
