from args import args
from plistlib import load
from re import T
import torch
import torch.nn as nn
import stock
import numpy as np
import tqdm
import logger
import argparse
import wandb
import copy 
import models
import torch.utils.benchmark as benchmark
# import multiprocessing as mp

from torch.utils.data import Dataset, DataLoader
if args.old == 9:
    from torch.utils.data.sampler import WeightedRandomSampler
    from stock import wegihtedsampler

# mp.set_start_method('spawn')

torch.set_default_dtype(torch.float32)
epochs = 100
lr = args.lr
from stock import y_length_list
max_r2 = 0
max_r2_itr = -1

wandb.init(project="stock_prediction", config=args, name=args.name, entity="zhouuxx96")

def mean(l):
    return sum(l)/len(l)

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def assign_learning_rate(optimizer, new_lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = new_lr

def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.reshape(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

def calculate_real_stats(model, dataset, evaluate=True):
    if evaluate:
        model.eval()
    else:
        model.train()
    y_hat_total = torch.zeros(len(dataset)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_total = dataset.data_y[args.T - 1:].cuda()
    with torch.no_grad():
        for i, (x, y, index) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat_total[index] = model(x).squeeze().detach()
            # print(y_hat_total.nonzero().nelement())
        loss = ((y_total-y_hat_total)**2).mean().item()
        corr = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2 = (1-((y_total-y_hat_total)**2).sum()/((y_total-y_total.mean())**2).sum()).item()
    dataset.clean()

    return loss, corr, r2

def calculate_real_stats_test(model, dataset, evaluate=True, step=0):

    if evaluate:
        model.eval()
    else:
        model.train()
    y_hat_total = torch.zeros(len(dataset)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False,
                                             sampler=torch.utils.data.SequentialSampler(dataset),
                                             batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_total = dataset.data_y[args.T - 1:].cuda()
    with torch.no_grad():
        for i, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            if "Normal" not in args.arch:
                y_hat_total[index] = model(x).squeeze().detach()
            else:
                y_hat_total[index] = model(x)[:, 0].squeeze().detach()
            # print(y_hat_total.nonzero().nelement())
        loss_all = ((y_total - y_hat_total) ** 2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1 - ((y_total - y_hat_total) ** 2).sum() / ((y_total - y_total.mean()) ** 2).sum()).item()
        wandb.log({f"test_all/loss_all": loss_all}, step=step)
        wandb.log({f"test_all/corr_all": corr_all}, step=step)
        wandb.log({f"test_all/r2_all": r2_all}, step=step)
        length_to_date = 0
        loss_l, corr_l, r2_l = [], [], []
        for i, l in enumerate(y_length_list):
            length_to_date_end = length_to_date + l
            y_total_seg = y_total[length_to_date:length_to_date_end]
            y_hat_total_seg = y_hat_total[length_to_date:length_to_date_end]
            loss = ((y_total_seg - y_hat_total_seg) ** 2).mean().item()
            corr = abs(np.corrcoef(torch.cat((y_total_seg.unsqueeze(1), y_hat_total_seg.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2 = (1 - ((y_total_seg - y_hat_total_seg) ** 2).sum() / ((y_total_seg - y_total_seg.mean()) ** 2).sum()).item()
            length_to_date = length_to_date_end
            wandb.log({f"test/loss_" + str(i): loss}, step=step)
            wandb.log({f"test/corr_" + str(i): corr}, step=step)
            wandb.log({f"test/r2_" + str(i): r2}, step=step)
            print("day", i, loss, corr, r2)
            loss_l.append(loss)
            corr_l.append(corr)
            r2_l.append(r2)
        wandb.log({f"test/loss_avg": mean(loss_l)}, step=step)
        wandb.log({f"test/corr_avg": mean(corr_l)}, step=step)
        wandb.log({f"test/r2_avg": mean(r2_l)}, step=step)
    return mean(loss_l), mean(corr_l), mean(r2_l)

def calculate_test_pretrained(model, dataset, evaluate=True, step=0):
    if evaluate:
        model.eval()
    else:
        model.train()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    losses = logger.AverageMeter("Loss", ":.3f")
    progress = logger.ProgressMeter(len(loader_seq), [losses], prefix=f"Val Epoch: [{epoch}]")
    with torch.no_grad():
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y, mask = x.cuda(), y.cuda(), mask.cuda() 
            y_hat = model(x*mask).squeeze()
            loss = criterion(y_hat*(~mask), x*(~mask))
            losses.update(loss.item(), x.size(0))
            if i % 300 == 0:
                progress.display(i)
        progress.display(len(loader_seq))
        wandb.log({f"test/loss": losses.avg}, step=step)

from torchmetrics import ConfusionMatrix

def calculate_test_classification(model, dataset, evaluate=True, step=0):
    if evaluate:
        model.eval()
    else:
        model.train()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    losses = logger.AverageMeter("Loss", ":.3f")
    top1 = logger.AverageMeter("Acc@1", ":6.2f")
    top2 = logger.AverageMeter("Acc@2", ":6.2f")
    progress = logger.ProgressMeter(len(loader_seq), [losses, top1, top2], prefix=f"Val Epoch: [{epoch}]")
    y_hat_total = torch.zeros(len(dataset), 5).cuda()
    y_total = dataset.data_y[args.T - 1:].cuda().long()
    confmat = ConfusionMatrix(num_classes=5).cuda()
    with torch.no_grad():
        for i, (x, y, index, mask) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat = model(x).squeeze()
            loss = criterion(y_hat, y.long())
            losses.update(loss.item(), x.size(0))
            acc1, acc2 = accuracy(y_hat, y, topk=(1, 2))
            top1.update(acc1.item(), x.size(0))
            top2.update(acc2.item(), x.size(0))
            y_hat_total[index] = y_hat
            if i % 300 == 0:
                progress.display(i)
        print(confmat(y_hat_total, y_total))
        progress.display(len(loader_seq))
        wandb.log({f"test/loss": losses.avg}, step=step)
        wandb.log({f"test/top1": top1.avg}, step=step)
        wandb.log({f"test/top2": top2.avg}, step=step)

def train(model, criterion, loader, opt, epoch, g = None):
    global max_r2, max_r2_itr
    model.train()
    losses = logger.AverageMeter("Loss", ":.3f")
    corres = logger.AverageMeter("Corr", ":.3f")
    r2es = logger.AverageMeter("R2", ":.3f")
    top1 = logger.AverageMeter("Acc@1", ":6.2f")
    top2 = logger.AverageMeter("Acc@2", ":6.2f")
    l = [losses, corres, r2es, top1, top2]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Train Epoch: [{epoch}]")
    # x_start, y_start = None, None

    for i, (x, y, _, mask) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
        model.train()
        x, y = x.cuda(), y.cuda()
        if "Classification" in args.arch:
            y = y.long()
        if "Pretrained" in args.arch:
            mask = mask.cuda()
            y_true = x*(~mask)
            x = x*mask
        # print(x.shape)
        # if i == 0:
            # x_start, y_start = x, y
        # x, y = x_start, y_start
        # print(x.size(), y.size())
        if opt:
            opt.zero_grad()
        y_hat = model(x).squeeze()
        # print(x, y_hat, y)
        # exit(-1)
        # print(y_hat.size())

        # cos = nn.CosineSimilarity(dim=0, eps=1e-6)
        # loss = -torch.abs(cos(y_hat - y_hat.mean(dim=0, keepdim=True), y - y.mean(dim=0, keepdim=True)))
        # loss = -(1-((y-y_hat)**2).sum()/((y-y.mean())**2).sum())
        # if "Normal" not in args.arch:
        if "Pretrained" in args.arch:
            # print(y_hat*(~mask), y_true)
            loss = criterion(y_hat*(~mask), y_true)
        else:
            loss = criterion(y_hat, y)
        
        if "Classification" in args.arch:
            acc1, acc2 = accuracy(y_hat, y, topk=(1, 2))
            top1.update(acc1.item(), x.size(0))
            top2.update(acc2.item(), x.size(0))
            # print(loss, acc1, acc2)
        # else:
            # print(y_hat[:, 1].size(), torch.log(y_hat[:, 1]).size(), (y-y_hat[:, 0]).size(), y_hat[:, 1].size())
            # loss = torch.mean(torch.log(y_hat[:, 1]) + (y-y_hat[:, 0])**2/(y_hat[:, 1]))

        # loss /=2
        # print(loss)
        # print(torch.cat((y.unsqueeze(1), y_hat.unsqueeze(1)), 1))
        # corr = abs(np.corrcoef(torch.cat((y.unsqueeze(1), y_hat[:, 0].unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        if "Pretrained" in args.arch:
            losses.update(loss.item(), x.size(0))
        # corres.update(corr.item(), x.size(0))
        # r2 = 1-((y-y_hat[:, 0])**2).sum()/((y-y.mean())**2).sum()
        # r2es.update(r2.item(), x.size(0))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 3)
        if opt:
            opt.step()
        if "Pretrained" in args.arch or "Class" in args.arch:
            if i % 2000 == 0:
                progress.display(i) 
        
        if i % args.test_interval == 0 and i!=0:
            # loss, corr, r2 = calculate_real_stats(model, train_dataset)
            # wandb.log({f"train/loss": loss}, step=epoch*len(loader)+i)
            # wandb.log({f"train/corr": corr}, step=epoch*len(loader)+i)
            # wandb.log({f"train/r2": r2}, step=epoch*len(loader)+i)
            # print(loss, corr, r2)
            # loss, corr, r2 = calculate_real_stats(model, val_dataset)
            # wandb.log({f"val/loss": loss}, step=epoch*len(loader)+i)
            # wandb.log({f"val/corr": corr}, step=epoch*len(loader)+i)
            # wandb.log({f"val/r2": r2}, step=epoch*len(loader)+i)
            # print(loss, corr, r2)
            if "Pretrained" in args.arch:
                calculate_test_pretrained(model, test_dataset, step=epoch*len(loader)+i)
                wandb.log({f"train/loss": losses.avg}, step=epoch*len(loader)+i)
                print(args.rand_number)
                torch.save(model, "results/best_model_pretrained"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
            elif "Classification" in args.arch:
                calculate_test_classification(model, test_dataset, step=epoch*len(loader)+i)
                calculate_test_classification(model, train_dataset, step=epoch*len(loader)+i)
                wandb.log({f"train/loss": losses.avg}, step=epoch*len(loader)+i)
                wandb.log({f"train/top1": top1.avg}, step=epoch*len(loader)+i)
                wandb.log({f"train/top2": top2.avg}, step=epoch*len(loader)+i)
                print(args.rand_number)
                torch.save(model, "results/best_model_class"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")

            else:
                if args.old != 12:
                    l, c, r = calculate_real_stats_test(model, test_dataset, step=epoch*len(loader)+i)
                    if r > max_r2:
                        max_r2_itr = epoch*len(loader)+i
                        max_r2 = r
                        print("new_best!!!")
                        torch.save(model, "best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
                    print("max_r2_itr, max_r2", max_r2_itr, max_r2, args.rand_number)

        # progress.display(len(loader))
    # model_copy = copy.deepcopy(model).cpu()
    # corr = abs(np.corrcoef(torch.cat((train_dataset.data_y.unsqueeze(1), model_copy(train_dataset.data_X-train_dataset.mean).squeeze().unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
    # print("train corr???", corr)
    return 0, 0, 0

def validate(model, criterion, loader, epoch):
    model.eval()
    losses = logger.AverageMeter("Loss", ":.3f")
    corres = logger.AverageMeter("Corr", ":.3f")
    r2es = logger.AverageMeter("R2", ":.3f")
    l = [losses, corres, r2es]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Epoch: [{epoch}]")
    with torch.no_grad():
        for i, (x, y, _) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
            x, y = x.cuda(), y.cuda()
            y_hat = model(x).squeeze()
            loss = criterion(y_hat, y)
            corr = abs(np.corrcoef(torch.cat((y.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            losses.update(loss.item(), x.size(0))
            corres.update(corr.item(), x.size(0))
            r2 = 1 - ((y - y_hat) ** 2).sum() / ((y - y.mean()) ** 2).sum()
            r2es.update(r2.item(), x.size(0))
            if i % 700 == 0:
                progress.display(i)
        progress.display(len(loader))
    return losses.avg, corres.avg, r2es.avg

@torch.no_grad()
def run_inference(model: nn.Module,
                  input_tensor: torch.Tensor) -> torch.Tensor:

    return model.forward(input_tensor)

def test_time(model):
    # model = torch.quantization.quantize_dynamic(
    #     model, {nn.Conv1d, nn.LeakyReLU, nn.BatchNorm1d, nn.MaxPool1d, nn.LSTM, nn.Linear}, dtype=torch.qint8
    # )

    
    num_threads = 1
    num_warmups = 100
    num_repeats = 1000
    
    model.eval()
    input = torch.randn(1, 57, args.T).cuda()
    timer = benchmark.Timer(stmt="run_inference(model, input_tensor)",
                            setup="from __main__ import run_inference",
                            globals={
                                "model": model,
                                "input_tensor": input
                            },
                            num_threads=num_threads,
                            label="Latency Measurement",
                            sub_label="torch.utils.benchmark.")

    profile_result = timer.timeit(num_repeats)
    # https://pytorch.org/docs/stable/_modules/torch/utils/benchmark/utils/common.html#Measurement
    print(f"Latency: {profile_result.mean * 1000:.5f} ms")


    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    repetitions = 300
    for _ in range(10):
        y = model(input)
    starter.record()
    for rep in range(repetitions):
        y = model(input)
    ender.record()
    torch.cuda.synchronize()
    curr_time = starter.elapsed_time(ender)
    print(curr_time/repetitions)

def export_model(model):
    model.eval()
    input = torch.ones(1, 57, args.T).cuda()
    traced_script_module = torch.jit.trace(model, input)
    # traced_script_module = torch.jit.script(model)
    print(model(input))
    traced_script_module.save("trans0.pt")

def generate_test_predict(model, dataset):
    model.eval()
    y_hat_total = torch.zeros(len(dataset)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_total = dataset.data_y[args.T - 1:].cuda()
    
    with torch.no_grad():
        for i, (x, y, index, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat_total[index] = model(x).squeeze().detach()
        loss_all = ((y_total-y_hat_total)**2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1-((y_total-y_hat_total)**2).sum()/((y_total-y_total.mean())**2).sum()).item()
        print("all", loss_all, corr_all, r2_all)
        length_to_date = 0
        loss_l, corr_l, r2_l = [], [], []
        for i, l in enumerate(y_length_list):
            length_to_date_end = length_to_date + l
            y_total_seg = y_total[length_to_date:length_to_date_end]
            y_hat_total_seg = y_hat_total[length_to_date:length_to_date_end]
            loss = ((y_total_seg-y_hat_total_seg)**2).mean().item()
            corr = abs(np.corrcoef(torch.cat((y_total_seg.unsqueeze(1), y_hat_total_seg.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2 = (1-((y_total_seg-y_hat_total_seg)**2).sum()/((y_total_seg-y_total_seg.mean())**2).sum()).item()
            length_to_date = length_to_date_end
            print("day", i, loss, corr, r2)
            loss_l.append(loss)
            corr_l.append(corr)
            r2_l.append(r2)
    with open("data_7/y"+args.y+"_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+args.rand_number+".npy", 'wb') as f:
        np.save(f, y_hat_total.detach().cpu().numpy())
if args.old == 14:
    train_dataset = stock.StockAggregate14("train")    
    test_dataset = stock.StockAggregate14("test")
elif args.old == 12:
    train_dataset = stock.StockAggregate12("train")
elif args.old == 10:
    train_dataset = stock.StockAggregate10("train")
else:
    train_dataset = stock.StockAggregate("train")

if "Classification" in args.arch:
    if args.reweight:
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True, sampler=wegihtedsampler)
    else:
        train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True)

test_dataset.load_data_test()

if args.loss == "mse":
    criterion = nn.MSELoss()
elif args.loss == "l1":
    criterion = nn.L1Loss()
elif args.loss == "huber":
    criterion = nn.HuberLoss()
elif args.loss == "smoothl1":
    criterion = nn.SmoothL1Loss()
if "Classification" in args.arch:
    criterion = nn.CrossEntropyLoss()

if not args.linear:
    # model = nn.Sequential(nn.Linear(args.input_size, 256), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, 256), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, 1)).cuda()
    # model = nn.Sequential(nn.Linear(args.input_size, args.hidden), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(args.hidden), nn.ReLU(), nn.Linear(args.hidden, args.hidden), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(args.hidden), nn.ReLU(), nn.Linear(args.hidden, 1)).cuda()
    # model = CNN().cuda()
    model = models.__dict__[args.arch]()
    # model = torch.quantization.quantize_dynamic(
        # model, {nn.LSTM, nn.Linear}, dtype=torch.qint8
    # )
    model = model.cuda()
else:
    model = nn.Linear(args.input_size, 1, bias=False).cuda()

if args.generate_test_predict:
    # model = torch.load("best_model_y"+args.y+"_05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27_05_30-05_30;06_07-06_07;06_14-06_14;06_21-06_21.pt").cuda()
    print(args.valid)
    args.rand_number = str(args.seed)
    model = torch.load("results/best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+args.rand_number+".pt")
    # model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_copy.pt")
    generate_test_predict(model, test_dataset)
    exit(0)

if args.test_pretrained:
    # model = torch.load("best_model_y"+args.y+"_05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27_05_30-05_30;06_07-06_07;06_14-06_14;06_21-06_21.pt").cuda()
    print(args.valid)
    epoch = 0
    args.rand_number = str(args.seed)
    model = torch.load("results/best_model_pretrained"+args.arch+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    # model = torch.load("best_model_y"+args.arch+args.y+"_"+';'.join(args.train)+"_"+';'.join(args.valid)+"_copy.pt")
    calculate_test_pretrained(model, test_dataset)
    exit(0)

if args.test_time:
    test_time(model)
    export_model(model)
    exit(0)

if args.load_pretrained:
    args.rand_number = str(args.seed)
    pretrained_model = torch.load("results/best_model_pretrained"+"TSTransformerEncoderPretrained"+"_"+';'.join(args.train)+"_"+';'.join(args.test)+args.rand_number+".pt")
    print(pretrained_model)
    pretrained_state_dict = pretrained_model.state_dict()
    model_state_dict = model.state_dict()
    # print(model_state_dict.keys())
    for k, v in pretrained_state_dict.items():
        if k not in model_state_dict or v.size() != model_state_dict[k].size():
            if k not in model_state_dict:
                print("not in state dict")
            else:
                print("size not match")
            print("IGNORE:", k)
        else:
            print("LOAD:", k)
            
    pretrained_state_dict = {
        k: v
        for k, v in pretrained_state_dict.items()
        if (k in model_state_dict and v.size() == model_state_dict[k].size())
    }
    model_state_dict.update(pretrained_state_dict)
    model.load_state_dict(model_state_dict)
    for n, p in model.named_parameters():
        if n in pretrained_state_dict:
            print("Freeze", n)
            p.requires_grad = False
print("number of parameters:", count_parameters(model))
print(model)
bn_params = [v for n, v in list(model.named_parameters()) if ("bn" in n) and v.requires_grad]
rest_params = [v for n, v in list(model.named_parameters()) if ("bn" not in n) and v.requires_grad]
if args.opt == "sgd":
    opt = torch.optim.SGD([
        {
            "params": bn_params,
            "weight_decay": 0 if args.no_bn_decay else args.wd,
        },
        {"params": rest_params, "weight_decay": args.wd},
    ], lr=lr, momentum=0.9, weight_decay = args.wd)
elif args.opt == "adamw":
    if args.follow_attn:
        opt = torch.optim.AdamW([
            {
                "params": bn_params,
                "weight_decay": 0 if args.no_bn_decay else args.wd,
            },
            {"params": rest_params, "weight_decay": args.wd},
        ], lr=lr, weight_decay = args.wd, eps=1e-09, betas=(0.9, 0.98),)
    else:
        opt = torch.optim.AdamW([
            {
                "params": bn_params,
                "weight_decay": 0 if args.no_bn_decay else args.wd,
            },
            {"params": rest_params, "weight_decay": args.wd},
        ], lr=lr, weight_decay = args.wd)

elif args.opt == "adam":
    opt = torch.optim.Adam([
        {
            "params": bn_params,
            "weight_decay": 0 if args.no_bn_decay else args.wd,
        },
        {"params": rest_params, "weight_decay": args.wd},
    ], lr=lr, weight_decay = args.wd)




best_loss = 200
best_corr = -200
best_r2 = -200
best_epoch_loss = -1
best_epoch_corr = -1
best_epoch_r2 = -1
from random import randrange
args.rand_number = str(randrange(1e10))
for epoch in range(epochs):
    assign_learning_rate(opt, 0.5 * (1 + np.cos(np.pi * epoch / epochs)) * lr)
    train_dataset.resample()
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=20, pin_memory=True)
    trainloss, traincorr, trainr2 = train(model, criterion, train_loader, opt, epoch)
    train_dataset.clean()
    # trainloss, traincorr, trainr2 = calculate_real_stats(model, train_dataset, evaluate=True)
    # print("real train loss, corr, r2",  trainloss, traincorr, trainr2) 
    # valloss, valcorr, valr2 = validate(model, criterion, val_loader, epoch)
    # valloss, valcorr, valr2 = calculate_real_stats(model, val_dataset, evaluate=True)
    # print("real val loss, corr, r2",  valloss, valcorr, valr2) 
    # testloss, testcorr, testr2 = validate(model, criterion, test_loader, epoch)
    # testloss, testcorr, testr2 = calculate_real_stats(model, test_dataset, evaluate=True)
    # print("real test loss, corr, r2",  testloss, testcorr, testr2) 
    # best_epoch_loss = epoch if testloss < best_loss else best_epoch_loss
    # best_loss = testloss if testloss < best_loss else best_loss
    # best_epoch_corr = epoch if testcorr > best_corr else best_epoch_corr
    # best_corr = testcorr if testcorr > best_corr else best_corr
    # best_epoch_r2 = epoch if testr2 > best_r2 else best_epoch_r2
    # best_r2 = testr2 if testr2 > best_r2 else best_r2
    # print("best_loss, best_epoch_loss, best_corr, best_epoch_corr, best_r2, best_epoch_r2", best_loss, best_epoch_loss, best_corr, best_epoch_corr, best_r2, best_epoch_r2)
    