import pickle
import matplotlib.pyplot as plt

# with open('backtest_result.pickle', 'rb') as f:
#     d1 = pickle.load(f)

# with open('backtest_result_2.pickle', 'rb') as f:
#     d2 = pickle.load(f)

# dn = {**d1, **d2}
# print(dn)

# with open('backtest_result_615.pickle', 'wb') as f:
#     pickle.dump(dn, f)
# exit(-1)
# backtest_result_TSTransformerEncoderClassiregressor06_18-07_18_07_19-07_23_07_27-07_30
a = "backtest_result_TSTransformerEncoderClassiregressor05_24-07_28_07_29-07_31_08_01-08_032"
with open(a+'.pickle', 'rb') as f:
    dic = pickle.load(f)
# print(d)
# for d in [1.5, 2.5]:
for p in [10]:
    result = [[[[0]]for i in range(10)] for i in range(10)]
    x = []
    y = []
    z = []
    for k, v in dic.items():
        print(k[1])
        if k[1] == p and k[2] <= 0:
            x_i = k[0]
            y_i = k[2]
            z_i = v[2]
            x.append(x_i)
            y.append(y_i)
            z.append(z_i)
            print(x_i, y_i, z_i)
    print(x, y, z)

    from mpl_toolkits.mplot3d import Axes3D
    import matplotlib.pyplot as plt
    from matplotlib import cm
    import numpy as np
    from sys import argv


    fig = plt.figure()
    ax = Axes3D(fig)
    surf = ax.plot_trisurf(x, y, z, cmap=cm.jet, linewidth=0.1)
    # plt.title(a+"b:"+str(p)+"d:"+str(d))
    # plt.savefig('profit_'+a+str(p)+";"+str(d)+'.png')
    plt.title(a+"b:"+str(p))
    plt.savefig('profit_'+a[8:]+str(p)+'.png')
    plt.show()