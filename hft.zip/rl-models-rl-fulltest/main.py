from args import args
from plistlib import load
from re import T
import torch
import torch.nn as nn
import stock
import numpy as np
import tqdm
import logger
import argparse
import wandb
import copy 
from stock import y_length_list

torch.set_default_dtype(torch.float64)
epochs = 100
lr = args.lr

wandb.init(project="stock_prediction", config=args)

class CNNLSTM(nn.Module):
    def __init__(self):
        super().__init__()                
        self.inp1 = nn.Sequential(
            nn.Conv2d(in_channels=588, out_channels=64, kernel_size=(1,1)),
            nn.LeakyReLU(negative_slope=0.01),
            nn.BatchNorm2d(64),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(3,1), padding=(1, 0)),
            nn.LeakyReLU(negative_slope=0.01),
            nn.BatchNorm2d(64),
        )
        self.inp2 = nn.Sequential(
            nn.Conv2d(in_channels=588, out_channels=64, kernel_size=(1,1)),
            nn.LeakyReLU(negative_slope=0.01),
            nn.BatchNorm2d(64),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(5,1), padding=(2, 0)),
            nn.LeakyReLU(negative_slope=0.01),
            nn.BatchNorm2d(64),
        )
        self.inp3 = nn.Sequential(
            nn.MaxPool2d((3, 1), stride=(1, 1), padding=(1, 0)),
            nn.Conv2d(in_channels=588, out_channels=64, kernel_size=(1,1)),
            nn.LeakyReLU(negative_slope=0.01),
            nn.BatchNorm2d(64),
        )
        
        # lstm layers
        self.lstm = nn.LSTM(input_size=192, hidden_size=64, num_layers=1, batch_first=True)
        self.fc1 = nn.Linear(64, 1)

    def forward(self, x):
        # h0: (number of hidden layers, batch size, hidden size)
        h0 = torch.zeros(1, x.size(0), 64)
        c0 = torch.zeros(1, x.size(0), 64)
        
        x_inp1 = self.inp1(x)
        x_inp2 = self.inp2(x)
        x_inp3 = self.inp3(x)  
        
        x = torch.cat((x_inp1, x_inp2, x_inp3), dim=1)
        
#         x = torch.transpose(x, 1, 2)
        x = x.permute(0, 2, 1, 3)
        x = torch.reshape(x, (-1, x.shape[1], x.shape[2]))
        
        x, _ = self.lstm(x, (h0, c0))
        x = x[:, -1, :]
        x = self.fc1(x)
        
        return x

class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(args.input_size, args.hidden)
        self.dropout1 = nn.Dropout(args.dropout)
        self.bn1 = torch.nn.BatchNorm1d(args.hidden)
        self.fc2 = nn.Linear(args.hidden, args.hidden)
        self.dropout2 = nn.Dropout(args.dropout)
        self.bn2 = torch.nn.BatchNorm1d(args.hidden)
        self.fc3 = nn.Linear(args.hidden, 1)

    def forward(self, x):
        x = nn.ReLU()(self.bn1(self.dropout1(self.fc1(x))))
        x = self.fc3(nn.ReLU()(self.bn2(self.dropout2(self.fc2(x)))))
        return x

class MLP2(nn.Module):
    def __init__(self):
        super(MLP2, self).__init__()
        self.fc1 = nn.Linear(args.input_size, args.hidden)
        self.dropout1 = nn.Dropout(args.dropout)
        self.bn1 = torch.nn.BatchNorm1d(args.hidden)
        self.fc2 = nn.Linear(args.hidden, 1)
        # self.dropout2 = nn.Dropout(args.dropout)
        # self.bn2 = torch.nn.BatchNorm1d(args.hidden)
        # self.fc3 = nn.Linear(args.hidden, 1)

    def forward(self, x):
        x = nn.ReLU()(self.bn1(self.dropout1(self.fc1(x))))
        x = self.fc2(x)
        return x

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def assign_learning_rate(optimizer, new_lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = new_lr

def calculate_real_stats(model, dataset, evaluate=True):
    if evaluate:
        model.eval()
    else:
        model.train()
    y_hat_total = torch.zeros(len(dataset.data_X)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=10000, num_workers=10, pin_memory=True)
    y_total = dataset.data_y.cuda()
    with torch.no_grad():
        for i, (x, y, index) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            y_hat_total[index] = model(x).squeeze().detach()
            # print(y_hat_total.nonzero().nelement())
        length_to_date = 0
        for i in y_length_list:
            length_to_date_end += length_to_date + i
            y_total_seg = y_total[length_to_date:length_to_date_end]
            y_hat_total_seg = y_hat_total_seg[length_to_date:length_to_date_end]
            loss = ((y_total_seg-y_hat_total_seg)**2).mean().item()
            corr = abs(np.corrcoef(torch.cat((y_total_seg.unsqueeze(1), y_hat_total_seg.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2 = (1-((y_total_seg-y_hat_total_seg)**2).sum()/((y_total_seg-y_total_seg.mean())**2).sum()).item()
    return loss, corr, r2

def train(model, criterion, loader, opt, epoch, g = None):
    model.train()
    losses = logger.AverageMeter("Loss", ":.3f")
    corres = logger.AverageMeter("Corr", ":.3f")
    r2es = logger.AverageMeter("R2", ":.3f")
    l = [losses, corres, r2es]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Epoch: [{epoch}]")
    # x_start, y_start = None, None

    for i, (x, y, _) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
        model.train()
        x, y = x.cuda(), y.cuda()
        # print(x.shape)
        # if i == 0:
            # x_start, y_start = x, y
        # x, y = x_start, y_start
        # print(x.size(), y.size())
        if opt:
            opt.zero_grad()
        y_hat = model(x).squeeze()
        # print(x, y_hat, y)
        # exit(-1)
        # print(y_hat.size())

        # cos = nn.CosineSimilarity(dim=0, eps=1e-6)
        # loss = -torch.abs(cos(y_hat - y_hat.mean(dim=0, keepdim=True), y - y.mean(dim=0, keepdim=True)))
        # loss = -(1-((y-y_hat)**2).sum()/((y-y.mean())**2).sum())
        loss = criterion(y_hat, y)
        # loss /=2
        # print(loss)
        # print(torch.cat((y.unsqueeze(1), y_hat.unsqueeze(1)), 1))
        corr = abs(np.corrcoef(torch.cat((y.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        losses.update(loss.item(), x.size(0))
        corres.update(corr.item(), x.size(0))
        r2 = 1-((y-y_hat)**2).sum()/((y-y.mean())**2).sum()
        r2es.update(r2.item(), x.size(0))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 3)
        if opt:
            opt.step()
        if i % 700 == 0:
            progress.display(i)
        if i % 300 == 0:
            print(calculate_real_stats(model, test_dataset))
    progress.display(len(loader))
    # model_copy = copy.deepcopy(model).cpu()
    # corr = abs(np.corrcoef(torch.cat((train_dataset.data_y.unsqueeze(1), model_copy(train_dataset.data_X-train_dataset.mean).squeeze().unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
    # print("train corr???", corr)
    return losses.avg, corres.avg, r2es.avg

def validate(model, criterion, loader, epoch):
    model.eval()
    losses = logger.AverageMeter("Loss", ":.3f")
    corres = logger.AverageMeter("Corr", ":.3f")
    r2es = logger.AverageMeter("R2", ":.3f")
    l = [losses, corres, r2es]
    progress = logger.ProgressMeter(len(loader), l, prefix=f"Epoch: [{epoch}]")
    with torch.no_grad():
        for i, (x, y, _) in tqdm.tqdm(enumerate(loader), ascii=True, total=len(loader)):
            x, y = x.cuda(), y.cuda()
            y_hat = model(x).squeeze()
            loss = criterion(y_hat, y)
            corr = abs(np.corrcoef(torch.cat((y.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            losses.update(loss.item(), x.size(0))
            corres.update(corr.item(), x.size(0))
            r2 = 1 - ((y - y_hat) ** 2).sum() / ((y - y.mean()) ** 2).sum()
            r2es.update(r2.item(), x.size(0))
            if i % 700 == 0:
                progress.display(i)
        progress.display(len(loader))
    return losses.avg, corres.avg, r2es.avg

train_dataset = stock.Stock("train")
val_dataset = stock.Stock("val")
test_dataset = stock.Stock("test")

train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=512, shuffle=True, num_workers=10, pin_memory=True)
val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=1000, shuffle=False, num_workers=10, pin_memory=True)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=1000, shuffle=False, num_workers=10, pin_memory=True)

if not args.linear:
    # model = nn.Sequential(nn.Linear(args.input_size, 256), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, 256), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(256), nn.ReLU(), nn.Linear(256, 1)).cuda()
    # model = nn.Sequential(nn.Linear(args.input_size, args.hidden), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(args.hidden), nn.ReLU(), nn.Linear(args.hidden, args.hidden), torch.nn.Dropout(args.dropout), torch.nn.BatchNorm1d(args.hidden), nn.ReLU(), nn.Linear(args.hidden, 1)).cuda()
    model = MLP2().cuda()
else:
    model = nn.Linear(args.input_size, 1, bias=False).cuda()
print("number of parameters:", count_parameters(model))
print(model)
bn_params = [v for n, v in list(model.named_parameters()) if ("bn" in n) and v.requires_grad]
rest_params = [v for n, v in list(model.named_parameters()) if ("bn" not in n) and v.requires_grad]
if args.opt == "sgd":
    opt = torch.optim.SGD([
        {
            "params": bn_params,
            "weight_decay": 0 if args.no_bn_decay else args.wd,
        },
        {"params": rest_params, "weight_decay": args.wd},
    ], lr=lr, momentum=0.9, weight_decay = args.wd)
elif args.opt == "adamw":
    opt = torch.optim.AdamW([
        {
            "params": bn_params,
            "weight_decay": 0 if args.no_bn_decay else args.wd,
        },
        {"params": rest_params, "weight_decay": args.wd},
    ], lr=lr, weight_decay = args.wd)
elif args.opt == "adam":
    opt = torch.optim.Adam([
        {
            "params": bn_params,
            "weight_decay": 0 if args.no_bn_decay else args.wd,
        },
        {"params": rest_params, "weight_decay": args.wd},
    ], lr=lr, weight_decay = args.wd)


criterion = nn.MSELoss()

best_loss = 200
best_corr = -200
best_r2 = -200
best_epoch_loss = -1
best_epoch_corr = -1
best_epoch_r2 = -1

for epoch in range(epochs):
    assign_learning_rate(opt, 0.5 * (1 + np.cos(np.pi * epoch / epochs)) * lr)
    trainloss, traincorr, trainr2 = train(model, criterion, train_loader, opt, epoch)
    trainloss, traincorr, trainr2 = calculate_real_stats(model, train_dataset, evaluate=True)
    print("real train loss, corr, r2",  trainloss, traincorr, trainr2) 
    # valloss, valcorr, valr2 = validate(model, criterion, val_loader, epoch)
    # valloss, valcorr, valr2 = calculate_real_stats(model, val_dataset, evaluate=True)
    # print("real val loss, corr, r2",  valloss, valcorr, valr2) 
    testloss, testcorr, testr2 = validate(model, criterion, test_loader, epoch)
    testloss, testcorr, testr2 = calculate_real_stats(model, test_dataset, evaluate=True)
    print("real test loss, corr, r2",  testloss, testcorr, testr2) 
    best_epoch_loss = epoch if testloss < best_loss else best_epoch_loss
    best_loss = testloss if testloss < best_loss else best_loss
    best_epoch_corr = epoch if testcorr > best_corr else best_epoch_corr
    best_corr = testcorr if testcorr > best_corr else best_corr
    best_epoch_r2 = epoch if testr2 > best_r2 else best_epoch_r2
    best_r2 = testr2 if testr2 > best_r2 else best_r2
    print("best_loss, best_epoch_loss, best_corr, best_epoch_corr, best_r2, best_epoch_r2", best_loss, best_epoch_loss, best_corr, best_epoch_corr, best_r2, best_epoch_r2)
    wandb.log({f"train/loss": trainloss}, step=epoch)
    wandb.log({f"train/corr": traincorr}, step=epoch)
    wandb.log({f"train/r2": trainr2}, step=epoch)
    # wandb.log({f"val/loss": valloss}, step=epoch)
    # wandb.log({f"val/corr": valcorr}, step=epoch)
    # wandb.log({f"val/r2": valr2}, step=epoch)
    wandb.log({f"test/loss": testloss}, step=epoch)
    wandb.log({f"test/corr": testcorr}, step=epoch)
    wandb.log({f"test/r2": testr2}, step=epoch)