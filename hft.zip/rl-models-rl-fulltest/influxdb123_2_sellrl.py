#!/usr/bin/env python
# coding: utf-8

# In[ ]:
import numpy as np
import datetime
import matplotlib.dates as dates
from influxdb import DataFrameClient
import pandas as pd
from args import args
import os
import psutil
pd.set_option('display.max_rows', None)

count = psutil.cpu_count()
p = psutil.Process()

cpu_lst = p.cpu_affinity()
print(cpu_lst)
p.cpu_affinity([2,3,4,5,6,7])

def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

flist = genflist(args.test[0])
filename = "fu"
data = pd.DataFrame()
first = True
tmp_lst = []
for file in flist:
    tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
    tmp = pd.DataFrame(tmp, columns=['mid_fu', "predict1", 'ap1_fu', 'bp1_fu', 'sellpriceT_'+filename, 'buypriceT_'+filename])
    tmp_lst.append(tmp)
data = pd.concat(tmp_lst)
data['time'] = data.index

print(data.index)
ts = pd.Timestamp(2022, 12, 6, 8, 0, 0)
# ts = pd.Timestamp(2022, 11, 23, 20, 0, 0)

start = (data.index > ts).nonzero()[0][0]
# print(data.index[start:start+100])
te = pd.Timestamp(2022, 12, 7, 2, 0, 0)
# end = (data.index > te).nonzero()[0][0]
# print(data.index[end:end+100])
dout = 4
# data = data.iloc[start:end]
data = data
if args.type == "mk1":
    m1, m2 = 4, 2
    args.ip = "***.***.***.***"
    args.type_ = "sell"
elif args.type == "mk3":
    m1, m2 = 2, 4
    args.ip = "54.65.16.142"
    args.type_ = "buy"


#1: ***.***.***.***
#mk2, 3, 4: 54.65.16.142
# client = DataFrameClient('***.***.***.***', ******)
start_ = ts.to_datetime64().astype(int)//int(1e6)
end_ = te.to_datetime64().astype(int)//int(1e6)
print(start_, end_)
client = DataFrameClient(args.ip, ******)

result2 = client.query("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND (type='filled' OR type='partially_filled') AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
result2['order'].index.name='time'
raw2 = result2['order'].reset_index(level=0)
raw2['time'] = pd.to_datetime(raw2['time']).dt.tz_localize(None)
raw2.set_index('time')
del result2['order']
print(raw2)


data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
result = client.query("SELECT \"y0\" FROM \"model\" WHERE exchange='fu' AND pair='ETHUSDT' AND  type='transformer' AND account='"+str(args.type)+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
result['model'].index.name='time'
raw3 = result['model'].reset_index(level=0)
raw3['time'] = pd.to_datetime(raw3['time']).dt.tz_localize(None)
raw3 = raw3.set_index('time')
del result['model']

print(raw3.index)
tmp = np.zeros((len(raw2), ))
for i in range(0, len(raw2)):
    result = client.query("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='init' AND client_id='"+str(raw2.iloc[i]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
    result['order'].index.name='time'
    raw = result['order'].reset_index(level=0)
    raw['time'] = pd.to_datetime(raw['time']).dt.tz_localize(None)
    raw.set_index('time')
    tmp[i] = (raw2.iloc[i]['time']-raw.iloc[0]['time']).to_numpy()/1e6
    print(i, tmp[i], raw)
raw2['filled_time'] = pd.DataFrame(tmp, index=raw2.index)

print(raw2)
valid_sellpoint_l = {}
thres = 0.01


y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+args.test[0]+"8313747812.npy")
d = np.load("data_7/d"+args.type_+args.test[0]+args.seed+".npy")
print(d)

# data['predict1'] = pd.DataFrame(raw3['y0'].to_numpy(), index = data.index)
data['predict1'] = pd.DataFrame(y_predict0, index = data.index)
if args.type_ == "sell":
    sell_price = data['ap1_'+filename].to_numpy()*(1+d/1e4)
else:
    sell_price = data['ap1_'+filename].to_numpy()*(1+dout/1e4)
sell_price *= (1+np.clip(m1*data['predict1'].to_numpy()/1e4, 0, 20/1e4))

for lag2 in range(0, 15):
    tp = data['buypriceT_'+filename][lag2:].to_numpy()
    tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
    valid_sellpoint_l[lag2] = (np.logical_and(tp >= sell_price+thres, tp != 0))

if args.type_ == "buy":
    buy_price = data['bp1_'+filename].to_numpy()*(1-d/1e4)
else:
    buy_price = data['bp1_'+filename].to_numpy()*(1-dout/1e4)
buy_price *= (1+np.clip(m2*data['predict1'].to_numpy()/1e4, -20/1e4, 0))

valid_buypoint_l = {}
for lag in range(0, 15):
    tpb = data['sellpriceT_'+filename][lag:].to_numpy()
    tpb = np.concatenate([tpb, np.zeros(lag)], axis=0)
    valid_buypoint_l[lag] = (np.logical_and(tpb <= buy_price-thres, tpb != 0))


def get_items(restriction):
    result = client.query(restriction)
    if len(result) == 0:
        return 0
    result['order'].index.name='time'
    raw = result['order'].reset_index(level=0)
    raw['time'] = pd.to_datetime(raw['time']).dt.tz_localize(None)
    raw.set_index('time')
    return raw

success_num = 0
fail_num = 0
not_found_num = 0
for i in range(0, len(raw2)):
    print(len(raw2), fail_num, success_num, not_found_num)
    print("For filled i consider its validaity", raw2.iloc[i])
    result = client.query("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='init' AND client_id='"+str(raw2.iloc[i]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
    result['order'].index.name='time'
    raw = result['order'].reset_index(level=0)
    raw['time'] = pd.to_datetime(raw['time']).dt.tz_localize(None)
    raw.set_index('time')
    print("init_time", raw.iloc[0]['time'])
    print("filled_time", raw2.iloc[i]['time'])
    tmp = data.index.values.astype(int)
    start = np.argmin(np.abs(tmp - raw.iloc[0]['time'].to_datetime64().astype(int)))
    found = False
    raw_ = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND client_id='"+str(int(raw2.iloc[i]['client_id'])+1)+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
    print("what is the next tick", raw_)
    for j in range(-1, 14):
        print(raw2.iloc[i]['time'])
        print(start, buy_price[start], data.iloc[start+j]['time'], data.iloc[start+j+1]['sellpriceT_'+filename], data.iloc[start+j+1]['buypriceT_'+filename])
        if (raw2.iloc[i]['time'] - data.iloc[start+j+1]['time']) <= pd.Timedelta(milliseconds=(20)) and (raw2.iloc[i]['time'] - data.iloc[start+j]['time']) >= pd.Timedelta(milliseconds=(20)):
            found = True
            print("SHOULD BE IN LAG ", j+1)
            if j >= -1:
                print("CHECK WHY LAG >= 0:")
                result = client.query("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND client_id='"+str(raw2.iloc[i]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                result['order'].index.name='time'
                raw = result['order'].reset_index(level=0)
                raw['time'] = pd.to_datetime(raw['time']).dt.tz_localize(None)
                raw.set_index('time')
                print(raw)
            print("THEN CHECK IF IN BACKTEST ALSO LAG ", j+1)
            print(data.iloc[start])
            if raw2.iloc[i]["side"] == "sell":
                if valid_sellpoint_l[j+1][start] == True:
                    print(i, "VALID SUCCESS! SELL", "lag", j+1)
                    success_num += 1
                else:
                    print("!!!!!!!!!!!!!!!!!!!VALID FAILURE SELL!!!!!!!!!!!!!!!")
                    fail_num += 1
                    for t in range(0, 15):
                        if valid_sellpoint_l[t][start] == True:
                            print(i, "Finally found in lag", t)
            elif raw2.iloc[i]["side"] == "buy":
                if valid_buypoint_l[j+1][start] == True:
                    print(i, "VALID SUCCESS! BUY", "lag", j+1)
                    success_num += 1
                else:
                    print("!!!!!!!!!!!!!!!!!!!VALID FAILURE BUY!!!!!!!!!!!!!!!")
                    fail_num += 1
                    for t in range(0, 15):
                        if valid_buypoint_l[t][start] == True:
                            print(i, "Finally found in lag", t)

            # break
    if not found:
        not_found_num += 1
        print("!!!!!!!!!!!!!!!!!!!VALID FAILURE Not Found!!!!!!!!!!!!!!!")
print(len(raw2), fail_num, success_num, not_found_num)
                
for lag in range(1, 3):
    valid_sellpoint_indices = valid_sellpoint_l[lag].nonzero()[0]
    print(valid_sellpoint_indices)
    for vs in valid_sellpoint_indices:
        # print(data.iloc[vs]['time'], data.iloc[vs]['time'].to_datetime64().astype(int), data.iloc[vs])
        r = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='init' AND side='sell' AND time >= "+str(data.iloc[vs]['time'].to_datetime64().astype(int)//int(1e6)-int(50))+"ms and time <= "+str(data.iloc[vs]['time'].to_datetime64().astype(int)//int(1e6)+int(50))+"ms;")
        # print("corresponding realtime trades", r)
        if type(r) != pd.DataFrame:
            #TODO check why no sell order
            continue
        else:
            r2 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='filled' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
            if type(r2) != pd.DataFrame:
                r4 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='new' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                r5 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='canceled' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                if r4.iloc[0]['time'] - data.iloc[vs+lag]['time'] < pd.Timedelta(milliseconds=(20)) and r5.iloc[0]['time'] - data.iloc[vs+lag-1]['time'] > pd.Timedelta(milliseconds=(20)):
                    r3 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='mk2' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                    print("CHECK VALIDALITY manually why not filled", r3)

            else:
                for j in range(-1, 11):                
                    if r2.iloc[0]['time'] < data.iloc[vs+j+1]['time']+pd.Timedelta(milliseconds=(20)) and r2.iloc[0]['time'] > data.iloc[vs+j]['time']+pd.Timedelta(milliseconds=(20)):
                        print("Actually in lag", j+1)
                        if j+1 == lag:
                            print("Matched", lag)
                        else:
                            print("Not Matched", j+1, lag)
                            if valid_sellpoint_l[j+1][vs]:
                                print("No Problem, Found in ", j+1)


        
for lag in range(1, 3):
    print(lag)
    valid_buypoint_indices = valid_buypoint_l[lag].nonzero()[0]
    print(valid_buypoint_indices)
    for vs in valid_buypoint_indices:
        print(data.iloc[vs]['time'], data.iloc[vs]['ap1_fu'], data.iloc[vs]['bp1_fu'])
        # print(data.iloc[vs]['time'], data.iloc[vs]['time'].to_datetime64().astype(int), data.iloc[vs])
        r = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='init' AND side='buy' AND time >= "+str(data.iloc[vs]['time'].to_datetime64().astype(int)//int(1e6)-int(50))+"ms and time <= "+str(data.iloc[vs]['time'].to_datetime64().astype(int)//int(1e6)+int(50))+"ms;")
        print(r)
        if type(r) != pd.DataFrame:
            #TODO check why no sell order
            continue
        else:
            r2 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='filled' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
            if type(r2) != pd.DataFrame:
                r4 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='new' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                r5 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND type='canceled' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                if type(r4) != pd.DataFrame or type(r5) != pd.DataFrame:
                    r3 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                    print("CHECK VALIDALITY manually why not filled", r3)
                else:
                    if r4.iloc[0]['time'] - data.iloc[vs+lag]['time'] < pd.Timedelta(milliseconds=(20)) and r5.iloc[0]['time'] - data.iloc[vs+lag-1]['time'] > pd.Timedelta(milliseconds=(20)):
                        r3 = get_items("SELECT * FROM \"order\" WHERE exchange='fu' AND pair='ETHUSDT' AND account='"+str(args.type)+"' AND client_id='"+str(r.iloc[0]['client_id'])+"' AND time >= "+str(start_)+"ms and time <= "+str(end_)+"ms;")
                        print("CHECK VALIDALITY manually why not filled", r3)

            else:
                for j in range(-1, 11):                
                    if r2.iloc[0]['time'] < data.iloc[vs+j+1]['time']+pd.Timedelta(milliseconds=(20)) and r2.iloc[0]['time'] > data.iloc[vs+j]['time']+pd.Timedelta(milliseconds=(20)):
                        print("Actually in lag", j+1)
                        if j+1 == lag:
                            print("Matched", lag)
                        else:
                            print("Not Matched", j+1, lag)
                            if valid_buypoint_l[j+1][vs]:
                                print("No Problem, Found in ", j+1)
                            else:
                                print("---Problem here---")

            
            

exit(-1)
