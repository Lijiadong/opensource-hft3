import pandas as pd
import numpy as np
from args import args
import datetime


def tr_data(date_list, tp, old=2):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day, day.month, day.day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        loc = 'data_6/'+tp+'_'+month_str+'_'+day_str+'.pkl'
        a = pd.read_pickle(loc)
        print(a["buypriceT2_fu"])
        a = a.fillna(0)
        print(a["buypriceT2_fu"])
        a.to_pickle('data_6/'+"data"+'_'+month_str+'_'+day_str+'.pkl')  

tr_data(args.train[0], "data", 7)
