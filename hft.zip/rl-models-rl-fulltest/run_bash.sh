source ~/.bashrc
for date0 in "12_28" "12_30" "12_31" "01_01" "01_02" "01_03" "01_04" "01_05" "01_06" "01_07" "01_08" "01_09" "01_10" "01_11" "01_12" "01_13" "01_14"
do
date="${date0}-${date0}"
echo $date
#$HOME/go/bin/gdrive download -r 1pTbmcTp9hZGPajuz5xPqmNkQBonZ4ZCH --skip
#mv data/* data_6/
bash combine_days_bash.sh $date0
conda activate python38
python trans_data.py --train $date --old 6
python trans_data.py --train $date --old 7
python trans_data.py --train $date --old 8


CUDA_VISIBLE_DEVICES=0 python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 601 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train 12_21-01_31 --valid 02_01-02_04 --test $date --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 13 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 02_01-02_01 --wandb --generate_test_predict --seed 8554873884

python backtest_2_compare_test6_19.py --test $date --perform_backtest --compute_trade --wandb --seed 8554873884    --profit_type 19 --write_db

python backtest_2_compare_test6_22.py --test $date --perform_backtest --compute_trade --wandb --seed 8554873884    --profit_type 19 --write_db --t2

source ~/.bashrc
CUDA_VISIBLE_DEVICES=2  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 504 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train 09_21-10_30 --valid 10_31-11_01 --test $date --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 11 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 10_31-10_31 --wandb --generate_test_predict --seed 8313747812
CUDA_VISIBLE_DEVICES=2  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 601 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train "12_06-01_09;01_11-01_15" --valid 01_16-01_19 --test $date --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 12 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 01_16-01_16 --wandb --generate_test_predict --seed 6279426738 
#12_31
CUDA_VISIBLE_DEVICES=2  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 601 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train 11_19-12_31 --valid 01_01-01_05 --test $date --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 12 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 01_01-01_05 --wandb --generate_test_predict --seed 467975215 
CUDA_VISIBLE_DEVICES=2  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 601 --wd 0.4 --T 5 --batch_size 2048 --old 18 --train "12_06-01_09;01_11-01_15" --valid 01_16-01_19 --test $date --arch TSTransformerEncoderClassiregressor --val_split 0.0001 --use_p23 13 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 01_16-01_16 --wandb --generate_test_predict --seed 361910542

conda activate python38
python backtest_2_compare_test6_19.py --test $date --perform_backtest --compute_trade --wandb --seed 8313747812    --profit_type 19 --write_db
python backtest_2_compare_test6_22.py --test $date --perform_backtest  --seed 8313747812    --profit_type 19 --t2

python backtest_2_compare_test6_19.py --test $date --perform_backtest --compute_trade --wandb --seed 6279426738    --profit_type 19 --write_db
python backtest_2_compare_test6_22.py --test $date --perform_backtest  --seed 6279426738    --profit_type 19 --t2

python backtest_2_compare_test6_19.py --test $date --perform_backtest --compute_trade --wandb --seed 467975215    --profit_type 19 --write_db
python backtest_2_compare_test6_22.py --test $date --perform_backtest  --seed 467975215    --profit_type 19 --t2

source ~/.bashrc
CUDA_VISIBLE_DEVICES=1  python main_cnnlstm_rl_sim3_3.py --lr 0.001 --dropout 0 --opt adamw --x xnn4 --y 0 --input_size 96 --wd 0 --T 5 --batch_size 2048 --old 37 --train 08_11-10_20 --valid 10_21-10_25 --test 10_21-10_25 --arch TSTransformerEncoderRLSeq3 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 10_27-11_08 --test4 $date --test_interval 2000 --rlbuy_profit_path 19dout4easy_profit_buy_08_11-10_20std --rlbuy_profit_path2 19dout4easy_profit_buy_10_21-10_25std --rlbuy_profit_path3 19dout4easy_profit_buy_10_27-11_08std --rlbuy_profit_path4 "19dout4easy_profit_buy_${date}std" --valid_buypoint_train 19dout4valid_buypoint_08_11-10_20std --valid_buypoint_valid 19dout4valid_buypoint_10_21-10_25std --valid_buypoint_test 19dout4valid_buypoint_10_27-11_08std --valid_buypoint_test4 "19dout4valid_buypoint_${date}std" --buy_bucket_path 19dout4buckets_buy_08_11-10_20std --buy_bucket_path2 19dout4buckets_buy_10_21-10_25std --buy_bucket_path3 19dout4buckets_buy_10_27-11_08std --buy_bucket_path4 "19dout4buckets_buy_${date}std" --valid_2ndsellpoint 19dout4valid_sell2ndpoint_08_11-10_20std --valid_2ndsellpoint2 19dout4valid_sell2ndpoint_10_21-10_25std --valid_2ndsellpoint3 19dout4valid_sell2ndpoint_10_27-11_08std --valid_2ndsellpoint4 "19dout4valid_sell2ndpoint_${date}std" --num_envs 256 --num_steps 5000 --lag 1 --wandb --gamma 0 --remaining 1 --gradient_acc_step 30 --norm_y --type buy --not_use_bin_feature --exp_neg --take_normal --updates_thres 200000 --profit_type 19  --generate_test_predict --seed 1670137302.338087  --ip 54.65.16.142  --test_clamp --predict_all --write_db
CUDA_VISIBLE_DEVICES=1  python main_cnnlstm_rl_sim4_2.py --lr 0.001 --dropout 0 --opt adamw --x xnn4 --y 0 --input_size 96 --wd 0 --T 5 --batch_size 2048 --old 37 --train 08_11-10_20 --valid 10_21-10_25 --test 10_21-10_25 --arch TSTransformerEncoderRLSeq4 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576 --test2 10_27-11_08 --test4 $date --test_interval 2000 --rlbuy_profit_path 19dout4easy_profit_sell_08_11-10_20std --rlbuy_profit_path2 19dout4easy_profit_sell_10_21-10_25std --rlbuy_profit_path3 19dout4easy_profit_sell_10_27-11_08std --rlbuy_profit_path4 "19dout4easy_profit_sell_${date}std" --valid_buypoint_train 19dout4valid_sellpoint_08_11-10_20std --valid_buypoint_valid 19dout4valid_sellpoint_10_21-10_25std --valid_buypoint_test 19dout4valid_sellpoint_10_27-11_08std --valid_buypoint_test4 "19dout4valid_sellpoint_${date}std" --buy_bucket_path 19dout4buckets_sell_08_11-10_20std --buy_bucket_path2 19dout4buckets_sell_10_21-10_25std --buy_bucket_path3 19dout4buckets_sell_10_27-11_08std --buy_bucket_path4 "19dout4buckets_sell_${date}std" --valid_2ndsellpoint 19dout4valid_buy2ndpoint_08_11-10_20std --valid_2ndsellpoint2 19dout4valid_buy2ndpoint_10_21-10_25std --valid_2ndsellpoint3 19dout4valid_buy2ndpoint_10_27-11_08std --valid_2ndsellpoint4 "19dout4valid_buy2ndpoint_${date}std" --num_envs 256 --num_steps 5000 --lag 1 --wandb --gamma 0 --remaining 1 --gradient_acc_step 30 --norm_y --type sell --not_use_bin_feature --exp_neg --take_normal --updates_thres 200000 --profit_type 19 --learn_bias --seed 1670164550.0509768  --ip ***.***.***.***  --generate_test_predict   --predict_all --write_db
done





