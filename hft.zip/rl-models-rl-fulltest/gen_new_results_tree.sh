source ~/.bashrc
$HOME/go/bin/gdrive download -r 1pTbmcTp9hZGPajuz5xPqmNkQBonZ4ZCH
mv data/* data_6/
conda activate python38
python backtest_lgb.py --train "05_24-08_04" --valid "08_05-08_06" --test "08_07-08_10"
python backtest_lgb_2.py --train "05_24-08_04" --valid "08_05-08_06" --test "08_07-08_10"

