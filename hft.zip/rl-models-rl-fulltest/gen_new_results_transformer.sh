# source ~/.bashrc

# $HOME/go/bin/gdrive download -r 1pTbmcTp9hZGPajuz5xPqmNkQBonZ4ZCH
# mv data/* data_6/
# conda activate python38
# python trans_data.py --train 08_17-08_22


source ~/.bashrc

CUDA_VISIBLE_DEVICES=4  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 645 --wd 0.4 --T 5 --batch_size 2048 --old 8 --train 05_24-08_04 --valid 08_05-08_06 --test 08_14-08_22 --arch TSTransformerEncoderClassiregressor --val_split 0.001 --use_p23 3 --min_mean --div_std --generate_test_predict --seed 1252747319 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576

CUDA_VISIBLE_DEVICES=4  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 0 --input_size 57 --wd 0.4 --T 5 --batch_size 2048 --old 8 --train 05_24-08_04 --valid 08_05-08_06 --test 08_14-08_22 --arch TSTransformerEncoderClassiregressor --val_split 0.001 --use_p23 3 --min_mean --div_std --generate_test_predict --seed 1252747319 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576

# CUDA_VISIBLE_DEVICES=4  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 3 --input_size 57 --wd 0.4 --T 5 --batch_size 2048 --old 8 --train 05_24-08_04 --valid 08_05-08_06 --test 08_11-08_22 --arch TSTransformerEncoderClassiregressor --val_split 0.001 --use_p23 3 --min_mean --div_std --generate_test_predict --seed 7180361367 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576

# CUDA_VISIBLE_DEVICES=4  python main_cnnlstm.py --lr 0.0001 --dropout 0 --opt adamw --x xnn --y 4 --input_size 57 --wd 0.4 --T 5 --batch_size 2048 --old 8 --train 05_24-08_04 --valid 08_05-08_06 --test 08_11-08_22 --arch TSTransformerEncoderClassiregressor --val_split 0.001 --use_p23 3 --min_mean --div_std --generate_test_predict --seed 1070551687 --val_split 0.0001 --use_p23 3 --min_mean --div_std --nlayers 1 --dim 144 --nhead 8 --dim_feedforward 576

conda activate python38


# python backtest.py --train 05_24-08_04 --valid 08_05-08_06 --test 08_14-08_22 --rand_number0 4590547682 --rand_number3 7180361367 --rand_number4 1070551687 --arch TSTransformerEncoderClassiregressor 
python backtest_2.py --train 05_24-08_04 --valid 08_05-08_06 --test 08_14-08_22 --rand_number0 4590547682 --rand_number3 7180361367 --rand_number4 1070551687 --arch TSTransformerEncoderClassiregressor 
