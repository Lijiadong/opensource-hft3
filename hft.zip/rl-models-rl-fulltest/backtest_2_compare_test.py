import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt


def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test, "???")
flist = genflist(args.test[0])
print(flist)
filename = "fu"
data = pd.DataFrame()

first = True
for file in flist:
    if first:
        data = pd.read_pickle('data_6/data_'+file+'.pkl')
        print(data.shape)
        first = False
        with open('data_6/y_'+file+'.npy', 'rb') as f:
            y_true = np.load(f)
        break
    else:
        tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
        print(tmp.shape)
        data = pd.concat([data, tmp])

        with open('data_6/y_'+file+'.npy', 'rb') as f:
            tmp = np.load(f)
        y_true = np.concatenate((y_true, tmp), axis=0)

with open("data_7/y0_"+args.arch+"_"+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(args.rand_number0)+".npy", 'rb') as f:
    y_predict0 = np.load(f)
# y_predict0 = np.concatenate((np.zeros(4), y_predict0), axis=0)

if args.double_test:
    with open("data_7/y0_"+args.arch+"_"+";".join(args.train3)+"_"+";".join(args.valid3)+"_"+";".join(args.test)+str(args.rand_number3)+".npy", 'rb') as f:
        y_predict1 = np.load(f)

def backtest(a, b, d, y, type):
    state = 'empty'
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'

    resl = []
    lag = 0 
    filename='fu'
    for i in range(0, len(data)-1-lag):
        if state == 'empty':
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-0.01 and tpb != 0:
                state = 'buy'
                total_profit += 0.4/1e4
                continue
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tps = data['buypriceT_'+filename][i+1]
            if tps >= sell_price+0.01 and tps != 0:
                state = 'sell'
                total_profit += 0.4/1e4
                continue
        
        if state == 'buy' and data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            state = 'empty'
            total_profit += sell_price / buy_price - 1 - 2/1e4
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            continue

        if state == 'sell' and data[p1][i] > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)
            state = 'empty'
            total_profit += sell_price / buy_price - 1 - 2/1e4
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            continue
        
        if state == 'buy':
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 0.4/1e4
                resl.append((data.index[i], total_profit))
                cnt += 1
                continue
        
        if state == 'sell':
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 0.4/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
            continue

        # if i > 2000000:
            # break
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt, resl

def add_vol(l, i):
    l[i][1] += 1

def backtest_2(a, b, d, y, type, thres, thres2=0):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y[:len(data)], index = data.index)

    p1='predict1'

    profits = []
    lag = 0 
    filename='fu'
    for i in range(0, len(data)-1-lag):
        buy_price = data['bp1_'+filename][i]*(1-d/1e4)
        if type == "predict":
            buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
        tpb = data['sellpriceT_'+filename][i+1]
        profit = 0
        if tpb <= buy_price-0.01 and tpb != 0:
            profit += 0.4/1e4
            j = i
            while(True):
                j += 1
                if data[p1][j] < -b:
                    sell_price = data['bp1_fu'][j+5]*(1.0)
                    profit += sell_price / buy_price - 1 - 2/1e4
                    break
                sell_price = data['ap1_'+filename][j]*(1+d/1e4)
                if type == "predict":
                    sell_price *= (1+np.clip(2*(data[p1][j]+0.0)/1e4,-0/1e4, 20/1e4))
                tp = data['buypriceT_'+filename][j+1]
                if tp >= sell_price+0.01 and tp != 0:
                    profit += sell_price / buy_price - 1 + 0.4/1e4
                    break
            profits.append([i,profit])
        if i > 800000: 
            break
    print(profits)
    # print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt



def backtest_3(a, b, d, y, type, thres, thres2=0):
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y[:len(data)], index = data.index)

    p1='predict1'
    resl = []
    lag = 0 
    filename='fu'
    buy_prices = []
    def buy_logic(buy_prices):
        delta_profit = []
        buy_price = data['bp1_'+filename][i]*(1-d/1e4)
        if type == "predict":
            buy_price *= (1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
        tpb = data['sellpriceT_'+filename][i+1]
        if tpb <= buy_price-0.01 and tpb != 0:
            buy_prices.append([i, buy_price])
            return [], buy_prices
        if data[p1][i] < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)
            for bp in buy_prices:
                delta_profit.append([bp[0], sell_price / bp[1] - 1 - 2/1e4 + + 0.4/1e4])
            buy_prices = []
            return delta_profit, buy_prices
        sell_price = data['ap1_'+filename][i]*(1+d/1e4)
        if type == "predict":
            sell_price *= (1+np.clip(2*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
        tp = data['buypriceT_'+filename][i+1]
        if tp >= sell_price+0.01 and tp != 0:
            for bp in buy_prices:
                delta_profit.append([bp[0], sell_price / bp[1] - 1 + 0.4/1e4 + + 0.4/1e4])
            buy_prices = []
            return delta_profit, buy_prices
        return delta_profit, buy_prices

    profits = []
    for i in range(0, len(data)-1-lag):
        delta_profit, buy_prices = buy_logic(buy_prices)
        # print(delta_profit)
        for dp in delta_profit:
            profits.append([dp[0], dp[1]])
        if i > 800000: 
            break
    print(profits)
    
    print(total_profit, cnt, takercnt)
    return total_profit, cnt, takercnt


import pickle
dic = {}
for a in [1.0]:
    for b in [10]:
            for d in [4]:
                import matplotlib.pyplot as plt
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                ax2 = ax1.twinx()
                # for thres in [1,3,5,7,10,15,20]:
                    # total_profit, cnt, takercnt, resl = backtest(a, b, d, y_predict, "true")
                    # total_profit2, cnt2, takercnt2, resl2= backtest_2(a, b, d, y_predict, "true")
    # 
                # total_profit, cnt, takercnt, resl3 = backtest(a, b, d, y_predict0, "predict")
                if args.double_test:
                    total_profit, cnt, takercnt, resl7 = backtest(a, b, d, y_predict1, "predict")

                total_profit2, cnt2, takercnt2 = backtest_2(a, b, d, y_predict0, "predict", 100, 100)             
                total_profit2, cnt2, takercnt2 = backtest_3(a, b, d, y_predict0, "predict", 100, 100)             

                # total_profit5, cnt5, takercnt5, resl5, volume_buy5, volume_sell5= backtest_2(a, b, d, y_predict0, "predict", 20, 0)


                # remainder = [[data.index[i], volume_buy4[i][1]-volume_sell4[i][1]] for i in range(2500005)]

                
                # ax1.plot(*zip(*resl), color='red')
                # ax1.plot(*zip(*resl2), color='green')
                # ax1.plot(*zip(*resl3), color='black')
                # ax1.plot(*zip(*resl3))
                # ax1.plot(*zip(*resl4))
                # ax1.plot(*zip(*resl5))
                if args.double_test:
                    ax1.plot(*zip(*resl7))

                # ax1.plot(*zip(*volume_buy4), color='green')
                # ax1.plot(*zip(*volume_sell4), color='black')
                # ax1.plot(*zip(*remainder), color='red')

                plt.grid()
                ax2.plot(data.index, (data['mid_fu']), color='blue')


                plt.title(args.arch+";a:"+str(a)+"b:"+str(b)+"d:"+str(d))
                plt.legend()
                plt.show()
                plt.savefig("result"+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(a)+"_"+str(b)+"_"+str(d)+"compare.png")
