import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt
from numba import jit
import wandb
np.set_printoptions(threshold=200)
thres = 0.01
def load_data_length(date_list, tp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    x_l = 0
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day, day.month, day.day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l += np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r").shape[0]
    return x_l

def genflist(date_list):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    x_l = []
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

flist = []
for i in range(len(args.test)):
    flist = flist + genflist(args.test[i])
filename = "fu"
data = pd.DataFrame()
first = True
tmp_lst = []
y_lst = []
for file in flist:
    tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
    tmp = pd.DataFrame(tmp, columns=['mid_fu', "predict1", 'ap1_fu', 'bp1_fu', 'sellpriceT_'+filename, 'buypriceT_'+filename, 'sellpriceT2_'+filename, 'buypriceT2_'+filename])
    tmp_lst.append(tmp)
    tmp = np.load('data_6/y_'+file+'.npy')
    y_lst.append(tmp)
data = pd.concat(tmp_lst)
y_true = np.concatenate(y_lst, axis=0)
import os
path = "***.***.***.***"

if args.test[0] == "08_11-09_15":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03), axis=0)

elif args.test[0] == "09_16-09_25":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01), axis=0)

elif args.test[0] == "09_26-10_25":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03), axis=0)

elif args.test[0] == "10_27-11_06":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    y_predict0 = np.concatenate((y_predict04, y_predict05), axis=0)

elif args.test[0] == "11_19-11_24":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+args.test[0]+"8313747812.npy")

elif args.test[0] == "08_11-10_20":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08), axis=0)



elif ";".join(args.test) == "01_21-02_08" and args.seed == "8313747812":
    y_list = []

    lent = load_data_length("01_16-01_20", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")[lent:])
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_24-01_278313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_28-02_068313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_02_07-02_088313747812.npy"))

    y_predict0 = np.concatenate(y_list, axis=0)
elif args.test[0] == "10_21-10_25":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")

elif args.test[0] == "11_19-12_01":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04), axis=0)

elif args.test[0] == "11_19-12_07":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05), axis=0)

elif args.test[0] == "11_25-12_07":
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")
    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04, y_predict05), axis=0)

elif args.test[0] == "10_27-11_11":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_118313747812.npy")
    y_predict0 = np.concatenate((y_predict04, y_predict05, y_predict06), axis=0)

elif args.test[0] == "10_27-11_08":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    total_length6 = load_data_length("11_07-11_08", "y")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_118313747812.npy")[:total_length6]
    y_predict0 = np.concatenate((y_predict04, y_predict05, y_predict06), axis=0)

elif args.test[0] == "11_25-11_27":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+args.test[0]+"8313747812.npy")
elif args.test[0] == "12_06-12_07" and args.seed == "8313747812":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_06-12_068313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_07-12_078313747812.npy")
    y_predict0 = np.concatenate((y_predict04, y_predict05), axis=0)

elif args.test[0] == "09_21-10_25":
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict0 = np.concatenate((y_predict05, y_predict06, y_predict07, y_predict08, y_predict09), axis=0)


elif ";".join(args.test) == "08_11-10_25;11_19-11_24":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict13 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09, y_predict13), axis=0)

elif ";".join(args.test) == "08_11-10_25;10_27-11_08;11_19-11_24":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict10 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict11 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    total_length6 = load_data_length("11_07-11_08", "y")
    y_predict12 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_118313747812.npy")[:total_length6]
    y_predict13 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09, y_predict10, y_predict11, y_predict12, y_predict13), axis=0)

elif args.test[0] == "11_19-12_07":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")

    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05), axis=0)


elif ";".join(args.test) == "08_11-10_25;11_19-12_08":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict10 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict11 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict12 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict13 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict14 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict15 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")
    y_predict16 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_08-12_088313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09, y_predict10, y_predict11, y_predict12, y_predict13, y_predict14, y_predict15, y_predict16), axis=0)


elif ";".join(args.test) == "12_11-01_20" and args.seed == "999999":
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_10_12_11-12_14_12_11-12_204608391152.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_20_12_21-12_24_12_21-12_317687624152.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_31_01_01-01_04_01_01-01_107808694296.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_03-01_10_01_11-01_14_01_11-01_208775546016.npy")

    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04), axis=0)



elif ";".join(args.test) == "12_11-02_08" and args.seed == "999999":
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_10_12_11-12_14_12_11-12_204608391152.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_20_12_21-12_24_12_21-12_317687624152.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_31_01_01-01_04_01_01-01_107808694296.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_03-01_10_01_11-01_14_01_11-01_208775546016.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy")
    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06), axis=0)

elif ";".join(args.test) == "12_11-01_20" and args.seed == "8313747812":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    lent = load_data_length("01_16-01_20", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")[:lent])
    y_predict0 = np.concatenate(y_list, axis=0)
    

elif ";".join(args.test) == "01_21-01_31" and args.seed == "8313747812":
    y_list = []

    
    lent = load_data_length("01_16-01_20", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")[lent:])
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_24-01_278313747812.npy"))
    lent = load_data_length("01_28-01_31", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_28-02_068313747812.npy")[:lent])
    y_predict0 = np.concatenate(y_list, axis=0)



elif ";".join(args.test) == "01_28-02_08" and args.seed == "999999":
    y_list = []
    lent = load_data_length("01_21-01_27", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")[lent:])
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy"))
    
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_28-02_06" and args.seed == "999999":
    y_list = []
    lent = load_data_length("01_21-01_27", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")[lent:])
    lent = load_data_length("02_01-02_06", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy")[:lent])
    y_predict0 = np.concatenate(y_list, axis=0)



elif ";".join(args.test) == "01_21-01_31" and args.seed == "999999":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")


elif ";".join(args.test) == "02_01-02_08" and args.seed == "999999":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy")

elif ";".join(args.test) == "12_07-12_31":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_01-01_07;01_11-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "12_11-01_09":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_11-01_18":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_188313747812.npy"))

    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "12_12-01_07":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)
elif ";".join(args.test) == "12_07-01_05":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_06-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_21-02_21" and args.seed == "999999":
    y_list = []
    lent = load_data_length("01_21-01_30", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")[:lent])
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_31-01_319536372242.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_09-02_168554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_17-02_178554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_18-02_188554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_19-02_198554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_20-02_208554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_21-02_218554873884.npy"))
    
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_01-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_08-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_16-01_27":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_24-01_278313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_21-02_21" and args.seed == "999999":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_09-02_168554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_17-02_178554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_18-02_188554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_19-02_198554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_20-02_208554873884.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_21-02_218554873884.npy"))
    
    y_predict0 = np.concatenate(y_list, axis=0)
    
elif ";".join(args.test) == "01_16-01_23":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")

elif ";".join(args.test) == "12_21-12_21" and args.seed == "4608391152":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_10_12_11-12_14_12_21-12_214608391152.npy")
    y_predict50 = np.load("data_7/y50_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_10_12_11-12_14_12_21-12_211666892494.npy")
elif args.seed == "467975215":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-12_31_01_01-01_05_"+args.test[0]+args.seed+".npy")

elif args.seed != "8313747812":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_"+args.test[0]+args.seed+".npy")
else:
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+args.test[0]+"8313747812.npy")

args.profit_type = str(args.profit_type)
dout = args.dout
np.save(args.profit_type+"dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std"+".npy", y_predict0)
np.save(args.profit_type+"dout"+str(dout)+"time"+"_"+";".join(args.test)+"std"+".npy", data.index.to_numpy())

def backtest_11(y):
    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    max_p = 1625.985
    data['predict1']=pd.DataFrame(y, index = data.index)
    p1='predict1'
    filename='fu'
    dout = 4
    m1, m2 = 2, 4
    if args.t2:
        abbr = "2"
    else:
        abbr = ""
    for lag, lag2 in [(1, 1)]:
        sell_price_base = data['ap1_'+filename].to_numpy()*(1+np.clip(m1*data[p1].to_numpy()/1e4, 0, 20/1e4))
        # sell_price_base = data['ap1_'+filename].to_numpy()
        tp = data['buypriceT'+abbr+'_'+filename][lag2:].to_numpy()
        tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
        valid_sellpoint_0 = (np.logical_and(tp >= sell_price_base+thres, tp != 0)).nonzero()[0]
        np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_sell2ndpoint_0"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_sellpoint_0)

        # buy_price_base = data['bp1_'+filename].to_numpy()
        buy_price_base = data['bp1_'+filename].to_numpy()*(1+np.clip(m2*data[p1].to_numpy()/1e4, -20/1e4, 0))
        tpb = data['sellpriceT'+abbr+'_'+filename][lag:].to_numpy()
        tpb = np.concatenate([tpb, np.zeros(lag)], axis=0)
        valid_buypoint_0 = (np.logical_and(tpb <= buy_price_base-thres, tpb != 0)).nonzero()[0]
        np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_buypoint_0"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_buypoint_0)

        print("valid_sellpoint", valid_sellpoint_0, len(valid_sellpoint_0))
        print("valid_buypoint", valid_buypoint_0, len(valid_buypoint_0))

        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"sell_price_basenop"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", data['ap1_'+filename].to_numpy())
        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"sell2nd_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", sell_price_base)
        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"buy_price_basenop"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", data['bp1_'+filename].to_numpy())
        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", buy_price_base)
        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", tpb)
        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"tps2nd"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", tp)

        buy_price_base = data['bp1_'+filename].to_numpy()
        buy_price_base *= (1+np.clip(m1*data[p1].to_numpy()/1e4, -20/1e4, 0))
        tp = data['sellpriceT'+abbr+'_'+filename][lag2:].to_numpy()
        tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
        valid_buypoint_0 = (np.logical_and(tp <= buy_price_base-thres, tp != 0)).nonzero()[0]
        np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_buy2ndpoint_0"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_buypoint_0)

        sell_price_base = data['ap1_'+filename].to_numpy()
        sell_price_base *= (1+np.clip(m2*data[p1].to_numpy()/1e4, 0, 20/1e4))
        tps = data['buypriceT'+abbr+'_'+filename][lag:].to_numpy()
        tps = np.concatenate([tps, np.zeros(lag)], axis=0)
        valid_sellpoint_0 = np.logical_and(tps >= sell_price_base+thres, tps != 0).nonzero()[0]
        np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_sellpoint_0"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_sellpoint_0)

        print("valid_buypoint", valid_buypoint_0, len(valid_buypoint_0))
        print("valid_sellpoint", valid_sellpoint_0, len(valid_sellpoint_0))
        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"buy2nd_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", buy_price_base)
        np.save(abbr+args.profit_type+"dout"+str(dout)+"sell_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", sell_price_base)
        np.save(abbr+args.profit_type+"dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", tps)
        np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"tpb2nd"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", tp)
    return

backtest_11(y_predict0)
