from cgi import test
import torch
import models
from args import args
import stock
from stock import y_length_list, ori_x2
import tqdm
torch.set_default_dtype(torch.float32)

pretrained0 = torch.load("best_model_yCNNLSTM0_05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27;06_29-07_04;07_06-07_07_05_30-05_30;06_07-06_07;06_14-06_14;06_21-06_21;06_28-06_28;07_05-07_05_copy.pt")
pretrained3 = torch.load("best_model_yCNNLSTM3_05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27;06_29-07_04;07_06-07_07_05_30-05_30;06_07-06_07;06_14-06_14;06_21-06_21;06_28-06_28;07_05-07_05_copy.pt")
pretrained4 = torch.load("best_model_yCNNLSTM4_05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27;06_29-07_04;07_06-07_07_05_30-05_30;06_07-06_07;06_14-06_14;06_21-06_21;06_28-06_28;07_05-07_05_copy.pt")

import numpy as np

with open('abs_v05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27;06_29-07_04;07_06-07_07.npy', 'rb') as f:
    abs_v = np.load(f)
with open('mean05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27;06_29-07_04;07_06-07_07.npy', 'rb') as f:
    mean = np.load(f)
with open('std05_24-05_29;05_31-06_06;06_08-06_13;06_15-06_20;06_22-06_27;06_29-07_04;07_06-07_07.npy', 'rb') as f:
    std = np.load(f)

print(pretrained0, pretrained3, pretrained4)

print(abs_v, mean, std)
test_dataset = stock.StockAggregate("test")

for i in range(10):
    input = (((ori_x2[i:i+args.T]/abs_v)-mean)/std).permute(1, 0).unsqueeze(0).cuda().float()
    print(input)
    # print(input.size())
    with open('ori_x'+str(i)+'.npy', 'wb') as f:
        np.save(f, ori_x2[i].cpu().detach().numpy())
    print(pretrained0(input))
    print(pretrained0(test_dataset.data_X[i:i+args.T, :].permute(1, 0).unsqueeze(0).cuda()).float())





def calculate_real_stats_test(model, dataset, evaluate=True, step=0):
    if evaluate:
        model.eval()
    else:
        model.train()
    y_hat_total = torch.zeros(len(dataset)).cuda()
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=args.batch_size, num_workers=4, pin_memory=True)
    y_total = dataset.data_y[args.T - 1:].cuda()
    with torch.no_grad():
        for i, (x, y, index) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
            x, y = x.cuda(), y.cuda()
            if "Normal" not in args.arch:
                y_hat_total[index] = model(x).squeeze().detach()
            else:
                y_hat_total[index] = model(x)[:, 0].squeeze().detach()
            # print(y_hat_total.nonzero().nelement())
        loss_all = ((y_total-y_hat_total)**2).mean().item()
        corr_all = abs(np.corrcoef(torch.cat((y_total.unsqueeze(1), y_hat_total.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
        r2_all = (1-((y_total-y_hat_total)**2).sum()/((y_total-y_total.mean())**2).sum()).item()
        length_to_date = 0
        loss_l, corr_l, r2_l = [], [], []
        for i, l in enumerate(y_length_list):
            length_to_date_end = length_to_date + l
            y_total_seg = y_total[length_to_date:length_to_date_end]
            y_hat_total_seg = y_hat_total[length_to_date:length_to_date_end]
            loss = ((y_total_seg-y_hat_total_seg)**2).mean().item()
            corr = abs(np.corrcoef(torch.cat((y_total_seg.unsqueeze(1), y_hat_total_seg.unsqueeze(1)), 1).t().detach().cpu().numpy())[0, 1])
            r2 = (1-((y_total_seg-y_hat_total_seg)**2).sum()/((y_total_seg-y_total_seg.mean())**2).sum()).item()
            length_to_date = length_to_date_end
            print("day", i, loss, corr, r2)
            loss_l.append(loss)
            corr_l.append(corr)
            r2_l.append(r2)
    return mean(loss_l), mean(corr_l), mean(r2_l)


calculate_real_stats_test(pretrained0, test_dataset)