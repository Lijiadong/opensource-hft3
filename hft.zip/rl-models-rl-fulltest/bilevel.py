import argparse
import random
from logging_utils.dir_manage import get_directories
from hypergrad.hypergradients_cifar_iter import update_tensor_grads
from hypergrad.meta import MetaSGD

train_lim = 800000
val_lim = 950000
test_lim = -1

import torch
import torch.nn as nn
import stock
import numpy as np
import tqdm
import logger
import argparse
import wandb
import copy 
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from args import args
torch.set_default_dtype(torch.float64)


# the proxy will always want more data, so probabily categorical sampling is a more natural choice, in that case, RL can be used to give the feedback
torch.set_printoptions(precision=6,sci_mode=False)

def assign_learning_rate(optimizer, new_lr):
    for param_group in optimizer.param_groups:
        param_group["lr"] = new_lr

class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(args.input_size, args.hidden)
        self.dropout1 = nn.Dropout(args.dropout)
        self.bn1 = torch.nn.BatchNorm1d(args.hidden)
        self.fc2 = nn.Linear(args.hidden, args.hidden)
        self.dropout2 = nn.Dropout(args.dropout)
        self.bn2 = torch.nn.BatchNorm1d(args.hidden)
        self.fc3 = nn.Linear(args.hidden, 1)

    def forward(self, x):
        x = nn.ReLU()(self.bn1(self.dropout1(self.fc1(x))))
        x = self.fc3(nn.ReLU()(self.bn2(self.dropout2(self.fc2(x)))))
        return x


def find_linear_solution(train_dataset, test_dataset, reweights):
    x = ((train_dataset.data_X-train_dataset.mean)*reweights).cpu().detach().numpy()
    y = train_dataset.data_y.cpu().detach().numpy()
    linear = Ridge(fit_intercept=False, alpha=0)
    linear.fit(x, y)
    r2_train = linear.score(x, y)
    loss_train = ((linear.predict(x) - y) ** 2).mean()
    print(r2_train, loss_train)
    y_hat = torch.from_numpy(linear.predict(x))
    y_true = torch.from_numpy(y)
    print(y_true.shape, y_hat.shape)
    corr_train = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach())[0, 1])
    print(corr_train)

    x_test = ((test_dataset.data_X-test_dataset.mean)*reweights).cpu().detach().numpy()
    y_test = test_dataset.data_y.cpu().detach().numpy()
    r2_test = linear.score(x_test, y_test)
    loss_test = ((linear.predict(x_test) - y_test) ** 2).mean()
    print(r2_test, loss_test)
    y_hat = torch.from_numpy(linear.predict(x_test))
    y_true = torch.from_numpy(y_test)
    print(y_true.shape, y_hat.shape)
    corr_test = abs(np.corrcoef(torch.cat((y_true.unsqueeze(1), y_hat.unsqueeze(1)), 1).t().detach())[0, 1])
    print(corr_test)
    return torch.from_numpy(linear.coef_).clone().detach().cuda()

def get_grad_weights_on_val(dataset, weights, reweights):
    model = nn.Linear(args.input_size, 1, bias=False).cuda()
    model.weight.data = weights
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=10000, num_workers=10, pin_memory=True)
    grad_weights_on_val = []
    grad_reweights_on_val = []
    for i, (x, y, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
        x, y = x.cuda(), y.cuda()
        y_hat = model(x).squeeze()
        loss = criterion(y_hat, y)/len(dataset)
        grad_weights_on_val_batch = torch.autograd.grad(loss, model.parameters(), retain_graph=True)
        # grad_reweights_on_val_batch = torch.autograd.grad(loss, reweights)
        if i > 0:
            grad_weights_on_val = [wb+w for wb, w in zip(grad_weights_on_val_batch, grad_weights_on_val)]
            # grad_reweights_on_val = [wb+w for wb, w in zip(grad_reweights_on_val_batch, grad_reweights_on_val)]
        else:
            grad_weights_on_val = grad_weights_on_val_batch
            # grad_reweights_on_val = grad_reweights_on_val_batch
    return grad_weights_on_val


def repass_backward(dataset, weights, reweights, grad_weights_on_full_train):
    # accumulate gradients backwards to leverage hessian-vector product
    reweighting_grads = [torch.zeros_like(weights)]
    model = nn.Linear(args.input_size, 1, bias=False).cuda()
    model.weight.data = weights
    loader_seq = torch.utils.data.DataLoader(dataset, shuffle=False, sampler=torch.utils.data.SequentialSampler(dataset), batch_size=10000, num_workers=10, pin_memory=True)
    for i, (x, y, _) in tqdm.tqdm(enumerate(loader_seq), ascii=True, total=len(loader_seq)):
        x, y = x.cuda(), y.cuda()
        y_hat = model(reweights*x).squeeze()
        loss = criterion(y_hat, y)/len(dataset)
        weight_grad = torch.autograd.grad(loss, model.parameters(), create_graph=True)
        grad_batch = torch.autograd.grad(weight_grad, reweights, grad_outputs=grad_weights_on_full_train)
        reweighting_grads = [g - b for g, b in zip(reweighting_grads, grad_batch)]
    return reweighting_grads[0]

def solve(model):
    reweights = torch.full_like(model.weight, 1, dtype=torch.float64, requires_grad=True, device="cuda")
    print(reweights.shape)
    reweights_opt = torch.optim.Adam([reweights], lr=args.outer_lr)
    reweights.grad = torch.zeros_like(reweights)
    for outer_iter in range(args.max_outer_iter):
        print(reweights)
        reweights_opt.zero_grad()
        assign_learning_rate(reweights_opt, 0.5 * (1 + np.cos(np.pi * outer_iter / args.max_outer_iter)) * args.outer_lr)
        weights = find_linear_solution(train_dataset, test_dataset, reweights.detach().cpu().numpy())
        grad_weights_on_val = get_grad_weights_on_val(test_dataset, weights, reweights)
        grad_reweights = repass_backward(train_dataset, weights, reweights, grad_weights_on_val)
        with torch.no_grad():
            reweights.grad = grad_reweights
        torch.nn.utils.clip_grad_norm_(reweights, 3)
        reweights_opt.step()
        with torch.no_grad():
            reweights.data = nn.ReLU()(reweights.data)
    return reweights

# wandb.init(project=args.project, name=args.runs_name, config=args)
run_base_dir, ckpt_base_dir, log_base_dir = get_directories(args)
print(run_base_dir, ckpt_base_dir, log_base_dir)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
random.seed(args.seed)

criterion = nn.MSELoss(reduction="sum")
train_dataset = stock.Stock("train")
val_dataset = stock.Stock("val")
test_dataset = stock.Stock("test")
model = nn.Linear(args.input_size, 1, bias=False).cuda()
solve(model)

