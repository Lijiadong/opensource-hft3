import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt
from numba import jit
import wandb
np.set_printoptions(threshold=200)

thres = 0.01
# wandb.init(project="stock_prediction", entity="zhouuxx96")



def calculate_profit_with_chosen_2(valid_sellpoint, chosen_value_total, position=args.bin, lag=1, lag2=1, record=False):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    profit_position_2 = np.zeros(len(chosen_vt))

    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    trades = []
    position_np = np.zeros(len(chosen_vt))
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+lag+lag2-1] += chosen_vt[vb]
                    profit_position_2[vb] += chosen_vt[vb]
                    trades.append((vb, vb+lag, valid_sellpoint[bin]+lag-1, valid_sellpoint[bin]+lag+lag2-1))
                    deferred_positions.append((bin, vb + lag))
                    
                    # print(deferred_positions)
                    if vb == 1010076:
                        print("here!!!", chosen_vt[vb], valid_sellpoint[bin]+lag-1, vb)


            else:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+lag+lag2-1] += chosen_vt[vb]
                    profit_position_2[vb] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    trades.append((vb, vb+lag, valid_sellpoint[bin+1]+lag-1, valid_sellpoint[bin+1]+lag+lag2-1))
                    if vb == 1010076:
                        print("here!!!", chosen_vt[vb], valid_sellpoint[bin+1]+lag-1, vb)
                    
                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    if record:
        np.save("compare2.npy", profit_position_2)
    segments = valid_sellpoint+lag+lag2-1
    # if record and lag == 1 and lag2 == 1:
        # for i in range(len(segments)-1):
            # print("close time", data.index[segments[i]])
            # print("posititon", positions_dict[i])
    for tr in trades:
        position_np[tr[1]] += 1
    for i in range(len(segments)-1):
        position_np[segments[i]:segments[i+1]] = np.cumsum(position_np[segments[i]:segments[i+1]])
    position_np[:segments[0]] = np.cumsum(position_np[:segments[0]])
    return total_profit, profit_position, sum(positions_dict), trades, position_np

def load_data_length(date_list, tp):
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = 0
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        print(day, day.month, day.day)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l += np.load('data_6/'+tp+'_'+month_str+'_'+day_str+'.npy', mmap_mode="r").shape[0]
    return x_l

def genflist(date_list):
    # print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    # print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    if end_month < start_month:
        year = 2023
    else:
        year = 2022
    end = datetime.date(year,end_month,end_day)
    x_l = []
    # print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test, "???")
flist = []
for i in range(len(args.test)):
    flist = flist + genflist(args.test[i])
print(flist)
filename = "fu"
data = pd.DataFrame()
first = True
tmp_lst = []
y_lst = []
std_lst = []
for file in flist:
    if args.test[0] == "09_26-11_01" and file == "10_26":
        continue
    # print(file)
    tmp = pd.read_pickle('data_6/data_'+file+'.pkl')

    tmp = pd.DataFrame(tmp, columns=['mid_fu', "predict1", 'ap1_fu', 'bp1_fu', 'sellpriceT_'+filename, 'buypriceT_'+filename, 'sellpriceT2_'+filename, 'buypriceT2_'+filename, 'lagtime_order'])
    std = pd.read_pickle('data_6/xnn6_'+file+'.pkl')
    std = pd.DataFrame(std, columns=['std'])
    print(std)
    # print(tmp)
    tmp_lst.append(tmp)
    std_lst.append(std)
    tmp = np.load('data_6/y_'+file+'.npy')
    y_lst.append(tmp)
data = pd.concat(tmp_lst)
data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
std = pd.concat(std_lst)
print(std)

if args.wandb:
    ts = pd.Timestamp(2022, 11, 15, 0, 55, 3, 100)

    print((data.index > ts).nonzero()[0])

    print(data.index[(data.index > ts).nonzero()[0][0]:(data.index > ts).nonzero()[0][0]+100])
    start = (data.index > ts).nonzero()[0][0]

    ts = pd.Timestamp(2022, 11, 15, 2, 5, 38, 800)

    print((data.index > ts).nonzero()[0])

    print(data.index[(data.index > ts).nonzero()[0][0]:(data.index > ts).nonzero()[0][0]+100])
    end = (data.index > ts).nonzero()[0][0]
    dout = args.dout
    # np.save(args.profit_type+"dout"+str(dout)+"data"+"_"+";".join(args.test)+"std"+".npy", data.to_numpy())



# # print("-------------", pd_buy_price, "-----------")
from influxdb import DataFrameClient
#1: ***.***.***.***
#mk2, 3, 4: 54.65.16.142
client0 = DataFrameClient('***.***.***.***', ******)
client = DataFrameClient('54.65.16.142', ******)
# # client.write_points(df_init, "backtest_init", {})
# # client.write_points(df_trans, "backtest_trans", {})

# client.write_points(df_rlseq, "backtest_rlseq", {})
if args.write_db:
    args.profit_type = str(args.profit_type)
    tp = data['buypriceT2_fu'][1:].to_numpy()
    tp = np.concatenate([tp, np.zeros(1)], axis=0)
    tmpframe = pd.DataFrame()
    tmpframe['shiftedbuypriceT2_fu'] = pd.DataFrame(tp[tp!=0], index=data.index[tp!=0])
    tmpframe['gapbuypriceT2_fu'] = tmpframe['shiftedbuypriceT2_fu'] - data['ap1_fu'][tp!=0]
    print(tmpframe['gapbuypriceT2_fu'])
    print(pd.isna(tmpframe['gapbuypriceT2_fu']).to_numpy().sum())

    tmpframe2 = pd.DataFrame()
    tp = data['sellpriceT2_fu'][1:].to_numpy()
    tp = np.concatenate([tp, np.zeros(1)], axis=0)
    print("nan?", np.isnan(tp).sum(), np.isnan(tp[tp!=0]).sum(), tp, tp!=0)
    tmpframe2['shiftedsellpriceT2_fu'] = pd.DataFrame(tp[tp!=0], index=data.index[tp!=0])
    print("nan?", tmpframe2['shiftedsellpriceT2_fu'].to_numpy().sum())
    print("why diff", tp[tp!=0], tmpframe2['shiftedsellpriceT2_fu'] )

    tmpframe2['gapsellpriceT2_fu'] = data['bp1_fu'][tp!=0] - tmpframe2['shiftedsellpriceT2_fu'] 
    print("why zero", pd.isna(data['bp1_fu'][tp!=0]).to_numpy().sum(), pd.isna(tmpframe2['shiftedsellpriceT2_fu'] ).to_numpy().sum())
    print(tmpframe2['gapsellpriceT2_fu'])
    print(pd.isna(tmpframe2['gapsellpriceT2_fu']).to_numpy().sum())
    print("why zero", pd.isna(data['sellpriceT2_fu']).to_numpy().sum())


    i = 0
    for i in range(1, int(len(data[['predict1']])//1e5)):
        print((i-1)*int(1e5), i*int(1e5))
        # client.write_points(data[['predict1']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_y0", {})
        client.write_points(std[['std']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_std", {})
        client.write_points(data[['mid_fu']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_mid", {})
        client.write_points(data[['ap1_fu']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_ap1", {})
        client.write_points(data[['bp1_fu']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_bp1", {})
        client.write_points(tmpframe[['shiftedbuypriceT2_fu']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_buypriceT2_funew", {})
        client.write_points(tmpframe[['gapbuypriceT2_fu']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_gapbuypriceT2_funew", {})
        client.write_points(tmpframe2[['shiftedsellpriceT2_fu']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_sellpriceT2_funew", {})
        client.write_points(tmpframe2[['gapsellpriceT2_fu']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_gapsellpriceT2_funew", {})

    print(i*int(1e5), len(data[['predict1']]))
    # client.write_points(data[['predict1']][i*int(1e5):], args.profit_type+"backtest_y0", {})
    client.write_points(std[['std']][i*int(1e5):], args.profit_type+"backtest_std", {})
    client.write_points(data[['mid_fu']][i*int(1e5):], args.profit_type+"backtest_mid", {})
    client.write_points(data[['ap1_fu']][i*int(1e5):], args.profit_type+"backtest_ap1", {})
    client.write_points(data[['bp1_fu']][i*int(1e5):], args.profit_type+"backtest_bp1", {})
    client.write_points(tmpframe[['shiftedbuypriceT2_fu']][i*int(1e5):], args.profit_type+"backtest_buypriceT2_funew", {})
    client.write_points(tmpframe[['gapbuypriceT2_fu']][i*int(1e5):], args.profit_type+"backtest_gapbuypriceT2_funew", {})
    client.write_points(tmpframe2[['shiftedsellpriceT2_fu']][i*int(1e5):], args.profit_type+"backtest_sellpriceT2_funew", {})
    client.write_points(tmpframe2[['gapsellpriceT2_fu']][i*int(1e5):], args.profit_type+"backtest_gapsellpriceT2_funew", {})
    exit(-1)


y_true = np.concatenate(y_lst, axis=0)
import os

path = "***.***.***.***"

if args.test[0] == "08_11-09_15":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03), axis=0)
elif args.test[0] == "09_16-09_25":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01), axis=0)

elif args.test[0] == "09_26-10_25":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03), axis=0)


elif args.test[0] == "10_27-11_06":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    y_predict0 = np.concatenate((y_predict04, y_predict05), axis=0)

elif args.test[0] == "11_19-11_24":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+args.test[0]+"8313747812.npy")

elif args.test[0] == "08_11-10_20":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08), axis=0)

elif args.test[0] == "10_21-10_25":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")


elif args.test[0] == "11_19-12_01":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04), axis=0)


elif args.test[0] == "11_19-12_07":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")

    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05), axis=0)


elif args.test[0] == "11_25-12_07":
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")

    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04, y_predict05), axis=0)

elif args.test[0] == "10_27-11_11":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_118313747812.npy")
    y_predict0 = np.concatenate((y_predict04, y_predict05, y_predict06), axis=0)

elif args.test[0] == "10_27-11_08":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    total_length6 = load_data_length("11_07-11_08", "y")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_118313747812.npy")[:total_length6]
    y_predict0 = np.concatenate((y_predict04, y_predict05, y_predict06), axis=0)

elif args.test[0] == "11_25-11_27":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+args.test[0]+"8313747812.npy")
elif args.test[0] == "12_06-12_07" and args.seed == "8313747812":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_06-12_068313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_07-12_078313747812.npy")
    y_predict0 = np.concatenate((y_predict04, y_predict05), axis=0)

elif args.test[0] == "09_21-10_25":
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict0 = np.concatenate((y_predict05, y_predict06, y_predict07, y_predict08, y_predict09), axis=0)


elif ";".join(args.test) == "08_11-10_25;11_19-11_24":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict13 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09, y_predict13), axis=0)

elif ";".join(args.test) == "08_11-10_25;10_27-11_08;11_19-11_24":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict10 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict11 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    total_length6 = load_data_length("11_07-11_08", "y")
    y_predict12 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_118313747812.npy")[:total_length6]
    y_predict13 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09, y_predict10, y_predict11, y_predict12, y_predict13), axis=0)


elif ";".join(args.test) == "08_11-10_25;10_27-11_08":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict10 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_0136685289.npy")
    y_predict11 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_068313747812.npy")
    total_length6 = load_data_length("11_07-11_08", "y")
    y_predict12 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_118313747812.npy")[:total_length6]
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09, y_predict10, y_predict11, y_predict12), axis=0)


elif args.test[0] == "12_07-12_16":
    # y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_07-12_078313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_25;12_02-12_03_12_04-12_05_12_07-12_081977460568.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_25;12_02-12_03_12_04-12_05_12_09-12_091977460568.npy")
    # y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_09-12_098313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_10-12_108313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_11-12_118313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_12-12_128313747812.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_13-12_138313747812.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_14-12_148313747812.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_15-12_158313747812.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_16-12_168313747812.npy")

    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09), axis=0)


elif args.test[0] == "11_19-12_07":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")

    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05), axis=0)


elif args.test[0] == "11_19-12_06":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    total_length5 = load_data_length("12_02-12_06", "y")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")[:total_length5]

    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05), axis=0)


elif ";".join(args.test) == "08_11-10_25;11_19-12_08":
    y_predict00 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_207134507811.npy")
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_312812233223.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103089098350.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_15919771028.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_20919771028.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_21-09_258846659927.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_10-09_20_09_21-09_22_09_26-09_308846659927.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_108754612109.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_203646965883.npy")
    y_predict09 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_2536685289.npy")
    y_predict10 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_19-11_248313747812.npy")
    y_predict11 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_25-11_278313747812.npy")
    y_predict12 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_28-11_298313747812.npy")
    y_predict13 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_30-11_308313747812.npy")
    y_predict14 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_01-12_018313747812.npy")
    y_predict15 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_02-12_078313747812.npy")
    y_predict16 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_12_08-12_088313747812.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08, y_predict09, y_predict10, y_predict11, y_predict12, y_predict13, y_predict14, y_predict15, y_predict16), axis=0)


elif ";".join(args.test) == "12_20-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)



elif ";".join(args.test) == "12_20-01_05":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_06-01_15" and args.seed==8313747812:
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "12_07-01_05":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_01-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_08-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)
elif ";".join(args.test) == "12_12-01_07":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_16-01_23":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")

elif ";".join(args.test) == "12_11-01_09":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_11-01_18":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_188313747812.npy"))

    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "12_07-12_31":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_01-01_05" and args.seed == "8313747812":
    y_list = []
    for file in flist:
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_01-01_07;01_11-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+args.seed+".npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_16-02_06" and args.seed != "8313747812":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_06-01_09;01_11-01_15_01_16-01_19_01_16-01_27"+args.seed+".npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_06-01_09;01_11-01_15_01_16-01_19_01_28-02_06"+args.seed+".npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "01_16-01_27" and args.seed == "8313747812":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_24-01_278313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_16-02_06" and args.seed == "8313747812":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_24-01_278313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_28-02_068313747812.npy"))

    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_28-02_06" and args.seed == "8313747812":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_28-02_068313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)

elif ";".join(args.test) == "12_07-01_07;01_11-01_15":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_06-01_15" and args.seed == "467975215":
    lent = load_data_length("01_01-01_05", "y")
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-12_31_01_01-01_05_01_01-01_15"+args.seed+".npy")[lent:]


elif ";".join(args.test) == "01_01-01_05" and args.seed == "467975215":
    lent = load_data_length("01_01-01_05", "y")
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-12_31_01_01-01_05_01_01-01_15"+args.seed+".npy")[:lent]


elif ";".join(args.test) == "12_11-01_20" and args.seed == "999999":
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_10_12_11-12_14_12_11-12_204608391152.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_20_12_21-12_24_12_21-12_317687624152.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_31_01_01-01_04_01_01-01_107808694296.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_03-01_10_01_11-01_14_01_11-01_208775546016.npy")

    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04), axis=0)



elif ";".join(args.test) == "12_11-02_08" and args.seed == "999999":
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_10_12_11-12_14_12_11-12_204608391152.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_20_12_21-12_24_12_21-12_317687624152.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_31_01_01-01_04_01_01-01_107808694296.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_03-01_10_01_11-01_14_01_11-01_208775546016.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy")
    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06), axis=0)



elif ";".join(args.test) == "12_11-02_17" and args.seed == "999999":
    y_predict01 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_10_12_11-12_14_12_11-12_204608391152.npy")
    y_predict02 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_20_12_21-12_24_12_21-12_317687624152.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-11_30;12_03-12_31_01_01-01_04_01_01-01_107808694296.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_03-01_10_01_11-01_14_01_11-01_208775546016.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy")
    y_list = []
    flag = False
    for file in flist:
        if file == "02_09":
            flag = True
        if flag:
            y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_"+file+"-"+file+"8554873884.npy"))
    y_predict0 = np.concatenate((y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06), axis=0)
    y_predict0 = np.concatenate((y_predict0, y_list), axis=0)


elif ";".join(args.test) == "12_11-01_20" and args.seed == "8313747812":
    y_list = []
    for file in flist:
        if file == "01_11":
            break
        y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+file+"-"+file+"8313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_11-01_158313747812.npy"))
    lent = load_data_length("01_16-01_20", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")[:lent])
    y_predict0 = np.concatenate(y_list, axis=0)
    

elif ";".join(args.test) == "01_21-01_31" and args.seed == "8313747812":
    y_list = []

    
    lent = load_data_length("01_16-01_20", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")[lent:])
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_24-01_278313747812.npy"))
    lent = load_data_length("01_28-01_31", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_28-02_068313747812.npy")[:lent])
    y_predict0 = np.concatenate(y_list, axis=0)



elif ";".join(args.test) == "01_21-02_08" and args.seed == "8313747812":
    y_list = []

    lent = load_data_length("01_16-01_20", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_16-01_238313747812.npy")[lent:])
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_24-01_278313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_28-02_068313747812.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_02_07-02_088313747812.npy"))

    y_predict0 = np.concatenate(y_list, axis=0)




elif ";".join(args.test) == "01_28-02_08" and args.seed == "999999":
    y_list = []
    lent = load_data_length("01_21-01_27", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")[lent:])
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy"))
    
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_21-02_08" and args.seed == "999999":
    y_list = []
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy"))
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy"))
    
    y_predict0 = np.concatenate(y_list, axis=0)


elif ";".join(args.test) == "01_28-02_06" and args.seed == "999999":
    y_list = []
    lent = load_data_length("01_21-01_27", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")[lent:])
    lent = load_data_length("02_01-02_06", "y")
    y_list.append(np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy")[:lent])
    y_predict0 = np.concatenate(y_list, axis=0)



elif ";".join(args.test) == "01_21-01_31" and args.seed == "999999":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_11-01_20_01_21-01_24_01_21-01_319536372242.npy")


elif ";".join(args.test) == "02_01-02_08" and args.seed == "999999":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_02_01-02_088554873884.npy")


elif ";".join(args.test) == "02_01-02_06" and args.seed == "8313747812":
    lent = load_data_length("01_28-01_31", "y")
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_01_28-02_068313747812.npy")[lent:]

elif args.seed == "467975215":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-12_31_01_01-01_05_"+args.test[0]+args.seed+".npy")

elif args.seed != "8313747812":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_12_21-01_31_02_01-02_04_"+args.test[0]+args.seed+".npy")
    # y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_11_19-12_02;10_10-11_08_12_03-12_04_"+args.test[0]+args.seed+".npy")

else:
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_"+args.test[0]+"8313747812.npy")


args.profit_type = str(args.profit_type)
dout = args.dout
np.save(args.profit_type+"dout"+str(dout)+"y0"+"_"+";".join(args.test)+"std"+".npy", y_predict0)
print(data.index.to_numpy())
np.save(args.profit_type+"dout"+str(dout)+"time"+"_"+";".join(args.test)+"std"+".npy", data.index.to_numpy())


print(data['lagtime_order'].to_numpy())

lags_list = data['lagtime_order'].to_numpy()
np.save(args.profit_type+"dout"+str(dout)+"lag"+"_"+";".join(args.test)+"std"+".npy", data['lagtime_order'].to_numpy())
# data_1 = pd.DataFrame()
# data_1['time'] = pd.DataFrame(data.index.to_numpy())
# data_1['predict1'] = pd.DataFrame(y_predict0)
# data_1.index = data_1.time
# print(data_1)
# start = 101775
# data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
data['predict1']=pd.DataFrame(y_predict0, index = data.index)
# print(y_predict0[start:start+100])
# print(data['mid_fu'][start:start+100], data['ap1_fu'][start:start+100], data['bp1_fu'][start:start+100])
buy_price = data['bp1_'+filename].to_numpy()*(1-4/1e4)
buy_price *= (1+np.clip(4*data['predict1'].to_numpy()/1e4, -20/1e4, 0))

sell_price = data['ap1_'+filename].to_numpy()*(1+4/1e4)
sell_price *= (1+np.clip(4*(data['predict1'].to_numpy())/1e4,-0/1e4, 20/1e4))

buy_price2 = data['bp1_'+filename].to_numpy()*(1-4/1e4)
buy_price2 *= (1+np.clip(2*data['predict1'].to_numpy()/1e4, -20/1e4, 0))

sell_price2 = data['ap1_'+filename].to_numpy()*(1+4/1e4)
sell_price2 *= (1+np.clip(2*(data['predict1'].to_numpy())/1e4,-0/1e4, 20/1e4))

# print(buy_price[start:start+100])

data['buy_init'] = pd.DataFrame(buy_price, index = data.index)
data['sell_init'] = pd.DataFrame(sell_price, index = data.index)


data['buy_init2'] = pd.DataFrame(buy_price2, index = data.index)
data['sell_init2'] = pd.DataFrame(sell_price2, index = data.index)


# # print("-------------", pd_buy_price, "-----------")
from influxdb import DataFrameClient
#1: ***.***.***.***
#mk2, 3, 4: 54.65.16.142
client0 = DataFrameClient('***.***.***.***', ******)
client = DataFrameClient('54.65.16.142', ******)
# # client.write_points(df_init, "backtest_init", {})
# # client.write_points(df_trans, "backtest_trans", {})
# # client.write_points(df_rlseq, "backtest_rlseq", {})
if args.write_db:
    i = 0
    for i in range(1, int(len(data[['predict1']])//1e5)):
        print((i-1)*int(1e5), i*int(1e5))
        client.write_points(data[['predict1']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_y0", {})
        client.write_points(std[['std']][(i-1)*int(1e5):i*int(1e5)], args.profit_type+"backtest_std", {})

    print(i*int(1e5), len(data[['predict1']]))
    client.write_points(data[['predict1']][i*int(1e5):], args.profit_type+"backtest_y0", {})
    client.write_points(std[['std']][i*int(1e5):], args.profit_type+"backtest_std", {})


    # for i in range(1, int(len(data[['buy_init']])//1e5)):
    #     print((i-1)*int(1e5), i*int(1e5))
    #     client.write_points(data[['buy_init']][(i-1)*int(1e5):i*int(1e5)], "backtest_buy_init", {})
    # print(i*int(1e5), len(data[['buy_init']]))

    # client.write_points(data[['buy_init']][i*int(1e5):], "backtest_buy_init", {})

    # for i in range(1, int(len(data[['sell_init']])//1e5)):
    #     print((i-1)*int(1e5), i*int(1e5))
    #     client.write_points(data[['sell_init']][(i-1)*int(1e5):i*int(1e5)], "backtest_sell_init", {})
    # print(i*int(1e5), len(data[['sell_init']]))

    # client.write_points(data[['sell_init']][i*int(1e5):], "backtest_sell_init", {})

    # for i in range(1, int(len(data[['buy_init2']])//1e5)):
    #     print((i-1)*int(1e5), i*int(1e5))
    #     client.write_points(data[['buy_init2']][(i-1)*int(1e5):i*int(1e5)], "buy_init2", {})
    #     client0.write_points(data[['buy_init2']][(i-1)*int(1e5):i*int(1e5)], "buy_init2", {})

    # print(i*int(1e5), len(data[['buy_init2']]))

    # client.write_points(data[['buy_init2']][i*int(1e5):], "buy_init2", {})
    # client0.write_points(data[['buy_init2']][i*int(1e5):], "buy_init2", {})

    # for i in range(1, int(len(data[['sell_init2']])//1e5)):
    #     print((i-1)*int(1e5), i*int(1e5))
    #     client.write_points(data[['sell_init2']][(i-1)*int(1e5):i*int(1e5)], "sell_init2", {})
    #     client0.write_points(data[['sell_init2']][(i-1)*int(1e5):i*int(1e5)], "sell_init2", {})

    # print(i*int(1e5), len(data[['sell_init2']]))

    # client.write_points(data[['sell_init2']][i*int(1e5):], "sell_init2", {})
    # client0.write_points(data[['sell_init2']][i*int(1e5):], "sell_init2", {})


# client = DataFrameClient('***.***.***.***', ******)
# result = client.query("SELECT * FROM \"model\" WHERE exchange='fu' AND pair='ETHUSDT' AND  type='transformer' AND account='mk2' AND time >= 1668461947000ms and time <= 1668483550600ms;")
# result['model'].index.name='time'
# raw2 = result['model'].reset_index(level=0)#.astype('float32')
# raw2['time'] = pd.to_datetime(raw2['time']).dt.tz_localize(None)
# raw2 = raw2.set_index('time')
# del result['model']
# print(raw2)

# print(raw2.shape)
@jit
def backtest_original(din, d, y, type):
    state = 'empty'
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'

    resl = []
    lag = 0 
    filename='fu'
    buyin_timepoint, sellin_timepoint = 0, 0
    executed_trades_buy, executed_trades_sell = [], []
    buy_price = 0
    buy_profit = 0
    sell_profit = 0
    for i in range(0, len(data)-1-lag):
        if i % 10000 == 0:
            print(i, executed_trades_buy, executed_trades_sell)
        if state == 'empty':
            buy_price = data['bp1_'+filename][i]*(1-din/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*data[p1][i]/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-thres and tpb != 0 and data[p1][i]>-1.0:
                state = 'buy'
                
                buyin_timepoint = i
                continue
            sell_price = data['ap1_'+filename][i]*(1+din/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            
            tps = data['buypriceT_'+filename][i+1]
            if i == 198:
                print(tps, sell_price, tps >= sell_price+thres)
            if tps >= sell_price+thres and tps != 0 and data[p1][i]<1.0:
                state = 'sell'
                sellin_timepoint = i
                continue
        
        if state == 'buy':
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*data[p1][i]/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+thres and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                resl.append((data.index[i], total_profit))
                cnt += 1
                buy_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                executed_trades_buy.append([buyin_timepoint, i, sell_price / buy_price - 1 + 2*0.4/1e4, buy_profit])

                continue

        if state == 'sell':
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-thres and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
                sell_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                executed_trades_sell.append([sellin_timepoint, i, sell_price / buy_price - 1 + 2*0.4/1e4, sell_profit])

            continue
    print(executed_trades_buy, len(executed_trades_buy))
    print(executed_trades_sell, len(executed_trades_sell))
    print(total_profit, cnt, takercnt, buy_profit, sell_profit)
    return total_profit, cnt, takercnt, resl, executed_trades_buy, executed_trades_sell

def add_vol(l, i):
    l[i][1] += 1



 

def backtest_11(y):
    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    max_p = np.max(data['mid_fu'].to_numpy())
    print(max_p)
    max_p = 1625.985
    data['predict1']=pd.DataFrame(y, index = data.index)
    
    p1='predict1'
    filename='fu'
    profit_b_all, profit_s_all = np.zeros((len(data), 7)), np.zeros((len(data), 7))
    data_p1 = data[p1].to_numpy()
    sum_m12 = {}
    p_d_sum_buy = {1:{i:0 for i in range(0, 6)}, args.bin:{i:0 for i in range(0, 6)}}
    p_d_sum_sell = {1:{i:0 for i in range(0, 6)}, args.bin:{i:0 for i in range(0, 6)}}
    for dout in [args.dout]:
        for m1 in [2]:
            for m2 in [4]:
                # for lag, lag2 in [(1, 1)]:
                for lag, lag2 in [(5, 5), (1, 1), (1, 2), (2, 2), (2, 1)]:
                    if lag == 5 and lag2 == 5:
                        abbr = "2"
                        lag, lag2 = 1, 1
                    else:
                        abbr = ""
                    print("-----------", dout, m1, m2, lag, lag2, "---------------")
                    sell_price = data['ap1_'+filename].to_numpy()*(1+dout/1e4)
                    sell_price *= (1+np.clip(m1*data[p1].to_numpy()/1e4, 0, 20/1e4))*(1+std["std"].to_numpy()/1e4)
                    tp = data['buypriceT'+abbr+'_'+filename][lag2:].to_numpy()
                    tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
                    profit_b = np.zeros((len(data), 7))
                    valid_sellpoint = (np.logical_and(tp >= sell_price+thres, tp != 0)).nonzero()[0]
                    valid_sellprice = np.zeros(len(data))
                    valid_sellprice_index = np.zeros(len(data))
                    start, end = 0, 0
                    for i in range(len(valid_sellpoint)):
                        end = valid_sellpoint[i].astype(int)
                        valid_sellprice[start:end-lag2+1] = sell_price[end]
                        valid_sellprice_index[start:end-lag2+1] = i
                        start = end-lag2+1
                    buckets = [[] for i in range(len(valid_sellpoint))]
                    buy_price_base = data['bp1_'+filename].to_numpy()*(1+np.clip(m2*data[p1].to_numpy()/1e4, -20/1e4, 0))
                    tpb = data['sellpriceT'+abbr+'_'+filename][lag:].to_numpy()
                    tpb = np.concatenate([tpb, np.zeros(lag)], axis=0)
                    p = data['predict1'].to_numpy()
                    for d in range(0, 6):
                        buy_price = data['bp1_'+filename].to_numpy()*(1-d/1e4)
                        buy_price *= (1+np.clip(m2*data[p1].to_numpy()/1e4, -20/1e4, 0))*(1-std["std"].to_numpy()/1e4)
                        valid_buypoint = (np.logical_and(tpb <= buy_price-thres, tpb != 0)).nonzero()[0]

                        if d == 0:
                            valid_buypoint_0 = valid_buypoint
                        for i in range(len(valid_buypoint)):
                            point = valid_buypoint[i]
                            if valid_sellprice[point] != 0:
                                if d == 0:
                                    buckets[valid_sellprice_index[point].astype(int)].append(point)
                                profit_b[point, d] = (valid_sellprice[point]-buy_price[point] + 0.4/1e4*(buy_price[point]+valid_sellprice[point]))/max_p
                    print("valid_sellpoint", valid_sellpoint, len(valid_sellpoint))
                    print("valid_buypoint", valid_buypoint_0, len(valid_buypoint_0))
                    nonemptybuckets = []
                    for i in range(len(buckets)):
                        if len(buckets[i]) != 0:
                            # print(buckets[i], valid_sellpoint[i])
                            nonemptybuckets.append(buckets[i])

                    lines1 = []
                    if args.perform_backtest:
                        p_sum1 = 0
                        for pos in [1, args.bin]:
                            for din in range(0, 6):
                                # p, executed_trades = calculate_profit_with_position(profit_b, valid_sellpoint-lag+1, d=din, position=pos, lag=lag)
                                p, executed_trades, num_tr = calculate_profit_with_chosen(valid_sellpoint-lag2+1, profit_b[:, din], position=pos, lag=lag, lag2=lag2)
                                lines1.append(executed_trades)

                                if din == 4:
                                    executed_trades_0_buy = executed_trades
                                print("with position", pos, din, p, num_tr)
                                p_sum1 += p
                                p_d_sum_buy[pos][din] += p
                    
                    portion = 0.01
                    if args.compute_trade:
                        for pos in [1]:
                            for din in range(0, 6):
                                record = False
                                if din == 4 and lag==1 and lag2==1:
                                    record = True
                                p, profit_position, trades_num, trades, position_np = calculate_profit_with_chosen_2(valid_sellpoint-lag2+1, profit_b[:, din], position=pos, lag=lag, lag2=lag2, record=record)
                                if din == 4:
                                    itemp = abbr+args.profit_type+'d'+str(din)+'_buyprofit_'+'lag'+str(lag)+str(lag2)
                                    itemp2 = abbr+args.profit_type+'d'+str(din)+'_buyposition_'+'lag'+str(lag)+str(lag2)
                                    data[itemp]=pd.DataFrame(np.cumsum(profit_position)*max_p*portion+4700, index = data.index)
                                    data_1 = pd.DataFrame()
                                    data_1['time'] = pd.DataFrame(data.index)
                                    data_1[itemp2]=pd.DataFrame(position_np*portion)
                                    data_1.index = data_1.time
                                    # if args.write_db and abbr == "2":
                                    #     i = 0
                                    #     for i in range(1, int(len(data[[itemp]])//1e5)):
                                    #         print((i-1)*int(1e5), i*int(1e5))
                                    #         client.write_points(data[[itemp]][(i-1)*int(1e5):i*int(1e5)], itemp, {})
                                    #         client.write_points(data_1[[itemp2]][(i-1)*int(1e5):i*int(1e5)], itemp2, {})

                                    #     print(i*int(1e5), len(data[[itemp]]))
                                    #     client.write_points(data[[itemp]][i*int(1e5):], itemp, {}) 
                                    #     client.write_points(data_1[[itemp2]][i*int(1e5):], itemp2, {}) 

                                print("with position", pos, din, p)
                    if args.draw:
                        fig, ax1 = plt.subplots()
                        fig.set_figwidth(16)
                        fig.set_figheight(12)
                        for j in range(0, 6):
                            ax1.plot(np.cumsum(lines1[j])[::1000])

                        plt.legend()
                        plt.show()
                        plt.savefig("results_new/result_"+abbr+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"buyopen_"+str(lag)+str(args.seed)+".png")

                        fig, ax1 = plt.subplots()
                        fig.set_figwidth(16)
                        fig.set_figheight(12)
                        for j in range(0, 6):
                            ax1.plot(np.cumsum(lines1[5+j])[::1000])

                        plt.legend()
                        plt.show()
                        plt.savefig("results_new/result_"+abbr+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"buyopen_"+str(args.bin)+str(lag)+str(args.seed)+".png")


                    np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_sell2ndpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_sellpoint-lag+1)
                    np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_buypoint_0)
                    np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"easy_profit_buy"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", profit_b)
                    np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_sellprice)
                    np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"buy_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", buy_price_base)
                    np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"buy_price_basenop"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", data['bp1_'+filename].to_numpy())
                    np.save(abbr+str(args.profit_type)+"dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+"train.npy", tpb)
                    with open(abbr+str(args.profit_type)+"dout"+str(dout)+"buckets_buy"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", "wb") as fp:   #Pickling
                        pickle.dump(nonemptybuckets, fp)
                    buy_price = data['bp1_'+filename].to_numpy()*(1-dout/1e4)
                    buy_price *= (1+np.clip(m1*data[p1].to_numpy()/1e4, -20/1e4, 0))*(1-std["std"].to_numpy()/1e4)
                    tp = data['sellpriceT'+abbr+'_'+filename][lag2:].to_numpy()
                    tp = np.concatenate([tp, np.zeros(lag2)], axis=0)
                    profit_s = np.zeros((len(data), 7))
                    valid_buypoint = (np.logical_and(tp <= buy_price-thres, tp != 0)).nonzero()[0]
                    # valid_buypoint = (np.logical_and(np.logical_and(tp <= buy_price-thres, tp != 0), p<-1)).nonzero()[0]
                    valid_buyprice = np.zeros(len(data))
                    valid_buyprice_index = np.zeros(len(data))
                    start, end = 0, 0
                    for i in range(len(valid_buypoint)):
                        end = valid_buypoint[i].astype(int)
                        valid_buyprice[start:end-lag2+1] = buy_price[end]
                        valid_buyprice_index[start:end-lag2+1] = i
                        start = end-lag2+1
                    buckets = [[] for i in range(len(valid_buypoint))]
                    sell_price_base = data['ap1_'+filename].to_numpy()*(1+np.clip(m2*data[p1].to_numpy()/1e4, 0, 20/1e4))
                    tps = data['buypriceT'+abbr+'_'+filename][lag:].to_numpy()
                    tps = np.concatenate([tps, np.zeros(lag)], axis=0)
                    
                    for d in range(0, 6):
                        sell_price = data['ap1_'+filename].to_numpy()*(1+d/1e4)
                        sell_price *= (1+np.clip(m2*data[p1].to_numpy()/1e4, 0, 20/1e4))*(1+std["std"].to_numpy()/1e4)
                        valid_sellpoint = np.logical_and(tps >= sell_price+thres, tps != 0).nonzero()[0]
                        
                        # valid_sellpoint = np.logical_and(np.logical_and(tps >= sell_price+thres, tps != 0), p < 1).nonzero()[0]
                        # point = 10420739
                        # if d == 4:
                            # print(point, sell_price[point], tps[point], tps[point] >= sell_price[point]+thres, tps != 0, valid_buyprice[point], (sell_price[point] - valid_buyprice[point] + 0.4/1e4*(sell_price[point] + valid_buyprice[point]))/args.max_p, args.max_p)

                        if d == 0:
                            valid_sellpoint_0 = valid_sellpoint
                        
                        # if d == 4:
                            # for i in range(len(valid_sellpoint)):
                                # print("time?", data.index[valid_sellpoint[i]])
                        for i in range(len(valid_sellpoint)):
                            point = valid_sellpoint[i]
                            if valid_buyprice[point] != 0:
                                if d == 0:
                                    buckets[valid_buyprice_index[point].astype(int)].append(point)
                                profit_s[point, d] = (sell_price[point] - valid_buyprice[point] + 0.4/1e4*(sell_price[point] + valid_buyprice[point]))/max_p
                    print("valid_buypoint", valid_buypoint, len(valid_buypoint))
                    print("valid_sellpoint", valid_sellpoint_0, len(valid_sellpoint_0))

                    print("where???", valid_buypoint, (profit_s[:, 5] != 0).nonzero()[0])
                    
                    nonemptybuckets = []
                    for i in range(len(buckets)):
                        if len(buckets[i]) != 0:
                            # print(buckets[i], valid_buypoint[i])
                            nonemptybuckets.append(buckets[i])
                    lines2 = []
                    if args.perform_backtest:
                    
                        p_sum2 = 0
                        for pos in [1, args.bin]:
                            for din in range(0, 6):
                                # p, executed_trades = calculate_profit_with_position(profit_s, valid_buypoint-lag+1, d=din, position=pos, lag=lag)
                                p, executed_trades, num_tr = calculate_profit_with_chosen(valid_buypoint-lag2+1, profit_s[:, din], position=pos, lag=lag, lag2=lag2)
                                lines2.append(executed_trades)

                                if din == 4:
                                    executed_trades_0_sell = executed_trades
                                print("with position", pos, din, p, num_tr)
                                p_sum2 += p
                                p_d_sum_sell[pos][din] += p
                    # sum_m12[(m1, m2)] = (p_sum1, p_sum2)
                    # print(sum_m12)
                    # np.save("sum_m12.npy", sum_m12)
                    if args.compute_trade:
                        
                        for pos in [1]:
                            for din in range(0, 6):
                                # p, executed_trades, profit_line = calculate_profit_with_position(profit_b, valid_sellpoint-lag+1, d=din, position=pos)
                                if din == 4 and lag==1 and lag2==1:
                                    record = True
                                p, profit_position, trades_num, trades, position_np  = calculate_profit_with_chosen_2(valid_buypoint-lag2+1, profit_s[:, din], position=pos, lag=lag, lag2=lag2, record=record)
                                if din == 4:
                                    itemp = abbr+args.profit_type+'d'+str(din)+'_sellprofit_'+'lag'+str(lag)+str(lag2)
                                    itemp2 = abbr+args.profit_type+'d'+str(din)+'_sellposition_'+'lag'+str(lag)+str(lag2)

                                    data[itemp]=pd.DataFrame(np.cumsum(profit_position)*max_p*portion+5600, index = data.index)
                                    data_1 = pd.DataFrame()
                                    data_1['time'] = pd.DataFrame(data.index)
                                    data_1[itemp2]=pd.DataFrame(position_np*portion)
                                    data_1.index = data_1.time
                                    # for tr in trades:
                                        # print("sell signal, sell in, buy signal, buy in", tr, data.index[tr[0]], data.index[tr[1]], data.index[tr[2]], data.index[tr[3]], profit_position[tr[3]])
                                    
                                    # if args.write_db and abbr == "2":
                                    #     i = 0
                                    #     for i in range(1, int(len(data[[itemp]])//1e5)):
                                    #         print((i-1)*int(1e5), i*int(1e5))
                                    #         client.write_points(data[[itemp]][(i-1)*int(1e5):i*int(1e5)], itemp, {})
                                    #         client.write_points(data_1[[itemp2]][(i-1)*int(1e5):i*int(1e5)], itemp2, {})
                                    #     print(i*int(1e5), len(data[[itemp]]))
                                    #     client.write_points(data[[itemp]][i*int(1e5):], itemp, {}) 
                                    #     client.write_points(data_1[[itemp2]][i*int(1e5):], itemp2, {}) 


                                print("with position", pos, din, p)


                    


                    if args.draw:
                        fig, ax1 = plt.subplots()
                        fig.set_figwidth(16)
                        fig.set_figheight(12)
                        for j in range(0, 6):
                            ax1.plot(np.cumsum(lines2[j])[::1000])

                        plt.legend()
                        plt.show()
                        plt.savefig("results_new/result_"+abbr+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"sellopen_"+str(lag)+str(args.seed)+".png")
                        
                        fig, ax1 = plt.subplots()
                        fig.set_figwidth(16)
                        fig.set_figheight(12)
                        for j in range(0, 6):
                            ax1.plot(np.cumsum(lines2[j+5])[::1000])

                        plt.legend()
                        plt.show()
                        plt.savefig("results_new/result_"+abbr+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"sellopen_"+str(args.bin)+str(lag)+str(args.seed)+".png")

                    # fig, ax1 = plt.subplots()
                    # fig.set_figwidth(16)
                    # fig.set_figheight(12)
                    # for j in range(0, 6):
                    #     ax1.plot(lines1[j]+lines2[j])

                    # plt.legend()
                    # plt.show()
                    # plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"all_"+str(lag)+".png")


                    np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_buy2ndpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_buypoint-lag+1)

                    np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_sellpoint_0)
                    np.save(abbr+args.profit_type+"dout"+str(dout)+"easy_profit_sell"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", profit_s)
                    np.save(abbr+args.profit_type+"dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", valid_buyprice)
                    np.save(abbr+args.profit_type+"dout"+str(dout)+"sell_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", sell_price_base)
                    np.save(abbr+args.profit_type+"dout"+str(dout)+"sell_price_basenop"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", data['ap1_'+filename].to_numpy())
                    np.save(abbr+args.profit_type+"dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+"train.npy", tps)
                    with open(abbr+args.profit_type+"dout"+str(dout)+"buckets_sell"+"_"+";".join(args.test)+"std"+"_"+str(lag)+str(lag2)+".npy", "wb") as fp:   #Pickling
                        pickle.dump(nonemptybuckets, fp)
                    for d in range(0, 6):
                        print(np.sum(profit_b[:, d]), np.sum(profit_s[:, d]))
                    print(np.sum(np.max(profit_b, axis=1)))
                    print(np.sum(np.max(profit_s, axis=1)))
                    profit_b_all  += profit_b
                    profit_s_all  += profit_s

                    # for pos in [5, 10, 10000]:
                    #     for din in range(0, 6):
                    #         p = calculate_profit_with_position(profit_b, valid_sellpoint, d=din, position=pos)
                    #         print(pos, din, p)
            
                # for pos in [1, 5]:
                #     for d in range(0, 6):
                #         print(p_d_sum_buy[pos][d], p_d_sum_sell[pos][d])
        

                # for d in range(0, 6):
                #     print(np.sum(profit_b_all[:, d]), np.sum(profit_s_all[:, d]))

                #     # for j in range(0, 6):
                #     #     print("d, ", j, np.sum(profit_b_all[arr[11000000:]][:, j]), np.sum(profit_b_all[:, j]))
                #     #     print("d, ", j, np.sum(profit_s_all[arr[11000000:]][:, j]), np.sum(profit_s_all[:, j]))

                # profit_b_all_points = (np.sum(profit_b_all, axis=1) != 0).nonzero()[0]
                # print(profit_b_all_points, )
                # vb_train = []
                # vb_valid = []
                # valid_buypoint = []
                # for vb in profit_b_all_points:
                #     if vb in arr_set_train:
                #         vb_train.append(vb)
                #     elif vb in arr_set_valid:
                #         vb_valid.append(vb)
                #     valid_buypoint.append(vb)
                # print(len(vb_train))
                # print(len(vb_valid))
                # print(len(valid_buypoint))
                # vb_train_arr = np.array(vb_train)
                # vb_valid_arr = np.array(vb_valid)
                # valid_buypoint_arr = np.array(valid_buypoint)

                # np.save(args.profit_type+"dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_12"+".npy", valid_buypoint_arr)
                # np.save(args.profit_type+"dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_12"+"train.npy", vb_train_arr)
                # np.save(args.profit_type+"dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_12"+"valid.npy", vb_valid_arr)
                # np.save(args.profit_type+"dout"+str(dout)+"easy_profit_buy"+"_"+";".join(args.test)+"std"+"_12"+".npy", profit_b_all)

                # profit_s_all_points = (np.sum(profit_s_all, axis=1) != 0).nonzero()[0]

                # vs_train = []
                # vs_valid = []
                # valid_sellpoint = []
                # for vs in profit_s_all_points:
                #     if vs in arr_set_train:
                #         vs_train.append(vs)
                #     elif vs in arr_set_valid:
                #         vs_valid.append(vs)
                #     valid_sellpoint.append(vs)
                # vs_train_arr = np.array(vs_train)
                # vs_valid_arr = np.array(vs_valid)
                # valid_sellpoint_arr = np.array(valid_sellpoint)

                # print(len(vs_train))
                # print(len(vs_valid))
                # print(len(valid_sellpoint))

                # np.save(args.profit_type+"dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_12"+".npy", valid_sellpoint_arr)
                # np.save(args.profit_type+"dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_12"+"train.npy", vs_train_arr)
                # np.save(args.profit_type+"dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_12"+"valid.npy", vs_valid_arr)
                # np.save(args.profit_type+"dout"+str(dout)+"easy_profit_sell"+"_"+";".join(args.test)+"std"+"_12"+".npy", profit_s_all)
                # print(np.sum(np.max(profit_b_all, axis=1)))
                # print(np.sum(np.max(profit_s_all, axis=1)))
    return executed_trades_0_buy, executed_trades_0_sell


# def calculate_profit_with_position(profit, valid_sellpoint, d=4, position=args.bin, lag=1):
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     valid_buypoint = (profit[:, d] != 0).nonzero()[0]

#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
#                 return i, True

#     executed_trades = [0]
#     total_profit = 0
#     deferred_position = 1000000000000000
#     for vb in valid_buypoint:
#         if vb >= deferred_position:
#             positions_dict[deferred_position_bin] += 1
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     positions_dict[bin] += 1
#                     # executed_trades.append([vb, valid_sellpoint[bin], profit[vb, d], total_profit])
#             else:
#                 if positions_dict[bin] < position: #因为如果vb是在sellpoint，那么是按照上一个bin的position去判，是否能买入的，然后
#                     total_profit += profit[vb, d]
#                     positions_dict[bin+1] += 1
#                     deferred_position = vb + lag
#                     deferred_position_bin = bin
#                     # positions_dict[bin] += 1 # should be deferred to vb + lag 

#                     # executed_trades.append([vb, valid_sellpoint[bin+1], profit[vb, d], total_profit])
#         else:
#             print("why larger")
#     # print(executed_trades, len(executed_trades))
#     return total_profit, executed_trades            


# def calculate_profit_with_position_2(y0, valid_sellpoint, d=4, position=args.bin, lag=1):
#     # print(valid_sellpoint)

#     profit = y0
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     valid_buypoint = (y0[:, d] != 0).nonzero()[0]
#     profit_position = np.zeros(len(y0))

#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
#                 return i, True

                

#     total_profit = 0
#     deferred_position = 1e21
#     for vb in valid_buypoint:
#         if vb >= deferred_position:
#             positions_dict[deferred_position_bin] += 1
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     profit_position[vb] = profit[vb, d]
#                     positions_dict[bin] += 1
#             else:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     profit_position[vb] = profit[vb, d]
#                     positions_dict[bin+1] += 1
#                     deferred_position = vb + lag
#                     deferred_position_bin = bin
#         else:
#             print("why larger")
#     return total_profit, profit_position    

@jit
def calculate_profit_with_position(y0, valid_sellpoint, d=4, position=args.bin, lag=1):
    # print(valid_sellpoint)

    profit = y0
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    valid_buypoint = (y0[:, d] != 0).nonzero()[0]
    profit_position = np.zeros(len(y0))
    deferred_position_bin = -1
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True
            
    total_profit = 0
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items    
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
            else:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
        else:
            print("why larger")
    return total_profit, profit_position      
      

@jit
def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=args.bin, lag=1, lag2=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + lag + lag2 -1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[vb] = chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin+1] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[vb] = chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    return total_profit, profit_position, sum(positions_dict)


def calculate_profit_with_chosen_trades(valid_sellpoint, chosen_value_total, position=args.bin, lag=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True
    trades = []
    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    true_position_dict =  [0 for i in range(len(valid_sellpoint))]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin]+2*lag-1] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    trades.append((vb, vb+lag, valid_sellpoint[bin]+lag-1, valid_sellpoint[bin]+2*lag-1))
                    true_position_dict[bin] += 1

                    # print(deferred_positions)

            else:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[valid_sellpoint[bin+1]+2*lag-1] += chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    trades.append((vb, vb+lag, valid_sellpoint[bin+1]+lag-1, valid_sellpoint[bin+1]+2*lag-1))
                    true_position_dict[bin+1] += 1

                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    return total_profit, profit_position, trades, true_position_dict


 

import pickle
dic = {}
for a in [1.0]:
    for b in [1000]:
            for d in [4]:
                import matplotlib.pyplot as plt
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                ax2 = ax1.twinx()
                
                # total_profit, cnt, takercnt, resl, executed_trades_buy, executed_trades_sell = backtest_original(0, 4, y_predict0, "predict")
                executed_trades_0_buy, executed_trades_0_sell = backtest_11(y_predict0)
                # np.save('executed_trades_buy.npy', executed_trades_buy)
                # np.save('executed_trades_sell.npy', executed_trades_sell)
                # np.save('executed_trades_0_buy.npy', executed_trades_0_buy)
                # np.save('executed_trades_0_sell.npy', executed_trades_0_sell)

                

                # # total_profit, cnt, takercnt, resl, volume_buy, volume_sell 
                # for i in range(max(len(executed_trades_buy), len(executed_trades_0_buy))):
                #     if i < len(executed_trades_buy):
                #         print(i, "from ori", executed_trades_buy[i])
                #     if i < len(executed_trades_0_buy):
                #         print(i, "from speed", executed_trades_0_buy[i])

                # for i in range(max(len(executed_trades_sell), len(executed_trades_0_sell))):
                #     if i < len(executed_trades_sell):
                #         print(i, "from ori", executed_trades_sell[i])
                #     if i < len(executed_trades_0_sell):
                #         print(i, "from speed", executed_trades_0_sell[i])

                # if args.double_test:
                ax1.plot(*zip(*resl))

                plt.grid()
                ax2.plot(data.index, (data['mid_fu']), color='blue')


                plt.title(args.arch+";a:"+str(a)+"b:"+str(b)+"d:"+str(d))
                plt.legend()
                plt.show()
                plt.savefig("result"+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(a)+"_"+str(b)+"_"+str(d)+"compare.png")
