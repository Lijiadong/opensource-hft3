start='2023-01-18'
end='2023-01-27'

start=$(date -d $start +%Y%m%d)
end=$(date -d $end +%Y%m%d)
filen="x_data"
while [[ $start -le $end ]]
do
        echo $(date -d $start +%m_%d)
        wdate=$(date -d $start +%m_%d)
        echo $wdate
        mv data_6/xnn5_$wdate.pkl $filen/xnn5_$wdate.pkl
        start=$(date -d"$start + 1 day" +"%Y%m%d")
done
