import numpy as np
import pandas as pd
from args import args
import datetime
import matplotlib.dates as dates
import matplotlib.pyplot as plt
from numba import jit
import wandb
np.set_printoptions(threshold=100)

wandb.init(project="stock_prediction", entity="zhouuxx96")

def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

print(args.test, "???")
flist = genflist(args.test[0])
print(flist)
filename = "fu"
data = pd.DataFrame()
first = True
tmp_lst = []
y_lst = []
for file in flist:
    if args.test[0] == "09_26-11_01" and file == "10_26":
        continue
    print(file)
    tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
    tmp = pd.DataFrame(tmp, columns=['mid_fu', "predict1", 'ap1_fu', 'bp1_fu', 'sellpriceT_'+filename, 'buypriceT_'+filename])
    print(tmp)
    tmp_lst.append(tmp)
    tmp = np.load('data_6/y_'+file+'.npy')
    y_lst.append(tmp)

ts = pd.Timestamp(2022, 11, 9, 15, 32, 46)
data = pd.concat(tmp_lst)
print((data.index > ts).nonzero()[0])

print(data.index[(data.index > ts).nonzero()[0][0]:(data.index > ts).nonzero()[0][0]+100])

dout = 4
np.save("14dout"+str(dout)+"data"+"_"+";".join(args.test)+"std"+".npy", data.to_numpy())

y_true = np.concatenate(y_lst, axis=0)
import os


path = "***.***.***.***"



if args.test[0] == "08_11-09_15":
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_201961813472.npy")
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_313295164704.npy")
    y_predict02 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103377339775.npy")
    y_predict03 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_155479942502.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03), axis=0)
elif args.test[0] == "09_16-09_25":
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_205479942502.npy")
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_257757296072.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01), axis=0)

elif args.test[0] == "09_26-10_26":
    len1 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_257757296072.npy").shape[0]
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_307757296072.npy")[len1:]
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_105572326033.npy")
    y_predict02 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_207066615716.npy")
    y_predict03 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_263902828398.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03), axis=0)


elif args.test[0] == "09_26-10_25":
    len1 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_257757296072.npy").shape[0]
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_307757296072.npy")[len1:]
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_105572326033.npy")
    y_predict02 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_207066615716.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_253902828398.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03), axis=0)

elif args.test[0] == "10_15-10_22":
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_15-10_207066615716.npy")
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_223902828398.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01), axis=0)


elif args.test[0] == "10_15-10_26":
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_15-10_207066615716.npy")
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_263902828398.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01), axis=0)

elif args.test[0] == "08_11-10_20":
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_201961813472.npy")
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_313295164704.npy")
    y_predict02 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103377339775.npy")
    y_predict03 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_155479942502.npy")
    y_predict04 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_205479942502.npy")
    y_predict05 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_307757296072.npy")
    y_predict06 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_105572326033.npy")
    y_predict07 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_207066615716.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07), axis=0)
elif args.test[0] == "08_11-10_20":
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_201961813472.npy")
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_313295164704.npy")
    y_predict02 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103377339775.npy")
    y_predict03 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_155479942502.npy")
    y_predict04 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_205479942502.npy")
    y_predict05 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_307757296072.npy")
    y_predict06 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_105572326033.npy")
    y_predict07 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_207066615716.npy")
    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07), axis=0)

elif args.test[0] == "10_21-10_26":
    y_predict0 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_263902828398.npy")

elif args.test[0] == "10_26-10_26":
    y_predict0 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_26-10_263902828398.npy")


elif args.test[0] == "10_27-11_01":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_013902828398.npy")

elif args.test[0] == "08_11-10_25":
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_01-08_10_08_11-08_12_08_11-08_201961813472.npy")
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_11-08_20_08_21-08_22_08_21-08_313295164704.npy")
    y_predict02 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_07_21-08_31_09_01-09_02_09_01-09_103377339775.npy")
    y_predict03 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_11-09_155479942502.npy")
    y_predict04 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_01-09_10_09_11-09_12_09_16-09_205479942502.npy")
    y_predict05 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_307757296072.npy")
    y_predict06 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_105572326033.npy")
    y_predict07 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_207066615716.npy")
    y_predict08 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_253902828398.npy")

    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04, y_predict05, y_predict06, y_predict07, y_predict08), axis=0)
    # y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_013902828398.npy")

elif args.test[0] == "10_21-10_25":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_253902828398.npy")

    
elif args.test[0] == "09_26-11_01":
    len1 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_257757296072.npy").shape[0]
    y_predict00 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_08-09_20_09_21-09_22_09_21-09_307757296072.npy")[len1:]
    y_predict01 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_08_21-09_30_10_01-10_02_10_01-10_105572326033.npy")
    y_predict02 = np.load("data_9/y0_TSTransformerEncoderClassiregressor_09_01-10_10_10_11-10_12_10_11-10_207066615716.npy")
    y_predict03 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_21-10_253902828398.npy")
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_013902828398.npy")

    y_predict0 = np.concatenate((y_predict00, y_predict01, y_predict02, y_predict03, y_predict04), axis=0)

elif args.test[0] == "11_02-11_04":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_044228653984.npy")
    
elif args.test[0] == "11_05-11_05":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_05-11_054228653984.npy")

  
elif args.test[0] == "11_06-11_06":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_06-11_064228653984.npy")


elif args.test[0] == "11_07-11_07":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_07-11_074228653984.npy")


elif args.test[0] == "11_08-11_08":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_08-11_084228653984.npy")


elif args.test[0] == "11_09-11_09":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_09-11_094228653984.npy")


elif args.test[0] == "11_10-11_10":
    y_predict0 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_10-11_104228653984.npy")

elif args.test[0] == "10_27-11_06":
    y_predict04 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_11-10_20_10_21-10_22_10_27-11_013902828398.npy")
    y_predict05 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_02-11_044228653984.npy")
    y_predict06 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_05-11_054228653984.npy")
    y_predict07 = np.load("data_7/y0_TSTransformerEncoderClassiregressor_09_21-10_30_10_31-11_01_11_06-11_064228653984.npy")

    y_predict0 = np.concatenate((y_predict04, y_predict05, y_predict06, y_predict07), axis=0)


print(y_predict0[852260:852260+100])



@jit
def backtest_original(din, d, y, type):
    state = 'empty'
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)

    p1='predict1'

    resl = []
    lag = 0 
    filename='fu'
    buyin_timepoint, sellin_timepoint = 0, 0
    executed_trades_buy, executed_trades_sell = [], []
    buy_price = 0
    buy_profit = 0
    sell_profit = 0
    for i in range(0, len(data)-1-lag):
        if i % 10000 == 0:
            print(i, executed_trades_buy, executed_trades_sell)
        if state == 'empty':
            buy_price = data['bp1_'+filename][i]*(1-din/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(4*data[p1][i]/1e4, -20/1e4, 0/1e4))
            tpb = data['sellpriceT_'+filename][i+1]
            if tpb <= buy_price-0.01 and tpb != 0 and data[p1][i]>-1.0:
                state = 'buy'
                
                buyin_timepoint = i
                continue
            sell_price = data['ap1_'+filename][i]*(1+din/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4))
            
            tps = data['buypriceT_'+filename][i+1]
            if i == 198:
                print(tps, sell_price, tps >= sell_price+0.01)
            if tps >= sell_price+0.01 and tps != 0 and data[p1][i]<1.0:
                state = 'sell'
                sellin_timepoint = i
                continue
        
        if state == 'buy':
            sell_price = data['ap1_'+filename][i]*(1+d/1e4)
            if type == "predict":
                sell_price *= (1+np.clip(2*data[p1][i]/1e4,-0/1e4, 20/1e4))
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                resl.append((data.index[i], total_profit))
                cnt += 1
                buy_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                executed_trades_buy.append([buyin_timepoint, i, sell_price / buy_price - 1 + 2*0.4/1e4, buy_profit])

                continue

        if state == 'sell':
            buy_price = data['bp1_'+filename][i]*(1-d/1e4)
            if type == "predict":
                buy_price *= (1+np.clip(2*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4))
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                state = 'empty'
                total_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
                sell_profit += sell_price / buy_price - 1 + 2*0.4/1e4
                executed_trades_sell.append([sellin_timepoint, i, sell_price / buy_price - 1 + 2*0.4/1e4, sell_profit])

            continue
    print(executed_trades_buy, len(executed_trades_buy))
    print(executed_trades_sell, len(executed_trades_sell))
    print(total_profit, cnt, takercnt, buy_profit, sell_profit)
    return total_profit, cnt, takercnt, resl, executed_trades_buy, executed_trades_sell

def add_vol(l, i):
    l[i][1] += 1



 


def backtest_11(y):
    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    max_p = np.max(data['mid_fu'].to_numpy())
    print(max_p)
    max_p = 1625.985
    data['predict1']=pd.DataFrame(y, index = data.index)
    p1='predict1'
    filename='fu'
    d_num = 22
    profit_b_all, profit_s_all = np.zeros((len(data), d_num)), np.zeros((len(data), d_num))
    data_p1 = data[p1].to_numpy()
    sum_m12 = {}
    
    p_d_sum_buy = {1:{i:0 for i in range(0, d_num-1)}, 5:{i:0 for i in range(0, d_num-1)}}
    p_d_sum_sell = {1:{i:0 for i in range(0, d_num-1)}, 5:{i:0 for i in range(0, d_num-1)}}
    for dout in [4]:
        for m1 in [2]:
            for m2 in [4]:
                for lag in [1,2]:
                    print("-----------", dout, m1, m2, lag, "---------------")
                    sell_price = data['ap1_'+filename].to_numpy()*(1+dout/1e4)
                    sell_price *= (1+np.clip(m1*data[p1].to_numpy()/1e4, 0, 20/1e4))
                    tp = data['buypriceT_'+filename][lag:].to_numpy()
                    tp = np.concatenate([tp, np.zeros(lag)], axis=0)
                    profit_b = np.zeros((len(data), d_num))
                    valid_sellpoint = (np.logical_and(tp >= sell_price+0.01, tp != 0)).nonzero()[0]
                    valid_sellprice = np.zeros(len(data))
                    valid_sellprice_index = np.zeros(len(data))
                    start, end = 0, 0
                    for i in range(len(valid_sellpoint)):
                        end = valid_sellpoint[i].astype(int)
                        valid_sellprice[start:end-lag+1] = sell_price[end]
                        valid_sellprice_index[start:end-lag+1] = i
                        start = end-lag+1
                    buckets = [[] for i in range(len(valid_sellpoint))]
                    buy_price_base = data['bp1_'+filename].to_numpy()*(1+np.clip(m2*data[p1].to_numpy()/1e4, -20/1e4, 0))
                    tpb = data['sellpriceT_'+filename][lag:].to_numpy()
                    tpb = np.concatenate([tpb, np.zeros(lag)], axis=0)
                    for d in range(0, d_num-1):
                        buy_price = data['bp1_'+filename].to_numpy()*(1-d/1e4)
                        buy_price *= (1+np.clip(m2*data[p1].to_numpy()/1e4, -20/1e4, 0))
                        # tpb = data['sellpriceT_'+filename][lag:].to_numpy()
                        # tpb = np.concatenate([tpb, np.zeros(lag)], axis=0)
                        valid_buypoint = np.logical_and(tpb <= buy_price-0.01, tpb != 0).nonzero()[0]
                        if d == 0:
                            valid_buypoint_0 = valid_buypoint
                        for i in range(len(valid_buypoint)):
                            point = valid_buypoint[i]
                            if valid_sellprice[point] != 0:
                                if d == 0:
                                    buckets[valid_sellprice_index[point].astype(int)].append(point)
                                profit_b[point, d] = (valid_sellprice[point]-buy_price[point] + 0.4/1e4*(buy_price[point]+valid_sellprice[point]))/max_p
                    print("valid_sellpoint", valid_sellpoint, len(valid_sellpoint))
                    print("valid_buypoint", valid_buypoint_0, len(valid_buypoint_0))
                    nonemptybuckets = []
                    for i in range(len(buckets)):
                        if len(buckets[i]) != 0:
                            # print(buckets[i], valid_sellpoint[i])
                            nonemptybuckets.append(buckets[i])
                    p_sum1 = 0
                    lines1 = []
                    for pos in [1, 5]:
                        for din in range(0, d_num-1):
                            # p, executed_trades = calculate_profit_with_position(profit_b, valid_sellpoint-lag+1, d=din, position=pos, lag=lag)
                            p, executed_trades, num_tr = calculate_profit_with_chosen(valid_sellpoint-lag+1, profit_b[:, din], position=pos, lag=lag)

                            if din == 4:
                                executed_trades_0_buy = executed_trades
                            print("with position", pos, din, p, num_tr)
                            p_sum1 += p
                            p_d_sum_buy[pos][din] += p
                    

                    # for pos in [1]:
                    #     for din in range(0, 6):
                    #         p, profit_line = calculate_profit_with_position_2(profit_b, valid_sellpoint-lag+1, d=din, position=pos)
                    #         lines1.append(np.cumsum(profit_line))
                    #         print("with position", pos, din, p)

                    # fig, ax1 = plt.subplots()
                    # fig.set_figwidth(16)
                    # fig.set_figheight(12)
                    # for j in range(0, 6):
                    #     ax1.plot(lines1[j])

                    # plt.legend()
                    # plt.show()
                    # plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"buyopen_"+str(lag)+".png")
                    

                    arr = np.load("arr.npy")
                    arr_set_train = set(arr[:11000000].flatten())
                    # print(arr_set_train)
                    arr_set_valid = set(arr[11000000:].flatten())
                    # print(arr_set_valid)
                    valid_buypoint = []
                    vb_train = []
                    vb_valid = []
                    for vb in valid_buypoint_0:
                        if vb >= end:
                            break
                        if vb in arr_set_train:
                            vb_train.append(vb)
                        elif vb in arr_set_valid:
                            vb_valid.append(vb)
                        valid_buypoint.append(vb)
                    print(len(vb_train))
                    print(len(vb_valid))
                    print(len(valid_buypoint))
                    vb_train_arr = np.array(vb_train)
                    vb_valid_arr = np.array(vb_valid)
                    valid_buypoint_arr = np.array(valid_buypoint)

                    np.save("14dout"+str(dout)+"valid_sell2ndpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", valid_sellpoint-lag+1)
                    np.save("14dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", valid_buypoint_arr)
                    np.save("14dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+"train.npy", vb_train_arr)
                    np.save("14dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+"valid.npy", vb_valid_arr)
                    np.save("14dout"+str(dout)+"easy_profit_buy"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", profit_b)

                    np.save("14dout"+str(dout)+"valid_sellprice"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", valid_sellprice)
                    np.save("14dout"+str(dout)+"buy_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", buy_price_base)
                    np.save("14dout"+str(dout)+"tpb"+"_"+";".join(args.test)+"std"+"_"+str(lag)+"train.npy", tpb)
                    with open("14dout"+str(dout)+"buckets_buy"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", "wb") as fp:   #Pickling
                        pickle.dump(nonemptybuckets, fp)
                    buy_price = data['bp1_'+filename].to_numpy()*(1-dout/1e4)
                    buy_price *= (1+np.clip(m1*data[p1].to_numpy()/1e4, -20/1e4, 0))
                    tp = data['sellpriceT_'+filename][lag:].to_numpy()
                    tp = np.concatenate([tp, np.zeros(lag)], axis=0)
                    profit_s = np.zeros((len(data), d_num))
                    valid_buypoint = (np.logical_and(tp <= buy_price-0.01, tp != 0)).nonzero()[0]
                    valid_buyprice = np.zeros(len(data))
                    valid_buyprice_index = np.zeros(len(data))
                    start, end = 0, 0
                    for i in range(len(valid_buypoint)):
                        end = valid_buypoint[i].astype(int)
                        valid_buyprice[start:end-lag+1] = buy_price[end]
                        valid_buyprice_index[start:end-lag+1] = i
                        start = end-lag+1
                    buckets = [[] for i in range(len(valid_buypoint))]
                    sell_price_base = data['ap1_'+filename].to_numpy()*(1+np.clip(m2*data[p1].to_numpy()/1e4, 0, 20/1e4))
                    tps = data['buypriceT_'+filename][lag:].to_numpy()
                    tps = np.concatenate([tps, np.zeros(lag)], axis=0)

                    for d in range(0, d_num-1):
                        sell_price = data['ap1_'+filename].to_numpy()*(1+d/1e4)
                        sell_price *= (1+np.clip(m2*data[p1].to_numpy()/1e4, 0, 20/1e4))
                        
                        valid_sellpoint = np.logical_and(tps >= sell_price+0.01, tps != 0).nonzero()[0]
                        # point = 10420739
                        # if d == 4:
                            # print(point, sell_price[point], tps[point], tps[point] >= sell_price[point]+0.01, tps != 0, valid_buyprice[point], (sell_price[point] - valid_buyprice[point] + 0.4/1e4*(sell_price[point] + valid_buyprice[point]))/args.max_p, args.max_p)

                        if d == 0:
                            valid_sellpoint_0 = valid_sellpoint
                        for i in range(len(valid_sellpoint)):
                            point = valid_sellpoint[i]
                            if valid_buyprice[point] != 0:
                                if d == 0:
                                    buckets[valid_buyprice_index[point].astype(int)].append(point)
                                profit_s[point, d] = (sell_price[point] - valid_buyprice[point] + 0.4/1e4*(sell_price[point] + valid_buyprice[point]))/max_p
                    print("valid_buypoint", valid_buypoint, len(valid_buypoint))
                    print("valid_sellpoint", valid_sellpoint_0, len(valid_sellpoint_0))
                    nonemptybuckets = []
                    for i in range(len(buckets)):
                        if len(buckets[i]) != 0:
                            # print(buckets[i], valid_buypoint[i])
                            nonemptybuckets.append(buckets[i])
                    p_sum2 = 0
                    for pos in [1, 5]:
                        for din in range(0, d_num-1):
                            # p, executed_trades = calculate_profit_with_position(profit_s, valid_buypoint-lag+1, d=din, position=pos, lag=lag)
                            p, executed_trades, num_tr = calculate_profit_with_chosen(valid_buypoint-lag+1, profit_s[:, din], position=pos, lag=lag)

                            if din == 4:
                                executed_trades_0_sell = executed_trades
                            print("with position", pos, din, p, num_tr)
                            p_sum2 += p
                            p_d_sum_sell[pos][din] += p
                    sum_m12[(m1, m2)] = (p_sum1, p_sum2)
                    print(sum_m12)
                    # np.save("sum_m12.npy", sum_m12)
                    # lines2 = []
                    # for pos in [1]:
                    #     for din in range(0, 6):
                    #         # p, executed_trades, profit_line = calculate_profit_with_position(profit_b, valid_sellpoint-lag+1, d=din, position=pos)
                    #         p, profit_line = calculate_profit_with_position_2(profit_s, valid_buypoint-lag+1, d=din, position=pos)

                    #         lines2.append(np.cumsum(profit_line))
                    #         # if din == 0:
                    #             # executed_trades_0 = executed_trades
                    #         print("with position", pos, din, p)


                    

                    # fig, ax1 = plt.subplots()
                    # fig.set_figwidth(16)
                    # fig.set_figheight(12)
                    # for j in range(0, 6):
                    #     ax1.plot(lines2[j])

                    # plt.legend()
                    # plt.show()
                    # plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"sellopen_"+str(lag)+".png")

                    # fig, ax1 = plt.subplots()
                    # fig.set_figwidth(16)
                    # fig.set_figheight(12)
                    # for j in range(0, 6):
                    #     ax1.plot(lines1[j]+lines2[j])

                    # plt.legend()
                    # plt.show()
                    # plt.savefig("results_new/result_"+args.arch+";".join(args.train)+"_"+";".join(args.test)+"_"+";".join(args.test2)+"all_"+str(lag)+".png")


                    vs_train = []
                    vs_valid = []
                    valid_sellpoint = []
                    for vs in valid_sellpoint_0:
                        if vs >= end:
                            break
                        if vs in arr_set_train:
                            # print(vs, "in train")
                            vs_train.append(vs)
                        elif vs in arr_set_valid:
                            # print(vs, "in valid")
                            vs_valid.append(vs)
                        valid_sellpoint.append(vs)
                    vs_train_arr = np.array(vs_train)
                    vs_valid_arr = np.array(vs_valid)
                    valid_sellpoint_arr = np.array(valid_sellpoint)

                    print(len(vs_train))
                    print(len(vs_valid))
                    print(len(valid_sellpoint))

                    np.save("14dout"+str(dout)+"valid_buy2ndpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", valid_buypoint-lag+1)

                    np.save("14dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", valid_sellpoint_arr)
                    np.save("14dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+"train.npy", vs_train_arr)
                    np.save("14dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_"+str(lag)+"valid.npy", vs_valid_arr)
                    np.save("14dout"+str(dout)+"easy_profit_sell"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", profit_s)
                    np.save("14dout"+str(dout)+"valid_buyprice"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", valid_buyprice)
                    np.save("14dout"+str(dout)+"sell_price_base"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", sell_price_base)
                    np.save("14dout"+str(dout)+"tps"+"_"+";".join(args.test)+"std"+"_"+str(lag)+"train.npy", tps)
                    with open("14dout"+str(dout)+"buckets_sell"+"_"+";".join(args.test)+"std"+"_"+str(lag)+".npy", "wb") as fp:   #Pickling
                        pickle.dump(nonemptybuckets, fp)
                    for d in range(0, d_num-1):
                        print(np.sum(profit_b[:, d]), np.sum(profit_s[:, d]))
                    print(np.sum(np.max(profit_b, axis=1)))
                    print(np.sum(np.max(profit_s, axis=1)))
                    profit_b_all  += profit_b
                    profit_s_all  += profit_s

                    # for pos in [5, 10, 10000]:
                    #     for din in range(0, 6):
                    #         p = calculate_profit_with_position(profit_b, valid_sellpoint, d=din, position=pos)
                    #         print(pos, din, p)
            
                for pos in [1, 5]:
                    for d in range(0, d_num-1):
                        print(p_d_sum_buy[pos][d], p_d_sum_sell[pos][d])
        

                for d in range(0, d_num-1):
                    print(np.sum(profit_b_all[:, d]), np.sum(profit_s_all[:, d]))

                    # for j in range(0, 6):
                    #     print("d, ", j, np.sum(profit_b_all[arr[11000000:]][:, j]), np.sum(profit_b_all[:, j]))
                    #     print("d, ", j, np.sum(profit_s_all[arr[11000000:]][:, j]), np.sum(profit_s_all[:, j]))

                profit_b_all_points = (np.sum(profit_b_all, axis=1) != 0).nonzero()[0]
                print(profit_b_all_points, )
                vb_train = []
                vb_valid = []
                valid_buypoint = []
                for vb in profit_b_all_points:
                    if vb in arr_set_train:
                        vb_train.append(vb)
                    elif vb in arr_set_valid:
                        vb_valid.append(vb)
                    valid_buypoint.append(vb)
                print(len(vb_train))
                print(len(vb_valid))
                print(len(valid_buypoint))
                vb_train_arr = np.array(vb_train)
                vb_valid_arr = np.array(vb_valid)
                valid_buypoint_arr = np.array(valid_buypoint)

                np.save("14dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_12"+".npy", valid_buypoint_arr)
                np.save("14dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_12"+"train.npy", vb_train_arr)
                np.save("14dout"+str(dout)+"valid_buypoint"+"_"+";".join(args.test)+"std"+"_12"+"valid.npy", vb_valid_arr)
                np.save("14dout"+str(dout)+"easy_profit_buy"+"_"+";".join(args.test)+"std"+"_12"+".npy", profit_b_all)

                profit_s_all_points = (np.sum(profit_s_all, axis=1) != 0).nonzero()[0]

                vs_train = []
                vs_valid = []
                valid_sellpoint = []
                for vs in profit_s_all_points:
                    if vs in arr_set_train:
                        vs_train.append(vs)
                    elif vs in arr_set_valid:
                        vs_valid.append(vs)
                    valid_sellpoint.append(vs)
                vs_train_arr = np.array(vs_train)
                vs_valid_arr = np.array(vs_valid)
                valid_sellpoint_arr = np.array(valid_sellpoint)

                print(len(vs_train))
                print(len(vs_valid))
                print(len(valid_sellpoint))

                np.save("14dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_12"+".npy", valid_sellpoint_arr)
                np.save("14dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_12"+"train.npy", vs_train_arr)
                np.save("14dout"+str(dout)+"valid_sellpoint"+"_"+";".join(args.test)+"std"+"_12"+"valid.npy", vs_valid_arr)
                np.save("14dout"+str(dout)+"easy_profit_sell"+"_"+";".join(args.test)+"std"+"_12"+".npy", profit_s_all)
                print(np.sum(np.max(profit_b_all, axis=1)))
                print(np.sum(np.max(profit_s_all, axis=1)))
    return executed_trades_0_buy, executed_trades_0_sell


# def calculate_profit_with_position(profit, valid_sellpoint, d=4, position=5, lag=1):
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     valid_buypoint = (profit[:, d] != 0).nonzero()[0]

#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
#                 return i, True

#     executed_trades = [0]
#     total_profit = 0
#     deferred_position = 1000000000000000
#     for vb in valid_buypoint:
#         if vb >= deferred_position:
#             positions_dict[deferred_position_bin] += 1
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     positions_dict[bin] += 1
#                     # executed_trades.append([vb, valid_sellpoint[bin], profit[vb, d], total_profit])
#             else:
#                 if positions_dict[bin] < position: #因为如果vb是在sellpoint，那么是按照上一个bin的position去判，是否能买入的，然后
#                     total_profit += profit[vb, d]
#                     positions_dict[bin+1] += 1
#                     deferred_position = vb + lag
#                     deferred_position_bin = bin
#                     # positions_dict[bin] += 1 # should be deferred to vb + lag 

#                     # executed_trades.append([vb, valid_sellpoint[bin+1], profit[vb, d], total_profit])
#         else:
#             print("why larger")
#     # print(executed_trades, len(executed_trades))
#     return total_profit, executed_trades            


# def calculate_profit_with_position_2(y0, valid_sellpoint, d=4, position=5, lag=1):
#     # print(valid_sellpoint)

#     profit = y0
#     positions_dict = [0 for i in range(len(valid_sellpoint))]
#     valid_buypoint = (y0[:, d] != 0).nonzero()[0]
#     profit_position = np.zeros(len(y0))

#     def get_loc(vb):
#         for i in range(len(valid_sellpoint)):
#             if vb < valid_sellpoint[i]:
#                 return i, False
#             if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
#                 return i, True

                

#     total_profit = 0
#     deferred_position = 1e21
#     for vb in valid_buypoint:
#         if vb >= deferred_position:
#             positions_dict[deferred_position_bin] += 1
#         if vb < valid_sellpoint[-1]:
#             bin, atpoint = get_loc(vb)
#             if not atpoint:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     profit_position[vb] = profit[vb, d]
#                     positions_dict[bin] += 1
#             else:
#                 if positions_dict[bin] < position:
#                     total_profit += profit[vb, d]
#                     profit_position[vb] = profit[vb, d]
#                     positions_dict[bin+1] += 1
#                     deferred_position = vb + lag
#                     deferred_position_bin = bin
#         else:
#             print("why larger")
#     return total_profit, profit_position    

@jit
def calculate_profit_with_position(y0, valid_sellpoint, d=4, position=5, lag=1):
    # print(valid_sellpoint)

    profit = y0
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    valid_buypoint = (y0[:, d] != 0).nonzero()[0]
    profit_position = np.zeros(len(y0))
    deferred_position_bin = -1
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True
            
    total_profit = 0
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items    
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
            else:
                if positions_dict[bin] < position:
                    total_profit += profit[vb, d]
                    profit_position[vb] = profit[vb, d]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
        else:
            print("why larger")
    return total_profit, profit_position      
      

@jit
def calculate_profit_with_chosen(valid_sellpoint, chosen_value_total, position=5, lag=1):
    # print(valid_sellpoint)
    chosen_vt = chosen_value_total
    positions_dict = [0 for i in range(len(valid_sellpoint))]
    # profit_positions = [0 for i in range(len(valid_sellpoint))]
    # addedvb_positions = [[] for i in range(len(valid_sellpoint))]

    valid_buypoint = (chosen_vt != 0).nonzero()[0]
    # for i in range(len(chosen_vt)):
        # print(chosen_vt[i])
    profit_position = np.zeros(len(chosen_vt))
    def get_loc(vb):
        for i in range(len(valid_sellpoint)):
            if vb < valid_sellpoint[i]:
                return i, False
            if valid_sellpoint[i] <= vb and vb < valid_sellpoint[i] + 2*lag-1:
                return i, True

    total_profit = 0
    # print(len(valid_buypoint))
    deferred_positions = [(0, 0)]
    deferred_positions = deferred_positions[1:]
    for vb in valid_buypoint:
        i = 0
        retained_items = []
        for i in range(len(deferred_positions)):
            if vb >= deferred_positions[i][1]:
                positions_dict[deferred_positions[i][0]] += 1
            else:
                retained_items.append(deferred_positions[i])
        deferred_positions = retained_items
        # print(positions_dict[:10], max(positions_dict), deferred_positions, lag)
        if vb < valid_sellpoint[-1]:
            bin, atpoint = get_loc(vb)
            if not atpoint:
                if positions_dict[bin] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[vb] = chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    # print(deferred_positions)

            else:
                if positions_dict[bin+1] < position:
                    total_profit += chosen_vt[vb]
                    profit_position[vb] = chosen_vt[vb]
                    deferred_positions.append((bin, vb + lag))
                    deferred_positions.append((bin+1, vb + lag))
                    # print(deferred_positions)
        else:
            print(vb, valid_sellpoint[-1], valid_sellpoint)
            print("why larger")
        # if vb > 10000:
            # break
    return total_profit, profit_position, sum(positions_dict)
 

import pickle
dic = {}
for a in [1.0]:
    for b in [1000]:
            for d in [4]:
                import matplotlib.pyplot as plt
                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                ax2 = ax1.twinx()
                
                # total_profit, cnt, takercnt, resl, executed_trades_buy, executed_trades_sell = backtest_original(0, 4, y_predict0, "predict")
                executed_trades_0_buy, executed_trades_0_sell = backtest_11(y_predict0)
                # np.save('executed_trades_buy.npy', executed_trades_buy)
                # np.save('executed_trades_sell.npy', executed_trades_sell)
                # np.save('executed_trades_0_buy.npy', executed_trades_0_buy)
                # np.save('executed_trades_0_sell.npy', executed_trades_0_sell)

                

                # # total_profit, cnt, takercnt, resl, volume_buy, volume_sell 
                # for i in range(max(len(executed_trades_buy), len(executed_trades_0_buy))):
                #     if i < len(executed_trades_buy):
                #         print(i, "from ori", executed_trades_buy[i])
                #     if i < len(executed_trades_0_buy):
                #         print(i, "from speed", executed_trades_0_buy[i])

                # for i in range(max(len(executed_trades_sell), len(executed_trades_0_sell))):
                #     if i < len(executed_trades_sell):
                #         print(i, "from ori", executed_trades_sell[i])
                #     if i < len(executed_trades_0_sell):
                #         print(i, "from speed", executed_trades_0_sell[i])

                # if args.double_test:
                ax1.plot(*zip(*resl))

                plt.grid()
                ax2.plot(data.index, (data['mid_fu']), color='blue')


                plt.title(args.arch+";a:"+str(a)+"b:"+str(b)+"d:"+str(d))
                plt.legend()
                plt.show()
                plt.savefig("result"+args.arch+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+str(a)+"_"+str(b)+"_"+str(d)+"compare.png")
