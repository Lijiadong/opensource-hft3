import numpy as np
import pandas as pd
import lightgbm as lgb
from args import args
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib.dates import HourLocator
import datetime

# flist = ['06_23', '06_24', 's6_25', '06_26', '06_27']
# modell = lgb.Booster(model_file='modell_'+";".join(args.train)+'_'+";".join(args.valid)+'.txt')
# modelp = lgb.Booster(model_file='modelp_'+";".join(args.train)+'_'+";".join(args.valid)+'.txt')
# modelm = lgb.Booster(model_file='modelm_'+";".join(args.train)+'_'+";".join(args.valid)+'.txt')


modell = lgb.Booster(model_file='modell_1.txt')
modelp = lgb.Booster(model_file='modelp_1.txt')
modelm = lgb.Booster(model_file='modelm_1.txt')
# flist = ['07_22', '07_23', '07_24', '07_25', '07_26']
# flist = ['07_27', '07_28', '07_29', '07_30']
# flist = [ '07_29', '07_30', '07_31']
filename = "fu"


def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

flist = genflist(args.test[0])
print(flist)


data = pd.DataFrame()
first = True
i = 0
for file in flist:
    if first:
        data = pd.read_pickle('data_6/data_'+file+'.pkl')
        linear_y = pd.read_pickle('data_6/xnn2_'+file+'.pkl')["predict"]
        xnn = pd.read_pickle('data_6/xnn2_'+file+'.pkl')
        print(linear_y)
        with open('data_6/y_'+file+'.npy', 'rb') as f:
            y_true = np.load(f)
        with open('data_6/y3_'+file+'.npy', 'rb') as f:
            y3_true = np.load(f)
        with open('data_6/y4_'+file+'.npy', 'rb') as f:
            y4_true = np.load(f)
        first = False
        y = modell.predict(xnn[:])
        print("day, ", i, " ", r2_score(y_true, y))
        y3 = modelp.predict(xnn[:])
        print("day, ", i, " ", r2_score(y3_true, y3))
        y4 = modelm.predict(xnn[:])
        print("day, ", i, " ", r2_score(y4_true, y4))
    else:
        tmpxnn = pd.read_pickle('data_6/xnn2_'+file+'.pkl')
        xnn = pd.concat([xnn, tmpxnn])
        tmp = pd.read_pickle('data_6/data_'+file+'.pkl')
        data = pd.concat([data, tmp])
        linear_y = pd.concat([linear_y, pd.read_pickle('data_6/xnn2_'+file+'.pkl')["predict"]])
        with open('data_6/y_'+file+'.npy', 'rb') as f:
            tmpy_true = np.load(f)
        y = modell.predict(tmpxnn[:])
        print("day, ", i, " ", r2_score(tmpy_true, y))
        y_true = np.concatenate((y_true, tmpy_true), axis=0)
        with open('data_6/y3_'+file+'.npy', 'rb') as f:
            tmpy3_true = np.load(f)
        y3 = modelp.predict(tmpxnn[:])
        print("day, ", i, " ", r2_score(tmpy3_true, y3))
        y3_true = np.concatenate((y3_true, tmpy3_true), axis=0)
        with open('data_6/y4_'+file+'.npy', 'rb') as f:
            tmpy4_true = np.load(f)
        y4 = modelm.predict(tmpxnn[:])
        print("day, ", i, " ", r2_score(tmpy4_true, y4))
        y4_true = np.concatenate((y4_true, tmpy4_true), axis=0)
    i += 1

# modell = lgb.Booster(model_file='modell.txt')
# modelp = lgb.Booster(model_file='modelp.txt')
# modelm = lgb.Booster(model_file='modelm.txt')




y = modell.predict(xnn[:])
y3 = modelp.predict(xnn[:])
y4 = modelm.predict(xnn[:])

print(r2_score(y_true, y))
print(r2_score(y3_true, y3))
print(r2_score(y4_true, y4))

# print(data, data.shape)
# print(y, y.shape)




def backtest(a, b, d):
    state = 'empty'
    total_profit = 0
    cnt = 0
    takercnt = 0

    data['mid_fu'] = data['ap1_fu']/2+data['bp1_fu']/2
    data['predict1']=pd.DataFrame(y, index = data.index)
    data['stdp2']=pd.DataFrame(y3, index = data.index)
    data['stdm2']=pd.DataFrame(y4, index = data.index)

    p1='predict1'
    p2='predict1'
    stp='stdp2'
    stm='stdm2'

    resl = []
    def select(x):
        return (d+np.maximum(x,0)/2)*1
    def select2(x):
        return (d+np.maximum(x,0)/2)*1
    buy_price_lock = 0
    sell_price_lock = 0
    lag = 0 # time lag cuz in real trading there will be network lag
    filename='fu'
    for i in range(0, len(data)-1-lag):
        current_price = data['mid_'+filename][i]
        if state == 'empty':
            buy_price = np.minimum(data['bp1_'+filename][i]*(1-np.maximum(select(data[stm][i]),0)/1e4)*(1+np.clip(4*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4)), data['bp1_'+filename][i])
            sell_price = np.maximum(data['ap1_'+filename][i]*(1+np.maximum(select(data[stp][i]),0)/1e4)*(1+np.clip(4*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4)), data['ap1_'+filename][i])
            tpb = data['sellpriceT_'+filename][i+1]
            tps = data['buypriceT_'+filename][i+1]
            #print(data['time'][i], buy_price, tp)
            if tpb <= buy_price-0.01 and tpb != 0 and data[p1][i]>-a:
                #print(data['predict3'][i])
                state = 'buy'
                buy_price_lock = buy_price
                # print(data.index[i],data[p1][i])
                # print('buy',i, buy_price, tpb, data['buyprice_'+filename][i+1], data['mid_'+filename][i])
                total_profit += 0.5/1e4
                continue
            if tps >= sell_price+0.01 and tps != 0 and data[p1][i]<a:
                #print(data['predict3'][i])
                state = 'sell'
                sell_price_lock = sell_price
                # print(data.index[i],data[p1][i])
                # print('sell',i, sell_price, data['mid_'+filename][i])
                total_profit += 0.5/1e4
                continue
        if state == 'buy' and (data[p1][i]+data[p2][i])/2 < -b:
            sell_price = data['bp1_fu'][i+5]*(1.0)#(current_price)
            state = 'empty'
            # print(data.index[i],data[p1][i])
            print('sell close', sell_price)
            total_profit += sell_price / buy_price_lock - 1 - 2/1e4
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            # print(data.index[i], total_profit)
            continue
        
        if state == 'sell' and (data[p1][i]+data[p2][i])/2 > b:
            buy_price = data['ap1_fu'][i+5]*(1.0)#(current_price)
            state = 'empty'
            # print(data.index[i],data[p1][i])
            print('buy close', buy_price)
            total_profit += sell_price_lock / buy_price - 1 - 2/1e4
            cnt += 1
            takercnt += 1
            resl.append((data.index[i], total_profit))
            # print(data.index[i], total_profit)
            continue
        
        if state == 'buy':
            sell_price = np.maximum(data['ap1_'+filename][i]*(1+np.maximum(select2(data[stp][i]),0)/2e4)*(1+np.clip(3*(data[p1][i]+0.0)/1e4,-0/1e4, 20/1e4)), data['ap1_'+filename][i])
            tp = data['buypriceT_'+filename][i+1]
            if tp >= sell_price+0.01 and tp != 0:
                state = 'empty'
                # print(data.index[i],data[p1][i])
                # print('sell close', sell_price)
                total_profit += sell_price / buy_price_lock - 1 + 0.5/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
                # print(data.index[i], total_profit)
                continue
        
        if state == 'sell':
            buy_price = np.minimum(data['bp1_'+filename][i]*(1-np.maximum(select2(data[stm][i]),0)/2e4)*(1+np.clip(3*(data[p1][i]-0.0)/1e4, -20/1e4, 0/1e4)), data['bp1_'+filename][i])
            tp = data['sellpriceT_'+filename][i+1]
            if tp <= buy_price-0.01 and tp != 0:
                state = 'empty'
                # print(data.index[i],data[p1][i])
                # print('buy close', buy_price, tp)
                total_profit += sell_price_lock / buy_price - 1 + 0.5/1e4
                cnt += 1
                resl.append((data.index[i], total_profit))
                # print(data.index[i], total_profit)
            continue
    return total_profit, cnt, takercnt, resl

import pickle
dic = {}
# for a in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
#     for b in [10]:
#         for c in [-2.1, -1.9, -1.7, -1.5, -1.3, -1.1, -0.9, -0.7, -0.5, -0.3, -0.1, 0, 0.1, 0.3, 0.5, 0.7, 0.9]:
#             for d in [1.5, 2.5]:
# for a in [0, -0.1, -0.2, -0.3, -0.4, -0.5, -0.6, -0.7, -0.8, -0.9, -1.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
for a in [-1.0, 1.0]:
    for b in [10]:
        # for c in [-2.1, -1.9, -1.7, -1.5, -1.3, -1.1, -0.9, -0.7, -0.5, -0.3, -0.1, 0, 0.1, 0.3, 0.5, 0.7, 0.9]:
            # for d in [1.5, 2.5]:
            for d in [1]:              
                total_profit, cnt, takercnt, resl = backtest(a, b, d)
                # print(total_profit, cnt, takercnt, resl)
                # print(tuple(total_profit, cnt, takercnt))
                dic[(a, b, d)] = tuple([total_profit, cnt, takercnt])
                # print(resl)
                import matplotlib.pyplot as plt

                fig, ax1 = plt.subplots()
                fig.set_figwidth(16)
                fig.set_figheight(12)
                ax2 = ax1.twinx()
                ax1.plot(*zip(*resl), color='red')
                plt.grid()
                ax2.plot(data.index, (data['mid_fu']), color='blue')
                ax1.xaxis.set_major_locator(HourLocator(range(0, 25, 6)))
                ax1.xaxis.set_major_locator(HourLocator(range(0, 25, 6)))

                plt.title("lgb;a:"+str(a)+"b:"+str(b)+"d:"+str(d))
                plt.show()
                plt.savefig("result"+"-".join(flist)+str(a)+"_"+str(b)+"_"+str(d)+"_lgb2.png")
                with open('backtest_result_'+";".join(args.train)+"_"+";".join(args.valid)+"_"+";".join(args.test)+'_lgb2.pickle', 'wb') as f:
                    pickle.dump(dic, f)
                print(dic)