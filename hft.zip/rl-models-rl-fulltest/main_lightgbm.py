import numpy as np
import pandas as pd
from args import args
import datetime
from sklearn.metrics import mean_squared_error, r2_score

print('modell_'+";".join(args.train)+'_'+";".join(args.test)+'.txt')
index_all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58]

def genflist(date_list):
    print(date_list)
    start_month, start_day, end_month, end_day = int(date_list.split("-")[0].split("_")[0]), int(date_list.split("-")[0].split("_")[1]), int(date_list.split("-")[1].split("_")[0]), int(date_list.split("-")[1].split("_")[1])
    print(start_month, start_day, end_month, end_day)
    start = datetime.date(2022,start_month,start_day)
    end = datetime.date(2022,end_month,end_day)
    x_l = []
    print(start, end)
    for i in range((end-start).days+1):
        day = start + datetime.timedelta(days=i)
        month_str = "0"+str(day.month) if len(str(day.month)) < 2 else str(day.month) 
        day_str = "0"+str(day.day) if len(str(day.day)) < 2 else str(day.day) 
        x_l.append(month_str+'_'+day_str)
    return x_l

flist = genflist(args.train[0])
print(flist)
flist2 = genflist(args.test[0])
print(flist2)
test = pd.DataFrame()
first = True
for file in flist:
    print(file)
    if first:
        # test = pd.read_pickle('data_6/xnn2_'+file+'.pkl')
        with open('data_6/xnn_'+file+'.npy', 'rb') as f:
            # xnn = np.load(f)[:, index_all]
            xnn = np.load(f)
        first = False
        if args.y == "0":
            with open('data_6/y_'+file+'.npy', 'rb') as f:
                y = np.load(f)
        elif args.y == "3":
            with open('data_6/y3_'+file+'.npy', 'rb') as f:
                y3 = np.load(f)
        elif args.y == "4":
            with open('data_6/y4_'+file+'.npy', 'rb') as f:
                y4 = np.load(f)
    else:
        with open('data_6/xnn_'+file+'.npy', 'rb') as f:
            # tmp = np.load(f)[:, index_all]
            tmp = np.load(f)
        xnn = np.concatenate([xnn, tmp], axis=0)
        if args.y == "0":
            with open('data_6/y_'+file+'.npy', 'rb') as f:
                tmp = np.load(f)
            y = np.concatenate((y, tmp), axis=0)
        elif args.y == "3":
            with open('data_6/y3_'+file+'.npy', 'rb') as f:
                tmp = np.load(f)
            y3 = np.concatenate((y3, tmp), axis=0)
        elif args.y == "4":
            with open('data_6/y4_'+file+'.npy', 'rb') as f:
                tmp = np.load(f)
            y4 = np.concatenate((y4, tmp), axis=0)

first = True
for file in flist2:
    print(file)
    if first:
        # test_2 = pd.read_pickle('data_6/xnn2_'+file+'.pkl')
        with open('data_6/xnn_'+file+'.npy', 'rb') as f:
            # xnn_2 = np.load(f)[:, index_all]
            xnn_2 = np.load(f)
        first = False
        if args.y == "0":
            with open('data_6/y_'+file+'.npy', 'rb') as f:
                y_2 = np.load(f)
        elif args.y == "3":
            with open('data_6/y3_'+file+'.npy', 'rb') as f:
                y3_2 = np.load(f)
        elif args.y == "4":
            with open('data_6/y4_'+file+'.npy', 'rb') as f:
                y4_2 = np.load(f)
    else:
        # tmp = pd.read_pickle('data_6/xnn2_'+file+'.pkl')
        # test_2 = pd.concat([test_2, tmp])
        with open('data_6/xnn_'+file+'.npy', 'rb') as f:
            # tmp = np.load(f)[:, index_all]
            tmp = np.load(f)
        xnn_2 = np.concatenate([xnn_2, tmp], axis=0)
        if args.y == "0":
            with open('data_6/y_'+file+'.npy', 'rb') as f:
                tmp = np.load(f)
            y_2 = np.concatenate((y_2, tmp), axis=0)
        elif args.y == "3":
            with open('data_6/y3_'+file+'.npy', 'rb') as f:
                tmp = np.load(f)
            y3_2 = np.concatenate((y3_2, tmp), axis=0)
        elif args.y == "4":
            with open('data_6/y4_'+file+'.npy', 'rb') as f:
                tmp = np.load(f)
            y4_2 = np.concatenate((y4_2, tmp), axis=0)
from sklearn.linear_model import Ridge

model = Ridge(normalize=False, fit_intercept=False, alpha=100)
model = model.fit(xnn, y)


print(r2_score(y, model.predict(xnn)))
print(r2_score(y_2, model.predict(xnn_2)))

# exit(0)
import lightgbm as lgb


params = {
'task': 'train',
'boosting': 'gbdt', 
'objective': 'regression',
'metric': 'l2',
'data': 'regression.train',
'valid': 'regression.valid',
'output_model': 'trained_model.txt',
'feature_fraction': 0.5,
'bagging_fraction': 1,
'bagging_freq':1,
'num_iterations': 1000,
'early_stopping_round': 50,
'learning_rate': 0.05,
'num_leaves': 180,
'max_depth': 9,
'min_data_in_leaf': 10,
'reg_alpha': 1, 
'reg_lambda': 1,
'verbosity': 2,
'n_jobs': 8,
'seed': 0,
'bagging_seed':0,
'feature_fraction_seed':0
}
from sklearn.metrics import mean_squared_error, r2_score



if args.y == "0":
    train_dataset = lgb.Dataset(xnn, y)
    val_dataset = lgb.Dataset(xnn_2, y_2)

    #train_dataset = lgb.Dataset(test[:], y[:])
    #val_dataset = lgb.Dataset(test_2[:], y_2[:])


    modell = lgb.train(params = params,
                        train_set = train_dataset, 
                        valid_sets = [val_dataset], 
                  )
    modell.save_model('modell_'+";".join(args.train)+'_'+";".join(args.test)+'.txt', num_iteration=modell.best_iteration) 
    print(r2_score(y_2[:], modell.predict(xnn_2[:])))

              
elif args.y == "3":
    train_dataset = lgb.Dataset(xnn, y3)
    val_dataset = lgb.Dataset(xnn_2, y3_2)
    #train_dataset = lgb.Dataset(test[:], y3[:])
    #val_dataset = lgb.Dataset(test_2[:], y3_2[:])

    modelp = lgb.train(params = params,
                        train_set = train_dataset, 
                        valid_sets = [val_dataset], 
                    )

    
    modelp.save_model('modelp_'+";".join(args.train)+'_'+";".join(args.test)+'.txt', num_iteration=modelp.best_iteration) 
    print(r2_score(y3_2[:], modelp.predict(xnn_2[:])))



elif args.y == "4":

#train_dataset = lgb.Dataset(test[:], y4[:])
#val_dataset = lgb.Dataset(test_2[:], y4_2[:])
    train_dataset = lgb.Dataset(xnn, y4)
    val_dataset = lgb.Dataset(xnn_2, y4_2)
    modelm = lgb.train(params = params,
                        train_set = train_dataset, 
                        valid_sets = [val_dataset], 
                    )
    modelm.save_model('modelm_'+";".join(args.train)+'_'+";".join(args.test)+'.txt', num_iteration=modelm.best_iteration) 
    print(r2_score(y4_2[:], modelm.predict(xnn_2[:])))







