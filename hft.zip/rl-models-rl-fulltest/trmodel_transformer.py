import torch
import models
from args import args
import numpy as np
args.temp = 1

model = torch.load("results/best_model_yTSTransformerEncoderClassiregressor0_12_21-01_31_02_01-02_04_02_01-02_018554873884.pt")
model.eval()
model.cpu()
# model.cuda()
# input = torch.ones(1, args.input_size, args.T).cuda()
input = torch.ones(1, args.input_size, args.T)
# input = torch.from_numpy(np.load("504_batched1.npy"))
# print(input.size())
traced_script_module = torch.jit.trace(model, input)
print(traced_script_module(input))
print(model(input))
# traced_script_module.save("best_model_y"+args.arch+args.y+"_"+";".join(args.train)+"_"+";".join(args.test)+str(args.seed)+"script.pt")

traced_script_module.save("results_new_3/best_model_yTSTransformerEncoderClassiregressor0_12_21-01_31_02_01-02_04_02_01-02_018554873884_script.pt")

# traced_script_module_1 = torch.jit.load("results_new_3/best_model_yTSTransformerEncoderClassiregressor0_09_21-10_25;12_02-12_03_12_04-12_05_12_04-12_041977460568_script.pt")

# print(traced_script_module_1(input))T